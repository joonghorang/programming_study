﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CODE_CHAPTER12 //Binary Plus Caculator
{
    class Input
    {
        public static int[] inputarray;
        public static void InInt(int addnum)
        {
            Console.WriteLine("이진숫자를 입력하세요. 다른 문자 입력시 프로그램 종료");
            string line = Console.ReadLine();
            string[] words = line.Split(' ');
            int[] array = new int[words.Length + addnum];

            for (int i = 0; i < words.Length; i++)
                array[words.Length - i - 1] = Convert.ToInt32(words[i]);

            inputarray = new int[array.Length]; // 8자리를 입력하면 다른 클래스에서 [9]짜리 배열을 선언하였더라도, 9칸짜리가 8칸짜리로 치환되어 들어가버린다. 이를 해결하기위해 공백 칸 addnum이란 변수를 초기화입력시에 넣어주고, 여기서는 addnum을 총 배열길이에 더해준 상태로 배열을 선언한다. 
            inputarray = array;
        }
    }


    class AndGate
    {
        public static int output;
        public static int AndBulb(int input1, int input2)
        {
            if (input1 == 1 && input2 == 1)
            {
                output = 1;
            }
            else
            {
                output = 0;
            }
            return output;
        }
    }

    class OrGate
    {
        public static int output;
        public static int OrBulb(int input1, int input2)
        {
            if (input1 == 1 || input2 == 1)
            {
                output = 1;
            }
            else
            {
                output = 0;
            }
            return output;
        }
    }

    class XorGate
    {
        public static int output;
        public static int XorBulb(int input1, int input2)
        {
            if (input1 == 1 && input2 == 1)
            {
                output = 0;
            }
            else if (input1 == 0 && input2 == 0)
            {
                output = 0;
            }
            else
            {
                output = 1;
            }
            return output;
        }
    }

    class NandGate
    {
        public static int output;
        public static int NandBulb(int input1, int input2)
        {
            if (input1 == 1 && input2 == 1)
            {
                output = 0;
            }
            else
            {
                output = 1;
            }
            return output;
        }
    }

    class NorGate
    {
        public static int output;
        public static int NorBulb(int input1, int input2)
        {
            if (input1 == 0 && input2 == 0)
            {
                output = 1;
            }
            else
            {
                output = 0;
            }
            return output;
        }
    }

    class InvertGate
    {
        public static int InvertBulb(int input1)
        {
            input1 = (input1 + 1) % 2;
            return input1;
        }
    }

    class HalfPlus
    {
        public static int output; // 합출력
        public static int carryout; // 자리올림출력
        public static int HalfN(int input1, int input2)
        {
            XorGate.XorBulb(input1, input2); // 각각의 첫 자리수를 입력받아 Xor게이트를 통과시킨다. 
            output = XorGate.output; // 출력할 변수명에 해당값을 입력.
            return output;
        }

        public static int Carry(int input1, int input2)
        {
            AndGate.AndBulb(input1, input2); // 각각의 첫 자리수를 입력받아 And게이트를 통과시킨다. 두 자리 모두 1이어야 carry가 생김.
            carryout = AndGate.output; // 캐리출력 변수에 해당값을 입력
            return carryout;
        }

        // 리턴값을 한 번에 하나만 줄 수 있기 때문에 두개의 함수로 나누어서 작성하였다.
    }

    class FullPlus
    {
        public static int carryin;
        public static int output; // 합출력
        public static int carryout; // 자리올림 입력
        public static int carry1;
        public static int carry2;

        public static int PreFullAdd(int input1, int input2) // 합출력함수
        {
            carryin = HalfPlus.carryout; // 제일 처음 반가산기에 넣어져 있던 캐리값을 받아서 캐리 1번에 입력

            int tempsum = HalfPlus.HalfN(input1, input2); // 반가산기의 합을 동일하게 사용하므로 해당값을 반가산기에 입력
            HalfPlus.Carry(input1, input2);

            carry1 = HalfPlus.carryout; // 첫번째 합에 대한 캐리값을 캐리 2번에 입력

            HalfPlus.HalfN(tempsum, carryin); // 위의 계산결과와 올라온 캐리값을 다시 더해준다. 
            carry2 = HalfPlus.Carry(tempsum, carryin);

            carryout = OrGate.OrBulb(carry1, carry2); // 두번째 합에 대한 자리올림값을 최종 저장하기 위해 캐리3번에 입력
            FullPlus.carryin = OrGate.OrBulb(carry1, carry2);

            output = HalfPlus.output; // 계산 결과로서 최종 합을 입력한다. 

            return output; // 전가산기의 합출력
        }

        // 현재 전부 1 1 1 1 1 1 1 1 1일때 연결부에서 0으로 출력되는 버그 발생 // 해결함

        public static int FullAdd(int input1, int input2) // 합출력함수
        {
            carryin = FullPlus.carryout; // 제일 처음 반가산기에 넣어져 있던 캐리값을 받아서 캐리 1번에 입력

            int tempsum = HalfPlus.HalfN(input1, input2); // 반가산기의 합을 동일하게 사용하므로 해당값을 반가산기에 입력
            HalfPlus.Carry(input1, input2);

            carry1 = HalfPlus.carryout; // 첫번째 합에 대한 캐리값을 캐리 2번에 입력

            HalfPlus.HalfN(tempsum, carryin); // 위의 계산결과와 올라온 캐리값을 다시 더해준다. 
            carry2 = HalfPlus.Carry(tempsum, carryin);

            carryout = OrGate.OrBulb(carry1, carry2); // 두번째 합에 대한 자리올림값을 최종 저장하기 위해 캐리3번에 입력

            output = HalfPlus.output; // 계산 결과로서 최종 합을 입력한다. 
            return output; // 전가산기의 합출력
        }

        //public static int FullCarry(int input1, int input2) // 자리올림출력함수
        //{
        //    carryout = carry3; // 위에서 캐리값을 다 계산하였으나 리턴은 하나밖에 못해주므로 여기서 캐리를 출력.
        //    return carryout; // 전가산기의 자리올림출력
        //}
    }

    class EightAdder
    {
        public static int[] a = new int[8];
        public static int[] b = new int[8];
        public static int[] result = new int[8]; // 8진수 계산을 받아주는 배열선언

        public static void EightSum()
        {
            HalfPlus.Carry(a[0], b[0]);
            result[0] = HalfPlus.HalfN(a[0], b[0]); // 일단 처음엔 반가산기에 값을 넣는다. 배열 정적 메소드 IndexOf()함수를 이용하려 했으나 입력값으로 배열의 이름과 배열 내용값까지 넣어야 했기 때문에 사용할 수 없었다.

            result[1] = FullPlus.PreFullAdd(a[1], b[1]);

            // 그다음 2번째 배열값부터는 전가산기에 값을 넣는다.
            for (int i = 2; i < a.Length; i++)
            {
                //FullPlus.FullCarry(a[i], b[i]); // 최종 자리올림 결과를 반가산기 캐리값에 미리 입력하여 전가산기에 제일 처음에 입력될 수 있도록함.
                result[i] = FullPlus.FullAdd(a[i], b[i]); // 한자리씩 결과배열에 입력
            }
        }
    }

    class SixteenAdder
    {
        public static int[] a = new int[8];
        public static int[] b = new int[8];
        public static int[] c = new int[8];
        public static int[] d = new int[8];

        public static int[] result = new int[16]; // 8진수 계산을 받아주는 배열선언

        public static void SixteenSum()
        {
            HalfPlus.Carry(a[0], b[0]);
            result[0] = HalfPlus.HalfN(a[0], b[0]); // 일단 처음엔 반가산기에 값을 넣는다. 배열 정적 메소드 IndexOf()함수를 이용하려 했으나 입력값으로 배열의 이름과 배열 내용값까지 넣어야 했기 때문에 사용할 수 없었다.

            result[1] = FullPlus.PreFullAdd(a[1], b[1]);

            for (int i = 2; i < a.Length; i++)
            {
                //FullPlus.FullCarry(a[i], b[i]); // 최종 자리올림 결과를 반가산기 캐리값에 미리 입력하여 전가산기에 제일 처음에 입력될 수 있도록함.
                result[i] = FullPlus.FullAdd(a[i], b[i]); // 한자리씩 결과배열에 입력
            }

            HalfPlus.carryout = FullPlus.carryout; // 직전의 자리올림 값을 직렬로 연결해줌 // 버그문제 있던 부분 해결 (2014.06.05) 16비트 가산기 정상작동.
            result[8] = FullPlus.PreFullAdd(c[0], d[0]);

            for (int i = 1; i < c.Length; i++)
            {
                result[i + 8] = FullPlus.FullAdd(c[i], d[i]); // 한자리씩 결과배열에 입력
            }
        }
    }

    class ToDecimal
    {
        public static int[] ToD1 = new int[9];
        public static int[] ToD2 = new int[9]; // 10진수 변환용 배열
        public static int aDecimal = 0;
        public static int bDecimal = 0;

        public static void ToDec()
        {

            // 먼저 뺄 수 와 빼어지는 수의 대소비교를 위해서 이진수를 십진수로 변환해야한다.
            int total = 0;
            //이진수를 십진수로 바꿔주는 코드.

            for (int i = 0; i < ToD1.Length; i++)
            {
                if (i == 0)
                {
                    // I == 0 일때는 0번째 수 즉, 2의 0승이 들어있다는 이야기이므로 1일 경우 그대로 1 0일 경우도 그대로 0이므로 아무 일도 하지 않는다. 
                }
                else
                {
                    for (int j = 1; j <= i; j++)
                    {
                        ToD1[i] = ToD1[i] * 2;
                    }
                }
            }
            for (int i = 0; i < ToD1.Length; i++)
            {
                total += ToD1[i];
            }
            aDecimal = total;
            total = 0;

            for (int i = 0; i < ToD2.Length; i++)
            {
                if (i == 0)
                {
                    // I == 0 일때는 0번째 수 즉, 2의 0승이 들어있다는 이야기이므로 1일 경우 그대로 1 0일 경우도 그대로 0이므로 아무 일도 하지 않는다. 
                }
                else
                {
                    for (int j = 1; j <= i; j++)
                    {
                        ToD2[i] = ToD2[i] * 2;
                    }
                }
            }

            for (int i = 0; i < ToD2.Length; i++)
            {
                total += ToD2[i];
            }

            bDecimal = total;
        }

    }
    class EightMinus
    {
        public static int[] a = new int[9];
        public static int[] minus = new int[9];
        public static int[] result = new int[9]; // 8진수 계산을 받아주는 배열선언

        public static void EightSub()
        {

            for (int i = 0; i < a.Length; i++)
            {
                ToDecimal.ToD1[i] = a[i];
                ToDecimal.ToD2[i] = minus[i];
            }
            ToDecimal.ToDec();
 
            if (ToDecimal.aDecimal > ToDecimal.bDecimal)
            {

                for (int i = 0; i < minus.Length - 1; i++) // minus의 가장 마지막 칸은 오버플로우를 위한 공백열이므로 그 자리에는 인버트시키지 않는다. 
                {
                    minus[i] = InvertGate.InvertBulb(minus[i]); // 빼는 수에 대한 1의 보수를 구합니다. [232p]
                }

                HalfPlus.Carry(a[0], minus[0]);
                result[0] = HalfPlus.HalfN(a[0], minus[0]); // 일단 처음엔 반가산기에 값을 넣는다. 배열 정적 메소드 IndexOf()함수를 이용하려 했으나 입력값으로 배열의 이름과 배열 내용값까지 넣어야 했기 때문에 사용할 수 없었다.

                result[1] = FullPlus.PreFullAdd(a[1], minus[1]);

                for (int i = 2; i < minus.Length; i++)
                {
                    result[i] = FullPlus.FullAdd(a[i], minus[i]); // 한자리씩 결과배열에 입력
                }

                minus[0] = 1; // 결과에 1을 더합니다. [233p] 이를 위해 b의 0번째 자리 외 에는 모두 0으로 만들어줍니다. 
                for (int i = 1; i < minus.Length; i++)
                {
                    minus[i] = 0;
                }

                HalfPlus.Carry(result[0], minus[0]);
                result[0] = HalfPlus.HalfN(result[0], minus[0]);

                result[1] = FullPlus.PreFullAdd(result[1], minus[1]);

                for (int i = 2; i < a.Length; i++)
                {
                    result[i] = FullPlus.FullAdd(result[i], minus[i]);
                }
                result[result.Length - 1] -= 1; // 결과에서 100000000을 뺍니다.
            }

            else // 빼는 수가 빼어지는 수보다 클때
            {
                for (int i = 0; i < minus.Length - 1; i++) // minus의 가장 마지막 칸은 오버플로우를 위한 공백열이므로 그 자리에는 인버트시키지 않는다. 
                {
                    minus[i] = InvertGate.InvertBulb(minus[i]); // 빼는 수에 대한 1의 보수를 구합니다.
                }

                HalfPlus.Carry(a[0], minus[0]);
                result[0] = HalfPlus.HalfN(a[0], minus[0]); // 일단 처음엔 반가산기에 값을 넣는다. 배열 정적 메소드 IndexOf()함수를 이용하려 했으나 입력값으로 배열의 이름과 배열 내용값까지 넣어야 했기 때문에 사용할 수 없었다.

                result[1] = FullPlus.PreFullAdd(a[1], minus[1]);

                for (int i = 2; i < minus.Length; i++)
                {
                    result[i] = FullPlus.FullAdd(a[i], minus[i]); // 한자리씩 결과배열에 입력
                }

                for (int i = 0; i < result.Length; i++)
                {
                    result[i] = InvertGate.InvertBulb(result[i]); // 최종 결과를 다시 인버트 시키면 총 음수량이 산출됨.                
                }
            }
        }
    }

    class SixteenMinus
    {
        public static int[] a = new int[8];
        public static int[] b = new int[8];
        public static int[] c = new int[8];
        public static int[] d = new int[8];

        public static int[] result = new int[16];

        public static void SixteenSub()
        {

            HalfPlus.Carry(a[0], b[0]);
            result[0] = HalfPlus.HalfN(a[0], b[0]); // 일단 처음엔 반가산기에 값을 넣는다. 배열 정적 메소드 IndexOf()함수를 이용하려 했으나 입력값으로 배열의 이름과 배열 내용값까지 넣어야 했기 때문에 사용할 수 없었다.

            result[1] = FullPlus.PreFullAdd(a[1], b[1]);

            for (int i = 2; i < a.Length; i++)
            {
                //FullPlus.FullCarry(a[i], b[i]); // 최종 자리올림 결과를 반가산기 캐리값에 미리 입력하여 전가산기에 제일 처음에 입력될 수 있도록함.
                result[i] = FullPlus.FullAdd(a[i], b[i]); // 한자리씩 결과배열에 입력
            }

            FullPlus.carryin = FullPlus.carryout; // 직전의 자리올림 값을 직렬로 연결해줌
            result[8] = FullPlus.PreFullAdd(c[0], d[0]);

            for (int i = 1; i < c.Length; i++)
            {
                result[i + 8] = FullPlus.FullAdd(c[i], d[i]); // 한자리씩 결과배열에 입력
            }
        }
    }
    class Bulb
    {
        public static void IsOn(int[] input)
        {
            for (int i = 0; i < input.Length; i++)
                if (input[input.Length - i - 1] == 1)
                {
                    Console.Write(" * ");
                }
                else
                {
                    Console.Write(" - ");
                }
            Console.WriteLine();
        }
    }

    class MainApp
    {
        static void Main(string[] args)
        {

            Input.InInt(1);
            EightMinus.a = Input.inputarray;

            Input.InInt(1);
            EightMinus.minus = Input.inputarray;
            //Array.Resize(ref EightMinus.minus, 9); // 로 할수도 있다. 

            EightMinus.EightSub();

            Bulb.IsOn(EightMinus.result); // 최종 출력용

        }
    }
}

