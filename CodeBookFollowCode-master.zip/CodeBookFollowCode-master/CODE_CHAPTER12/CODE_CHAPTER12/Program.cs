﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CODE_CHAPTER12 //Binary Plus Caculator
{
    class Input
    {
        public static int[] inputarray;
        public static void InInt()
        {
            Console.WriteLine("이진숫자를 입력하세요. 다른 문자 입력시 프로그램 종료");
            string line = Console.ReadLine();
            string[] words = line.Split(' ');
            int[] array = new int[words.Length];

            for (int i = 0; i < words.Length; i++)
                array[words.Length - i - 1] = Convert.ToInt32(words[i]);

            inputarray = new int[array.Length];
            inputarray = array;
        }
    }

    class AndGate
    {
        public static int output;
        public static int AndBulb(int input1, int input2)
        {
            if (input1 == 1 && input2 == 1)
            {
                output = 1;
            }
            else
            {
                output = 0;
            }
            return output;
        }
    }

    class OrGate
    {
        public static int output;
        public static int OrBulb(int input1, int input2)
        {
            if (input1 == 1 || input2 == 1)
            {
                output = 1;
            }
            else
            {
                output = 0;
            }
            return output;
        }
    }

    class XorGate
    {
        public static int output;
        public static int XorBulb(int input1, int input2)
        {
            if (input1 == 1 && input2 == 1)
            {
                output = 0;
            }
            else if (input1 == 0 && input2 == 0)
            {
                output = 0;
            }
            else
            {
                output = 1;
            }
            return output;
        }
    }

    class NandGate
    {
        public static int output;
        public static int NandBulb(int input1, int input2)
        {
            if (input1 == 1 && input2 == 1)
            {
                output = 0;
            }
            else
            {
                output = 1;
            }
            return output;
        }
    }

    class NorGate
    {
        public static int output;
        public static int NorBulb(int input1, int input2)
        {
            if (input1 == 0 && input2 == 0)
            {
                output = 1;
            }
            else
            {
                output = 0;
            }
            return output;
        }
    }

    class InvertGate
    {
        public static int output;
        public static int InvertBulb(int input1)
        {
            if (input1 == 1)
            {
                output = 0;
            }
            else
            {
                output = 1;
            }
            return output;
        }
    }

    class HalfPlus
    {
        public static int output; // 합출력
        public static int carryout; // 자리올림출력
        public static int HalfN(int input1, int input2)
        {
            XorGate.XorBulb(input1, input2); // 각각의 첫 자리수를 입력받아 Xor게이트를 통과시킨다. 
            output = XorGate.output; // 출력할 변수명에 해당값을 입력.
            return output;
        }

        public static int Carry(int input1, int input2)
        {
            AndGate.AndBulb(input1, input2); // 각각의 첫 자리수를 입력받아 And게이트를 통과시킨다. 두 자리 모두 1이어야 carry가 생김.
            carryout = AndGate.output; // 캐리출력 변수에 해당값을 입력
            return carryout;
        }

        // 리턴값을 한 번에 하나만 줄 수 있기 때문에 두개의 함수로 나누어서 작성하였다.
    }

    class FullPlus
    {
        public static int carryin;
        public static int output; // 합출력
        public static int carryout; // 자리올림 입력
        public static int carry1;
        public static int carry2;
        public static int carry3;

        public static int PreFullAdd(int input1, int input2) // 합출력함수
        {
            carryin = HalfPlus.carryout; // 제일 처음 반가산기에 넣어져 있던 캐리값을 받아서 캐리 1번에 입력

            int tempsum = HalfPlus.HalfN(input1, input2); // 반가산기의 합을 동일하게 사용하므로 해당값을 반가산기에 입력
            HalfPlus.Carry(input1, input2);

            carry1 = HalfPlus.carryout; // 첫번째 합에 대한 캐리값을 캐리 2번에 입력

            HalfPlus.HalfN(tempsum, carryin); // 위의 계산결과와 올라온 캐리값을 다시 더해준다. 
            carry2 = HalfPlus.Carry(tempsum, carryin);

            carryout = OrGate.OrBulb(carry1, carry2); // 두번째 합에 대한 자리올림값을 최종 저장하기 위해 캐리3번에 입력
            FullPlus.carryin = OrGate.OrBulb(carry1, carry2);

            output = HalfPlus.output; // 계산 결과로서 최종 합을 입력한다. 

            return output; // 전가산기의 합출력
        }

        public static int FullAdd(int input1, int input2) // 합출력함수
        {
            carryin = FullPlus.carryout; // 제일 처음 반가산기에 넣어져 있던 캐리값을 받아서 캐리 1번에 입력

            int tempsum = HalfPlus.HalfN(input1, input2); // 반가산기의 합을 동일하게 사용하므로 해당값을 반가산기에 입력
            HalfPlus.Carry(input1, input2);

            carry1 = HalfPlus.carryout; // 첫번째 합에 대한 캐리값을 캐리 2번에 입력

            HalfPlus.HalfN(tempsum, carryin); // 위의 계산결과와 올라온 캐리값을 다시 더해준다. 
            carry2 = HalfPlus.Carry(tempsum, carryin);

            carryout = OrGate.OrBulb(carry1, carry2); // 두번째 합에 대한 자리올림값을 최종 저장하기 위해 캐리3번에 입력

            output = HalfPlus.output; // 계산 결과로서 최종 합을 입력한다. 
            return output; // 전가산기의 합출력
        }
        //public static int FullCarry(int input1, int input2) // 자리올림출력함수
        //{
        //    carryout = carry3; // 위에서 캐리값을 다 계산하였으나 리턴은 하나밖에 못해주므로 여기서 캐리를 출력.
        //    return carryout; // 전가산기의 자리올림출력
        //}

        //public static void Print()
        //{
        //    Console.WriteLine("합비트는 {0}, 자리올림 비트는 {1}", HalfPlus.output1, output2);
        //} // Bulb클래스의 IsOn함수로 대체 
    }

    class Bulb
    {
        public static void IsOn(int[] input)
        {
            for (int i = 0; i < input.Length; i++ )
                if (input[input.Length - i - 1] == 1)
                {
                    Console.Write(" * ");
                }
                else
                {
                    Console.Write(" - ");
                }
            Console.WriteLine();
        }
    }

    class EightAdder
    {
        public static int[] a = new int[8];
        public static int[] b = new int[8];
        public static int[] result = new int[8]; // 8진수 계산을 받아주는 배열선언

        public static void EightSum()
        {
            HalfPlus.Carry(a[0], b[0]);
            result[0] = HalfPlus.HalfN(a[0], b[0]); // 일단 처음엔 반가산기에 값을 넣는다. 배열 정적 메소드 IndexOf()함수를 이용하려 했으나 입력값으로 배열의 이름과 배열 내용값까지 넣어야 했기 때문에 사용할 수 없었다.

            result[1] = FullPlus.PreFullAdd(a[1], b[1]);

            // 그다음 2번째 배열값부터는 전가산기에 값을 넣는다.
            for(int i = 2; i < a.Length; i++)
            {
                //FullPlus.FullCarry(a[i], b[i]); // 최종 자리올림 결과를 반가산기 캐리값에 미리 입력하여 전가산기에 제일 처음에 입력될 수 있도록함.
                result[i] = FullPlus.FullAdd(a[i], b[i]); // 한자리씩 결과배열에 입력
            }
        }
    }

    class SixteenAdder
    {
        public static int[] a = new int[8];
        public static int[] b = new int[8];
        public static int[] c = new int[8];
        public static int[] d = new int[8];

        public static int[] result = new int[16]; // 8진수 계산을 받아주는 배열선언

        public static void SixteenSum()
        {
            HalfPlus.Carry(a[0], b[0]);
            result[0] = HalfPlus.HalfN(a[0], b[0]); // 일단 처음엔 반가산기에 값을 넣는다. 배열 정적 메소드 IndexOf()함수를 이용하려 했으나 입력값으로 배열의 이름과 배열 내용값까지 넣어야 했기 때문에 사용할 수 없었다.

            result[1] = FullPlus.PreFullAdd(a[1], b[1]);
            
            for (int i = 2; i < a.Length; i++)
            {
                //FullPlus.FullCarry(a[i], b[i]); // 최종 자리올림 결과를 반가산기 캐리값에 미리 입력하여 전가산기에 제일 처음에 입력될 수 있도록함.
                result[i] = FullPlus.FullAdd(a[i], b[i]); // 한자리씩 결과배열에 입력
            }

            FullPlus.carryin = FullPlus.carryout; // 직전의 자리올림 값을 직렬로 연결해줌
            result[8] = FullPlus.PreFullAdd(c[0], d[0]);

            for (int i = 1; i < c.Length; i++)
            {
                result[i + 8] = FullPlus.FullAdd(c[i], d[i]); // 한자리씩 결과배열에 입력
            }
        }
    }
    class MainApp
    {
        static void Main(string[] args)
        {

            Input.InInt();
            SixteenAdder.a = Input.inputarray;
            Input.InInt();
            SixteenAdder.b = Input.inputarray; // a와 b를 입력받음

            Input.InInt();
            SixteenAdder.c = Input.inputarray;
            Input.InInt();
            SixteenAdder.d = Input.inputarray;

            int[] SixteenSum = new int[16];

            SixteenAdder.SixteenSum();
            SixteenSum = SixteenAdder.result;

            Bulb.IsOn(SixteenSum); // 최종 출력용
        }
    }
}

