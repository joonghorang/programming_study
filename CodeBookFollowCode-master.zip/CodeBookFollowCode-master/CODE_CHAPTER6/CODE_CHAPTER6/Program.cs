﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CODE_CHAPTER6
{
    class Relay
    {
        public static bool aswitch;
        public static bool bswitch;

        static void Relation(bool aswitch)
        {
            if (aswitch == true)
            {
                bswitch = true;
                Console.WriteLine("*");
            }
            else if (aswitch == false)
            {
                bswitch = false;
                Console.WriteLine("_");
            }
        }

        static void SwitchInput()
        {
            aswitch = false;
            Console.WriteLine("스위치를 키려면 1, 끄려면 0 ");
            int bnum = Convert.ToInt32(Console.ReadLine());

            if (bnum == 0)
            {
                aswitch = false;
            }
            else if (bnum == 1)
            {
                aswitch = true;
            }
        }
        static void Main(string[] args)
        {
            SwitchInput();
            Relation(aswitch);
        }
    }
}
