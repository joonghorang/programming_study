﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CODE_CHAPTER10
{
    class AndGate
    {
        public static int input1;
        public static int input2;
        public static int output;

        public static void InInt()
        {
            Console.WriteLine("1번스위치를 키려면 1, 끄려면 0 ");
            input1 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("2번스위치를 키려면 1, 끄려면 0 ");
            input2 = Convert.ToInt32(Console.ReadLine());
        }

        public static int AndBulb(int input1, int input2)
        {
            if (input1 == 1 && input2 == 1)
            {
                output = 1;
            }
            else
            {
                output = 0;
            }
            return output;
        }


        public static void OutInt()
        {
            Console.WriteLine(output);
        }
    }

    class OrGate
    {
        public static int input1;
        public static int input2;
        public static int output;

        public static void InInt()
        {
            Console.WriteLine("1번스위치를 키려면 1, 끄려면 0 ");
            input1 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("2번스위치를 키려면 1, 끄려면 0 ");
            input2 = Convert.ToInt32(Console.ReadLine());
        }

        public static int OrBulb(int input1, int input2)
        {
            if (input1 == 1 || input2 == 1)
            {
                output = 1;
            }
            else
            {
                output = 0;
            }
            return output;
        }


        public static void OutInt()
        {
            Console.WriteLine(output);
        }
    }

    class ExOrGate
    {
        public static int input1;
        public static int input2;
        public static int output;

        public static void InInt()
        {
            Console.WriteLine("1번스위치를 키려면 1, 끄려면 0 ");
            input1 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("2번스위치를 키려면 1, 끄려면 0 ");
            input2 = Convert.ToInt32(Console.ReadLine());
        }

        public static int ExOrBulb(int input1, int input2)
        {
            if (input1 == 1 && input2 == 1)
            {
                output = 0;
            }
            else if(input1 == 0 && input2 == 0)
            {
                output = 0;
            }
            else
            {
                output = 1;
            }
            return output;
        }


        public static void OutInt()
        {
            Console.WriteLine(output);
        }
    }

    class NandGate
    {
        public static int input1;
        public static int input2;
        public static int output;

        public static void InInt()
        {
            Console.WriteLine("1번스위치를 키려면 1, 끄려면 0 ");
            input1 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("2번스위치를 키려면 1, 끄려면 0 ");
            input2 = Convert.ToInt32(Console.ReadLine());
        }

        public static int NandBulb(int input1, int input2)
        {
            if (input1 == 1 && input2 == 1)
            {
                output = 0;
            }
            else
            {
                output = 1;
            }
            return output;
        }


        public static void OutInt()
        {
            Console.WriteLine(output);
        }
    }

    class NorGate
    {
        public static int input1;
        public static int input2;
        public static int output;

        public static void InInt()
        {
            Console.WriteLine("1번스위치를 키려면 1, 끄려면 0 ");
            input1 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("2번스위치를 키려면 1, 끄려면 0 ");
            input2 = Convert.ToInt32(Console.ReadLine());
        }

        public static int NorBulb(int input1, int input2)
        {
            if (input1 == 0 && input2 == 0)
            {
                output = 1;
            }
            else
            {
                output = 0;
            }
            return output;
        }


        public static void OutInt()
        {
            Console.WriteLine(output);
        }
    }

    class InvertGate
    {
        public static int input1;
        public static int output;
        public static int InvertBulb(int input1)
        {
            if(input1 == 1)
            {
                output = 0;
            }
            else
            {
                output = 1;
            }
            return output;
        }
    }

    class MainApp
    {
        static void Main(string[] args)
        {
            AndGate.InInt();
            AndGate.AndBulb(AndGate.input1, AndGate.input2);
            AndGate.OutInt();

            OrGate.InInt();
            OrGate.OrBulb(OrGate.input1, OrGate.input2);
            OrGate.OutInt();

            ExOrGate.InInt();
            ExOrGate.ExOrBulb(ExOrGate.input1, ExOrGate.input2);
            ExOrGate.OutInt();

            NandGate.InInt();
            NandGate.NandBulb(NandGate.input1, NandGate.input2);
            NandGate.OutInt();

            NorGate.InInt();
            NorGate.NorBulb(NorGate.input1, NorGate.input2);
            NorGate.OutInt();
        }
    }
}

