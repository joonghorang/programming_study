IO 멀티 플렉싱

이전 Chapter에서는 다중접속 서버의 구현을 위해서 클라이언트의 연결 요청이 있을 때마다 새로운 프로세스를 생성하였다. 
하지만 이는 많은 자원을 사용한다. 그래서 효율적으로 사용하기 위해 

"하나의 통신채널을 통해서 둘 이상의 데이터(시그널)을 전송하는데 사용되는 기술" 인 멀티플렉싱을 사용한다. 

이를 이해하는 이야기

어느 교실에 학생이 열 명 있다. 그런데 이 책에 나오는 등장 인물들 처럼 이 아이들 역시 상상을 초월한다.
선생님은 한 분인데, 
수업시간 내내 선생님에게 질문을 한다.
그래서 이 학교에서는 어쩔 수 없이, 이 반에 학생 한 명당 교사 한 명을 두었다.
따라서 이 교실에만 현재 교사의 수가 열 명이다. 
이후로도 한 학생이 전학을 오면 교사도 한 명 늘리고,
두 명의 학생이 전학 오면 교사도 두 명을 늘렸다.
전학 온 녀석들도 모두 질문에 살고 질문에 죽는 녀석들이기 때문이다.
지금 언급한 이야기에서 학생은 클라이언트에, 
교사는 클라이언트와 데이터를 주고받는 서버 쪽 프로세스에 비유하면,
이 반의 운영방식은 멀티프로세스 기반이라 할 수 있다.

그런데 어느 날 이 반에 아주 무시무시한 능력을 소유하신 선생님께서 전근 오셨다.
이분은 아이들의 무차별한 질문에 혼자 답을 다한다. 그 답변의 속도가 너무 빨라서 학생들은 대기하지 않고도
답변을 들을 수 있다.
그래서 학교에서는 교사의 효율적 활용을 위해 이 분을 제외한 나머지 분들을 다른 반으로 이동시켰다.
때문에 이제 학생들은 질문에 앞서 '손을 들어야'하고, 교사는 
손을 든 학생의 질문을 '확인하고선 답변'을 하기 시작했다. 
즉, 이 교실은 멀티플렉싱 기반으로 운영되기 시작한 것이다. 

IO 멀티플렉싱 서버에서는 프로세스가, 손을 든(데이터가 수신된) 소켓이 있는지 확인을 한다. 
그래서 손을 든 소켓을 통해서 전송된 데이터를 수신하게 된다. 

12-2 select 함수의 이해와 서버의 구현

select()함수를 사용하면 한 곳에 여러 개의 파일  디스크립터를 모아놓고 동시에 이들을 관찰할 수 있다.
	- 수신한 데이터를 지니고 있는 소켓이 존재하는가?
	- 블로킹되지 않고 데이터의 전송이 가능한 소켓은 무엇인가?
	- 예외상황이 발생한 소켓은 무엇인가?

#include <sys/select.h>
#include <sys/time.h>

int select(
	int maxfd, fd_set *readset, fd_set *writeset, fd_set *exceptset, const struct timeval *timeout);

	-> 성공 시 0이상, 실패 시 -1 반환

	- maxfd : 검사 대상이 되는 파일 디스크립터의 수
	- readset : fd_set형 변수에 '수신된 데이터의 존재여부'에 관심 있는 파일 디스크립터 정보를 모두 등록해서 
				그 변수의 주소 값을 전달한다. 
	- writeset : fd_set형 변수에 '블로킹 없는 데이터 전송의 가능여부'에 관심 있는 파일 디스크립터를 모두 등록해서
				그 변수의 주소 값을 전달한다.
	- exceptset : fd_set형 변수에 '예외상황의 발생여부'에 관심이 있는 파일 디스크립터 정보를
				모두 등록해서 그 변수의 주소 값을 전달한다.
	- timeout : select 함수호출 이후의 무한정 블로킹 상태에 빠지지 않도록 타임아웃(time-out)
				을 설정하기 위한 인자를 전달한다.
	- 반환 값 : 오류 발생시에는 -1이 반환되고, 타임 아웃에 의한 반환시에는 0이 반환된다. 
				그리고 관심대상으로 등록된 파일 디스크립터에 해당 관심에 관련된 변화가 발생하면 
				0보다 큰 값이 반환되는데, 이 값은 변화가 발생한 파일 디스크립터의 수를 의미한다. 

이 함수의 호출과정은 
1. 
 1.1 파일 디스크립터의 설정
 1.2 검사의 범위 지정
 1.3 타임아웃의 설정
2. select함수의 호출
3. 호출결과 확인 

1.1 파일 디스크립터의 설정은 먼저 관찰하고자 하는 파일 디스크립터를 모아야 하는 것이다. 
이 때 사용되는 것이 fd_set 형 변수이다. 이 형은 0과 1로 이루어진 비트단위의 배열이다. 
여기서 비트가 1인 것이 관찰대상으로 지정된 것이다. 

fd_set형 변수에 값을 등록하거나 변경하는 작업은 다음과 같은 매크로 함수의 도움을 받는다.

	FD_ZERO(fd_set *fdset)
	인자로 전달된 주소의 fd_set형 변수의 모든 비트를 0으로 초기화

	FD_SET(int fd, fd_set *fdset)
	매개변수 fdset으로 전달된 주소의 변수에 매개변수 fd로 전달된 파일 디스크립터 정보를 등록한다. 

	FD_CLR(int fd, fd_set *fdset)
	매개변수 fdset으로 전달된 주소의 변수에서 매개변수 fd로 전달된 파일 디스크립터 정보를 삭제한다.

	FD_ISSET(int fd, fd_set *fdset)
	매개변수 fdset으로 전달된 주소의 변수에 매개변수 fd로 전달된 파일 디스크립터 정보가 있으면 양수를 반환한다. 
	이 함수는 select함수의 호출 결과를 확인하는 요도로 사용된다. 


1.2 검사의 범위 지정 
	select()함수의 호출에 앞서 다음 두 가지를 먼저 결정해야 한다.

	"파일 디스크립터의 관찰(검사) 범위는 어떻게 되지?"

	우선 범위는 select함수의 첫 번째 매개변수로 넘겨준다. 
	따라서 fd_set형 변수에 등록된 파일 디스크립터의 수를 확인할 필요가 있는데,
	파일 디스크립터의 값은 생성될 때마다 1씩 증가하기 때문에 가장 큰 파일 디스크립터의 값에
	1을 더해서 인자로 전달하면 된다. (파일 디스크립터의 값이 0에서 시작하므로)

1.3 타임아웃의 설정
	"select 함수의 타임아웃 시간을 어떻게 할까?"

	select()함수의 마지막 매개변수와 관련이 있다. 
	매개변수 선언에서 보이는 자료형 timeval은 구조체 기반의 자료형으로, 다음과 같이 정의되어 있다. 

	struct timeval
	{
		long tv_sec;		// seconds
		long tv_usec;		// micro seconds; 
	}

	원래 select함수는 관찰중인 파일 디스크립터에 변화가 생겨야 반환을 한다.
	때문에 변화가 생기지 않으면 무한정 블로킹 상태에 머물게 된다. 바로 이러한 상황을 막기 위해
	타임 아웃을 지정하는 것이다. 

	만약 타임 아웃되면, select()함수는 0을 반환한다. 
	또한 타임아웃을 설정하고 싶지 않으면 마지막 변수에 null 값을 전달한다. 

2. select()함수의 호출
	이제 그대로 하면됨.

3. 함수 호출 이후의 결과확인
	0이 아닌 양수가 반환이 되면, 그 수만큼 파일 디스크립터에 변화가 발생했음을 의미한다. 

ex)
#include <stdio.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/select.h>
#define BUF_SIZE 30

int main(int argc, char *argv[])
{
	fd_set reads, temps;
	int result, str_len;
	char buf[BUF_SIZE];
	struct timeval timeout;

	// fd_set형 변수를 초기화 하는 코드. 
	FD_ZERO(&reads);
	FD_SET(0, &reads); // 파일 디스크립터 0의 위치를 1로 설정. 즉, 표준입력에 변화가 있는지 관심을 두고 보겠다는 뜻.

	/* 이 위치에서 타임아웃을 설정하면 안된다. select()함수를 호출하기 전에 매번 구조체 변수를 초기화 해야하기 때문이다. 
	timeout.tv_sec = 5;
	timeout.ti_usec = 5000;
	*/

	while(1)
	{
		tmeps = reads;	// 미리 준비해둔 reads의 내용을 변수 temps에 복사. 원본을 유지해야 하기 때문이다. 

		timeout.tv_sec = 5; // 반복문 안의 타임아웃 설정 
		timeout.tv_usec = 0;

		result = select(1, &temps, 0, 0, &timeout); // select()함수 호출 

		if(result == -1) // 에러 시 
		{
			puts("select() error !");
			break;
		}
		else if(result == 0)	// 변화가 없을 때. 
		{
			puts("Time-out!");
		}
		else					// 변화가 있을 때. 
		{
			if(FD_ISSET(0, &temps))	// 표준입력이 맞는지 확인. 
			{
				str_len = read(0, buf, BUF_SIZE);	// 데이터를 읽어서 
				buf[str_len] = 0;
				printf("message from console : %s", buf);	// 콘솔에 출력 
			}
		}
	}
	return 0;
}

멀티플렉싱 서버의 구현

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <sys/select.h>

#define BUF_SIZE 100
void error_handling(char *buf);

int main(int argc, char *argv[])
{
	int serv_sock, clnt_sock;
	struct sockaddr_in serv_adr, clnt_adr;
	struct timeval timeout;
	fd_set reads, cpy_reads;

	socklen_t adr_sz;
	int fd_max, str_len, fd_num, i;
	char buf[BUF_SIZE];
	if(argc != 2) 
	{
		printf("Usage : %s <port> \n", argv[0]);
		exit(1);
	}

	serv_sock = socket(PF_INET, SOCK_STREAM, 0);
	memset(&serv_adr, 0, sizeof(serv_adr));
	serv_adr.sin_family = AF_INET;
	serv_adr.sin_addr.s_addr = htonl(INADDR_ANY);
	serv_adr.sin_port = htons(atoi(argv[1]));

	if(bind(serv_sock, (struct sockaddr *) & serv_adr, sizeof(serv_adr)) == -1)
		error_handling("bind() error");
	if(listen(serv_sock, 5) == -1)
		error_handling("listen() error");

	FD_ZERO(&reads);
	FD_SET(serv_sock, &reads);	// 데이터의 수신여부를 관찰하는 
								// 관찰대상에 서버 소켓이 포함되었음.
								// 참고로 클라이언트의 연결 요청도
								// 데이터의 전송을 통해서 이루어짐
								// 이후에 서버 소켓으로 수신된 
								// 데이터가 존재한다는 것은 
								// 연결요청이 있었다는 뜻으로 해석해야함.
	fd_max = serv_sock;

	while(1)
	{
		cpy_reads = reads;
		timeout.tv_sec = 5;
		timeout.tv_usec = 5000;

		if((fd_num = select(fd_max + 1, &cpy_reads, 0, 0, &timeout)) == -1)	// 무한루프 내에서 select함수가 호출
																			// 3번 4번 인자가 비어있다. 
																			// 관찰의 목적에 맞게 필요한 인자만 
																			// 전달한 것. 
			break;
		if(fd_num == 0)
			continue;

		for(i = 0; i < fd_max + 1; i++)
		{
			if(FD_ISSET(i, &cpy_reads))	// select함수의 반환값이 1이상일 때, 상태 변화가 있었던 디스크립트를 찾는다. 
			{
				if(i == serv_sock) // connection request!
									// 상태변화가 감지되면 서버 소켓에서 우선 변화가 있었는지 확인한다. 
									// 서버 소켓의 변화라면, 연결요청에 대한 수락의 과정을 진행. accept()
				{
					adr_sz = sizeof(clnt_adr);
					clnt_sock = accept(serv_sock, (struct sockaddr*) & clnt_adr, &adr_sz);
					FD_SET(clnt_sock, &reads);	// fd_set형 변수 reads에 클라이언트와 연결된 소켓의 파일 디스크립터 정보를 등록
					if(fd_max < clnt_sock)
						fd_max = clnt_sock;
					printf("connected client : %d \n", clnt_sock);
				}
				else //read message!
					// 상태변화가 발생한 소켓이 서버 소켓이 아닌 경우에 실행되는 구문.
					// 즉, 수신할 데이터가 있는 경우(연결 요청이 아닌 경우)
					// 이거나 아니면 연결 종료를 의미하는 EOF 인지 확인해야한다. 
				{
					str_len = read(i, buf, BUF_SIZE);
					if(str_len == 0) // close request! 만약에 종료 요청이라면 
					{
						FD_CLR(i, &reads);	// reads에서 소켓 정보를 삭제
						close(i);			// 소켓을 종료 
						printf("closed client : %d \n", i);	// 종료된 클라이언트 정보 출력 
					}
					else // 수신된 메시지가 문자열이라면 
					{
						write(i, buf, str_len); // echo !
					}
				}
				
			}
		}
	}
	close(serv_sock);
	return 0;
}

void error_handling(char *buf)
{
	fputs(buf, stderr);
	fputc('\n', stderr);
	exit(1);
}