17 select보다 나은 epoll

사실 select는 오래된 함수라서 동시접속자의 수가 100을 넘기 힘들게 구현되어 있다. 
이에 대한 대안으로 epoll을 사용한다. 

select와 epoll이 다른 점은 epoll은 
"운영체제에게 관찰대상에 대한 정보를 딱 한번만 알려주고서,
관찰대상의 범위, 또는 내용에 변경이 있을 때 
변경 사항만 알려주도록" 하는 함수라는 점이다. 

epoll의 장점
 - 상태변화의 확인을 위한, 전체 파일 디스크립터를 대상으로 하는 반복문이 필요 없다. 
 - select함수에 대응하는 epoll_wait함수 호출시, 관찰대상의 정보를 매번 전달할 필요가 없다. 

epoll의 구현에 필요한 함수
	epoll_create	// epoll 파일 디스크립터 저장소 생성
	epoll_ctl 		// 저장소에 파일 디스크립터 등록 및 삭제 
	epoll_wait 		// selecct 함수와 마찬가지로 파일 디스크립터의 변화를 대기한다. 

epoll 방식에서는 파일 디스크립터의 저장을 운영체제가 담당한다. 
때문에 파일 디스크립터의 저장을 위한 저장소의 생성을 운영체제에게 요청해야 하는데, 
이 때 사용되는 함수가 'epoll_create'이다.  

그리고 관찰대상인 파일 디스크립터의 추가, 삭제를 위해서 'epoll_ctl' 함수를 통해서 
운영체제에게 요청하는 방식으로 이루어진다. 

1. epoll_create
#include <sys/epoll.h>

int epoll_create(int size);
	-> 성공 시 epoll 파일 디스크립터, 실패 시 -1 반환 // 이 파일 디스크립터는 epoll 인스턴스를 구분하기 위해 사용됨. 

	- size : epoll 인스턴스의 크기 정보 // 전달된 크기의 epoll 인스턴스가 생성되는 것이 아니라, 운영체제가 참고 할 뿐. 
										// 전달인자는 완전히 무시된다. 

2. epoll_ctl
#include <sys/epoll.h>

int epoll_ctl(int epfd, int op, int fd, struct epoll_event *event);
	-> 성공 시 0, 실패 시 -1 반환 

	- epfd : 관찰 대상을 등록할 epoll 인스턴스의 파일 디스크립터. 
	- op : 관찰대상의 추가, 삭제 또는 변경여부 지정
	- fd : 등록할 관찰 대상의 파일 디스크립터.
	- event : 관찰대상의 관찰 이벤트 유형  // 원래는 이벤트가 발생한 파일 디스크립터를 묶는 용도로 사용되는 
										   // 자료형이지만, 여기서는 이벤트의 유형을 등록하는 용도로 사용된다. 


	ex) 
	epoll_ctl(A, EPOLL_CTL_ADD, B, C); 
	"epoll 인스턴스 A에 파일 디스크립터 B를 등록하되, C를 통해 전달된 이벤트의 관찰을 목적으로 등록을 진행"

	epoll_ctl(A, EPOLL_CTL_DEL, B, NULL);
	"epoll 인스턴스 A에서 파일 디스크립터 B를 삭제한다."

	epoll_ctl(A, EPOLL_CTL_MOD, B, ..);
	"등록된 파일 디스크립터의 이벤트 발생상활을 변경한다."

epoll의 구현에 필요한 구조체
struct epoll_event
{
	__uint32_t events;
	epoll_data_t data;
}

typedef union epoll_data
{
	void * ptr;
	int fd;
	__uint32_t u32;
	__uint64_t u64;
} epoll_data_t;

epoll_event를 기반으로 상태변화가 발생한(이벤트가 발생한) 파일 디스크립터가 별도로 묶인다. 
	
	epoll_event의 멤버인 events에 저장 가능한 상수와 유형
	- EPOLLIN		수신할 데이터가 존재하는 상황
	- EPOLLOUT 		출력버퍼가 비워져서 당장 데이터를 전송할 수 있는 상황
	- EPOLLPRI		OOB 데이터가 수신된 상황
	- EPOLLRDHUP	연결이 종료되거나 Half-close가 진행된 상황, 이는 엣지 트리거 방식에서 유용
	- EPOLLERR		에러가 발생한 상황 
	- EPOLLET 		이벤트의 감지를 엣지 트리거 방식으로 동작시킨다. 
	- EPOLLONESHOT	이벤트가 한 번 감지되면, 해당 파일 디스크립터에서는 더 이상 이벤트를
					발생시키지 않는다. 따라서 epoll_ctl 함수의 두 번째 인자로 
					EPOLL_CTL_MOD을 전달해서 이벤트를 재설정해야한다. 

epoll_wait
기본적으로 이 함수가 epoll 관련 함수 중에서 가장 마지막에 호출된다. 

#include <sys/epoll.h>

int epoll_wait(int epfd, struct epoll_event * events, int maxevents, int timeout);
	-> 성공 시 이벤트가 발생한 파일 디스크립터 수, 실패 시 -1 반환 

	- epfd : 이벤트의 발생의 관찰영역인 epoll 인스턴스의 파일 디스크립터. 
	- events : 이벤트가 발생한 파일 디스크립터가 채워질 버퍼의 주소 값.
	- maxevents : 두 번째 인자로 전달된 주소 값의 버퍼에 등록 가능한 최대 이벤트 수
	- timeout : 1/1000초 단위의 대기시간, -1 전달 시, 이벤트가 발생할 때까지 무한 대기. 

	ex)
	int event_cnt;
	struct epoll_event *ep_events;
	....
	ep_events = malloc(sizeof(struct epoll_event) *EPOLL_SIZE); // EPOLL_SIZE는 매크로 상수 값
	....
	event_cnt = epoll_wait(epfd, ep_events, EPOLL_SIZE, -1);
	....

	함수 호출 후에는 이벤트가 발생한 파일 디스크립터의 수가 반환되고, 두 번째 인자로 
	전달된 주소 값의 버퍼에는 이벤트가 발생한 파일 디스크립터의 정보가 별도 묶이기 때문에
	select 방식에서 보인 전체 파일 디스크립터를 대상으로 하는 반복문의 삽입이 불필요하다. 


epoll 기반의 에코 서버

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/epoll.h>

#define BUF_SIZE 100
#define EPOLL_SIZE 50
void error_handling(char *buf);

int main(int argc, char *argv[])
{
	int serv_sock, clnt_sock;
	struct sockaddr_in serv_adr, clnt_adr;
	socklen_t adr_sz;
	int str_len, i;
	char buf[BUF_SIZE];

	struct epoll_event *ep_events;
	struct epoll_event event;
	int epfd, event_cnt;

	if(argc != 2)
	{
		printf("Usage : %s <port>\n", argv[0]);
		exit(1);
	}

	serv_sock = socket(PF_INET, SOCK_STREAM, 0);
	memeset(&serv_adr, 0, sizeof(serv_adr));
	serv_adr.sin_family = AF_INET;
	serv_adr.sin_addr.s_addr = htonl(INADDR_ANY);
	serv_adr.sin_port = htons(atoi(argv[1]));

	if(bind(serv_sock, (struct sockaddr*) &serv_adr, sizeof(serv_adr)) == -1)
		error_handling("bind() error");
	if(listen(serv_sock, 5) == -1)
		error_handling("listen() error");

	epfd = epoll_create(EPOLL_SIZE);
	ep_events = malloc(sizeof(struct epoll_event)*EPOLL_SIZE);

	event.events = EPOLLIN;
	evnet.data.fd = serv_sock;
	epoll_ctl(epfd, EPOLL_CTL_ADD, serv_sock, &event);

	while(1)
	{
		event_cnt = epoll_wait(epfd, ep_events, EPOLL_SIZE, -1);
		if(evnet_cnt == -1)
		{
			puts("epoll_wait() error");
			break;
		}

		for(i = 0; i < event_cnt; i++)
		{
			if(ep_events[i].data.fd == serv_sock)
			{
				adr_sz = sizeof(clnt_adr);
				clnt_sock = accept(serv_sock, (struct sockaddr*)&clnt_adr, &adr_sz);
				event.events = EPOLLIN;
				event.data.fd = clnt_sock;
				epoll_ctl(epfd, EPOLL_CTL_ADD, clnt_sock, &event);
				printf("connected client : %d \n", clnt_sock);
			}
			else
			{
				str_len = read(ep_events[i].data.fd, buf, BUF_SIZE);
				if(str_len == 0) // close request !
				{
					epoll_ctl(epfd, EPOLL_CTL_DEL, ep_events[i].data.fd, NULL);
					close(ep_events[i].data.fd);
					printf("closed client : %d \n", ep_events[i].data.fd);
				}
				else 
				{
					write(ep_events[i].data.fd, buf, str_len); // echo !
				}
			}
		}
	}
	close(serv_sock);
	close(epfd);
	return 0;
}

void error_handling(char *buf)
{
	fputs(buf, stderr);
	fputc('\n', stderr);
	exit(1);
}

17-2 레벨 트리거(Level Trigger)와 엣지 트리거(Edge Trigger)
epoll이 작동하는 2가지 방식이다. 

레벨 트리거와 엣지 트리거의 차이는 이벤트가 발생하는 시점에 있다. 

레벨 트리거 방식에서는 입력버퍼에 데이터가 남아있는 동안에 계속해서 이벤트가 등록된다. 
예를 들어 서버의 입력버퍼로 50바이트의 데이터가 수신되면, 일단 서버측 운영체제는 이벤트를
이벤트로 등록한다(변화가 발생한 파일 디스크립터로 등록한다.). 
그런데 서버 프로그램에서 20바이트를 수신해서 입력버퍼에 30바이트만 남는다면, 
이 상황 역시 이벤트로 등록이 된다. 

반대로 엣지 트리거는 입력버퍼로 데이터가 수신된 상황에서 딱 ! 한번만
이벤트가 등록된다. 때문에 입력버퍼에 데이터가 남아있다고 해서 이벤트를 추가로 등록하지 않는다. 

레벨트리거 방식 서버 예제
ex)
#define BUF_SIZE 4	// read 함수 호출 시 사용할 버퍼의 크기를 4바이트로 축소
					// 입력버퍼가 수신된 데이터를 한번에 읽어 들이지 못하게 하기 위함.
					// 즉, read 함수 호출 이후에도 입력버퍼에는 여전히 읽어 들일 데이터가 존재할 것이고, 
					// 이로 인해 새로운 이벤트가 등록되어서 epoll_wait 함수가 반환을 한다면,
					// 문자열 "return epoll_wait" 이 반복 출력될 것이다. 
#define EPOLL_SIZE 50
void error_handling(char *buf);

int main(int argc, char *argv[])
{
	int serv_sock, clnt_sock;
	struct sockaddr_in serv_adr, clnt_adr;
	socklen_t adr_sz;
	int str_len, i;
	char buf[BUF_SIZE];

	struct epoll_event *ep_events;
	struct epoll_event event;
	int epfd, event_cnt;

	if(argc != 2)
	{
		printf("Usage : %s <port> \n", argv[0]);
		exit(1); 
	}

	serv_sock = socket(PF_INET, SOCK_STREAM, 0);
	memset(&serv_adr, 0, sizeof(serv_adr));
	serv_adr.sin_family = AF_INET;
	serv_adr.sin_addr.s_addr = htonl(INADDR_ANY);
	serv_Adr.sin_port = htons(atoi(argv[1]));

	if(bind(serv_sock, (struct sockaddr*) &serv_adr, sizeof(serv_adr)) == -1)
		error_handling("bind() error");
	if(listen(serv_sock, 5) == -1)
		error_handling("lisetn() error");

	epfd = epoll_create(EPOLL_SIZE);
	ep_events = malloc(sizeof(struct epoll_event) * EPOLL_SIZE);

	event.events = EPOLLIN;
	evnet.data.fd = serv_sock;
	epoll_ctl(epfd, EPOLL_CTL_ADD, serv_sock, &event);

	while(1)
	{
		event_cnt = epoll_wait(epfd, ep_events, EPOLL_SIZE, -1);
		if(event_cnt == -1)
		{
			puts("epoll_wait() error");
			break;
		}

		puts("return epoll_wait");	// epoll_wait 함수의 호출횟수를 확인하기 위한 문장 삽입. 

		for(i = 0; i < event_cnt; i++)
		{
			if(ep_events[i].data.fd == serv_sock)
			{
				adr_sz = sizeof(clnt_adr);
				clnt_sock = accept(serv_sock, (struct sockaddr*)&clnt_adr, &adr_sz);
				event.events = EPOLLIN;
				event.data.fd = clnt_sock;
				epoll_ctl(epfd, EPOLL_CTL_ADD, clnt_sock, &event);
				pritnf("connected client :  %d \n", clnt_sock);
			}
			else
			{
				str_len = read(ep_evnets[i].data.fd, buf, BUF_SIZE);
				if(str_len == 0) // close request
				{
					epoll_ctl(epfd, EPOLL_CTL_DEL, ep_events[i].data.fd, NULL);
					close(ep_events[i].data.fd);
					printf("closed client : %d \n", ep_events[i].data.fd);
				}
				else
				{
					write(ep_events[i].data.fd, buf, str_len); // echo ! 
				}
			}
		}
	}
	close(serv_sock);
	close(epfd);
	return 0;
}

* select 함수는 레벨 트리거 방식으로 동작한다. 

엣지 트리거 기반의 서버 구현 . 

* 미리 알아야할 것 2 가지.
 - 변수 errno을 이용한 오류의 원인을 확인하는 방법.
 - 넌-블로킹(Non-blocking) IO를 위한 소켓의 특성을 변경하는 방법. 

 *일반적으로 리눅스에서 소켓관련 함수는 오류가 날 경우 -1을 리턴하는데, 
  이것만 가지고는 어떤 에러인지 알 수가 없다. 
  그래서 int errno; 라는 변수에 접근하면 알 수 있는데, 
  사용하기 전에 헤더에 error.h를 포함해야한다. 
  그리고 함수 별로, 오류 발생시 변수 errno에 저장되는 값이 다르다. 

  그래서 하고 싶은 말은, 
  "read 함수는 입력버퍼가 비어서 더 이상 읽어 들일 데이터가 없을 때 -1을 반환하고, 이 때 
  errno에는 상수 EAGAIN가 저장된다."


  소켓을 넌-블러킹 모드로 변경하는 법. 
  아래 함수를 사용한다. 
  #include <fcntl.h>

  int fcntl(int filedes, int cmd, ...);
  	-> 성공 시 매개변수 cmd에 따른 값, 실패 시 -1 반환

  	- filedes : 특성 변경의 대상이 되는 파일의 파이 ㄹ디스큷터 전달. 
  	- cmd 	  : 함수 호출의 목적에 해당하는 정보 전달.

  	이 함수는 가변인자의 형태로 정의되어 있다. 

  	ex)
	int flag = fcntl(fd, F_GETFL, 0);	// 기존의 특성 정보를 얻어오고, 
	fcntl(fd, F_SETFL, flag|O_NONBLOCK);	// 거기에 넌 블러킹 입출력을 더해서 특성을 재설정해주고 있다. 


엣지 트리거 기반의 에코 서버 구현 

왜 에러에 대해 이야기 했나? 

"엣지 트리거 방식에는 데이터가 수신되면 딱 한번 이벤트가 등록된다."
이렇기 때문에, 일단 입력과 관련해서 이벤트가 발생하면, 입력버퍼에 저장된 데이터를 전부 읽어야한다.
따라서 앞서 설명한 다음 내용을 기반으로 입력버퍼가 비어있는지 확인해야한다.

"read 함수가 -1을 반환하고, 변수 errno에 저장된 값이 EAGAIN이라면 더 이상 읽어 들일 데이터가 존재하지 않는상황"

그럼 소켓을 넌-블러킹 모드로 만드는 이유는 뭔가?

엣지 트리거 방식의 특성상 블로킹 방식으로 동작하는 read & write 함수의 호출은 서버를 오랜 시간 멈추는 
상황으로까지 이어지게할 수 있다. 그렇기 때문에 반드시 넌-블라킹 소켓을 기반으로 read&write 함수를 호출해야 한다. 

ex) 엣지 트리거 서버 
#include <fcntl.h>
#include <errno.h>
#define BUF_SIZE 4
#define EPOLL_SIZE 50
void setnonblockingmode(int fd);
void setnonblockingmode(int fd)
{
	int flag = fcntl(fd, F_GETFL, 0);
	fcntl(fd, F_SETFL, flag|O_NONBLOCK);
}

void error_handling(char *buf);

int main(int argc, char *argv[])
{
	int serv_sock, clnt_sock;
	struct sockaddr_in serv_adr, clnt_adr;
	socklen_t adr_sz;
	int str_len, i;
	char buf[BUF_SIZE];

	struct epoll_event *ep_events;
	struct epoll_event event;
	int epfd, event_cnt;

	if(argc != 2)
	{
		printf("Usage : %s <port> \n", argv[0]);
		exit(1); 
	}

	serv_sock = socket(PF_INET, SOCK_STREAM, 0);
	memset(&serv_adr, 0, sizeof(serv_adr));
	serv_adr.sin_family = AF_INET;
	serv_adr.sin_addr.s_addr = htonl(INADDR_ANY);
	serv_Adr.sin_port = htons(atoi(argv[1]));

	if(bind(serv_sock, (struct sockaddr*) &serv_adr, sizeof(serv_adr)) == -1)
		error_handling("bind() error");
	if(listen(serv_sock, 5) == -1)
		error_handling("lisetn() error");

	epfd = epoll_create(EPOLL_SIZE);
	ep_events = malloc(sizeof(struct epoll_event) * EPOLL_SIZE);

	setnonblockingmode(serv_sock);
	event.events = EPOLLIN;
	evnet.data.fd = serv_sock;
	epoll_ctl(epfd, EPOLL_CTL_ADD, serv_sock, &event);

	while(1)
	{
		event_cnt = epoll_wait(epfd, ep_events, EPOLL_SIZE, -1);
		if(event_cnt == -1)
		{
			puts("epoll_wait() error");
			break;
		}

		puts("return epoll_wait");	// epoll_wait 함수의 호출횟수를 확인하기 위한 문장 삽입. 

		for(i = 0; i < event_cnt; i++)
		{
			if(ep_events[i].data.fd == serv_sock)
			{
				adr_sz = sizeof(clnt_adr);
				clnt_sock = accept(serv_sock, (struct sockaddr*)&clnt_adr, &adr_sz);
				setnonblockingmode(clnt_sock);
				event.events = EPOLLIN;
				event.data.fd = clnt_sock;
				epoll_ctl(epfd, EPOLL_CTL_ADD, clnt_sock, &event);
				pritnf("connected client :  %d \n", clnt_sock);
			}
			else
			{
				str_len = read(ep_evnets[i].data.fd, buf, BUF_SIZE);
				if(str_len == 0) // close request
				{
					epoll_ctl(epfd, EPOLL_CTL_DEL, ep_events[i].data.fd, NULL);
					close(ep_events[i].data.fd);
					printf("closed client : %d \n", ep_events[i].data.fd);
					break;
				}
				else if(str_len < 0)
				{
					if(errno == EAGAIN)
						brak;
				}
				else
				{
					write(ep_events[i].data.fd, buf, str_len); // echo ! 
				}
			}
		}
	}
	close(serv_sock);
	close(epfd);
	return 0;
}

레벨 트리거와 엣지 트리거 중에 뭐가 더 좋은건가? 
딱히 엣지 트리거의 장점이 없어보이지만, 
"데이터의 수신과 데이터가 처리는 시점을 분리할 수 있다!." 
라는 점에서 강력한 장점을 지니고 있다. 

물론 상황에 따라 다르기 때문에 어느 것이 무조건 더 좋다고 할 수 없다. 
