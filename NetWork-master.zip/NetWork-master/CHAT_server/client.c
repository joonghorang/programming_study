#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#define BUF_SIZE 30

void error_handling(char *message)
{
	fputs(message, stderr);
	fputc('\n', stderr);
	exit(1);
}

void read_routine(int sock, char *buf)
{
	while(1)
	{
		int str_len = read(sock, buf, BUF_SIZE); 	// 소켓에 있는 내용을 버퍼사이즈만큼 버퍼에 넣는다. 
													// 그리고 읽은 길이를 str_len에 저장.
		if(str_len == 0) 							//다 읽었으면 str_len은 0일테니 무한 반복문을 탈출.
			return;

		buf[str_len] = 0;
		printf("Somebody : %s", buf); 	// 내용을 출력
	}
}

void write_routine(int sock, char *buf)
{
	while(1)
	{
		fgets(buf, BUF_SIZE, stdin); // 사용자 입력으로부터 버퍼사이즈만큼 buf에 넣는다.
		if(!strcmp(buf, "q\n") || !strcmp(buf, "Q\n")) 
		{
			shutdown(sock, SHUT_WR);
			return;
		}
		write(sock, buf, strlen(buf)); //입력받은 내용을 buf에 들어있는 길이만큼  소켓을 통해 쓴다.
	}
}

int main(int argc, char* argv[])
{
	int sock;
	pid_t pid;
	char buf[BUF_SIZE];
	char bufTemp[BUF_SIZE];

	struct sockaddr_in server_address;
	
	if(argc != 3)
	{
		printf("Usage : %s <IP> <port> \n", argv[0]);
		exit(1);
	}

	sock = socket(PF_INET, SOCK_STREAM, 0);
	if(sock == -1)
		error_handling("socket() error");

	memset(&server_address, 0, sizeof(server_address));
	server_address.sin_family = AF_INET;
	server_address.sin_addr.s_addr = inet_addr(argv[1]); // 사용자에게 입력받은 첫번째 인자를 iP주소로 할당
	server_address.sin_port = htons(atoi(argv[2])); 	// 입력받은 두번째 인자를 포트번호로 할당
			
	if(connect(sock, (struct sockaddr*)&server_address, sizeof(server_address)) == -1)
		error_handling("connect() error");
	else
		printf("Connect Success!\n");


	pid = fork();
	if(pid == 0) // 자식프로세스라면
		write_routine(sock, buf); // 소켓을 통해 buf만큼 쓴다. 
				
	else
		read_routine(sock, bufTemp); // 소켓을 통해 buf만큼 읽는다. 

	close(sock);
	return 0;
}
