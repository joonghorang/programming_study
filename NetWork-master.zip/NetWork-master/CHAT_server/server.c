#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>		 // 다중접속을 위해 추가
#include <sys/wait.h> 	// 다중접속을 위해 추가 
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/epoll.h>
#include <fcntl.h>

#define BUF_SIZE 100
#define EPOLL_SIZE 50

void error_handling(char *message)
{
	fputs(message, stderr);
	fputc('\n', stderr);
	exit(1);
}
int main(int argc, char *argv[])
{
	int server_socket;
	int client_socket;
	struct sockaddr_in server_address;
	struct sockaddr_in client_address;

	socklen_t address_size;
	int str_len;
	int i;

	char buf[BUF_SIZE];

	struct epoll_event *ep_events;
	struct epoll_event event;
	int epfd, event_count;

	int client_number = 0;
	int client_socket_array[BUF_SIZE];

	if(argc != 2)
	{
		printf("Wrong Input, %s please input <port> number. \n", argv[0]);
		exit(1);
	}

	server_socket = socket(PF_INET,SOCK_STREAM, 0);
	if(server_socket == - 1) // error handling
		error_handling("socket() error");

	memset(&server_address, 0, sizeof(server_address));
	server_address.sin_family = AF_INET;
	server_address.sin_addr.s_addr = htonl(INADDR_ANY);
	server_address.sin_port = htons(atoi(argv[1])); // 입력받은 포트번호를 소켓에 지정

	if(bind(server_socket, (struct sockaddr*) &server_address, sizeof(server_address)) == -1)
		error_handling("bind() error");

	if(listen(server_socket, 5) == -1)
		error_handling("listen() error");

	epfd = epoll_create(EPOLL_SIZE);
	ep_events = malloc(sizeof(struct epoll_event)*EPOLL_SIZE);

	void setnonblockingmode(int fd)
	{
		int flag = fcntl(fd, F_GETFL, 0);
		fcntl(fd, F_SETFL, flag|O_NONBLOCK);
	}
	setnonblockingmode(server_socket);
	event.events = EPOLLIN;
	event.data.fd = server_socket;
	epoll_ctl(epfd, EPOLL_CTL_ADD, server_socket, &event);

	while(1) //반복적으로 입력을 받고 출력해주기 위해 무한 루프를 생성
	{
		event_count = epoll_wait(epfd, ep_events, EPOLL_SIZE, -1);

		if(event_count  == -1)
		{
			puts("epoll_wait() error");
			break;
		}

		for(i = 0; i < event_count; i++)
		{
			if(ep_events[i].data.fd == server_socket)
			{
				address_size = sizeof(client_address);
				client_socket_array[client_number] = accept(server_socket, (struct sockaddr*)&client_address, &address_size);
				event.events = EPOLLIN;
				event.data.fd = client_socket_array[client_number];
				epoll_ctl(epfd, EPOLL_CTL_ADD, client_socket_array[client_number], &event);
				printf("connectd client : %d, client No : %d \n", client_socket_array[client_number], client_number++);
			}
			else
			{
				str_len = read(ep_events[i].data.fd, buf, BUF_SIZE);
				
				if(str_len == 0) // close request
				{
					epoll_ctl(epfd, EPOLL_CTL_DEL, ep_events[i].data.fd, NULL);
					close(ep_events[i].data.fd);
					printf("closed client : %d \n", ep_events[i].data.fd);
				}

				int j;
				for(j = 0; j < client_number; j++)
				{
					write(client_socket_array[j], buf, str_len);
				}
			}
		}
	}
	close(server_socket);
	close(epfd);
	return 0;
}

