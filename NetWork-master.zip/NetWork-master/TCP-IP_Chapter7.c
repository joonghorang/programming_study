UDP 기반 서버/ 클라이언트

UDP 소켓의 특성

	편지를 보내기 위해서는 일단 편지봉투에다가 보내는 사람과 받는 사람의 주소정보를 써 넣어야 한다. 
	그리고 우표를 붙여서 우체통에 넣어주면 끝이다. 

	"다만 수신여부를 확인할 길은 없다."

	즉, 편지는 신뢰할 수 없는 전송 방법이다. 

	UDP 소켓은 신뢰할 수 없는 전송 방법을 제공한다. 
	하지만 UDP는 훨씬 간결한 구조로 설계되어 있다. 
	그리고 데이터 손실이 생각보다 자주 발생하는 것은 아니다. 
	신뢰성보다 성능이 중요시되는 상황에 사용한다. 

	TCP는 신뢰성 없는 IP를 기반으로 신뢰성 있는 데이터의 송수신을 위해서 '흐름제어(Flow Contro)'
	를 한다고 설명했는데, 바로 이 흐름제어가 UDP에는 존재하지 않는다. 

	그것이 UDP와 TCP의 유일한 차이이다. 

UDP의 효율적 사용

	"UDP에서 서버와 클라이언트는 연결되어 있지 않다."

	따라서 연결 설정의 과정이 필요 없다. 
    서버의 listen()과 accept() 함수의 호출이 불필요하다.;
	
	"UDP에서는 서버건 클라이언트건 하나의 소켓만 있으면 된다."
	즉, 여기서 하나의 소켓은 바로 우체통이다. 받는 것도 우체통으로, 보내는 것도 같은 우체통으로 하면 된다. 

	따라서 연결 상태를 유지하는 것이 아니므로, 
	데이터를 전송할 때 
	반드시, 목적지의 주소정보를 별도로 추가해야 한다. 

	이를 추가해서 데이터를 전송해 주는 함수는 

	#include <sys/socket.h>

	ssize_t sendto(int sock, void *buff, size_t nbytes, int flas,
										struct sockaddr *to, sockeln_t addrlen);

	- sock : 데이터 전송에  사용될 UDP 소켓의 파일 디스크립터를 인자로 전달.
	- buff : 전송할 데이터를 저장하고 있는 버퍼의 주소 값 전달.
	- nbytes : 전송할 데이터 크기를 바이트 단위로 전달. 
	- flags : 옵션 지정에 사용되는 매개변수, 지정할 옵션이 없다면 0 전달.
	- to : 목적지 주소정보를 담고 있는 sockaddr 구조체 변수의 주소 값 전달. // tcp방식과 다른 점.
	- addrlen : 매개변수 to로 전달된 주소 값의 구조체 변수 크기 전달.

	반대로 데이터를 수신해 주는 함수는

	ssize_t recvfrom(int sock, void *buff, size_t nbytes, int flags, 
											struct sockaddr *from, socklen_t *addrlen);

	- sock : 데이터 수신에 사용될 UDP 소켓의 파일 디스크립터를 인자로 전달. 
	- buff : 데이터 수신에 사용될 버퍼의 주소 값 전달.
	- nbytes : 수신할 최대 바이트 수 전달, 때문에 매개변수 buff가 가리키는 버퍼의 크기를 넘을 수 없다. 
	- flags : 옵션 지정에 사용되는 매개변수, 지정할 옵션이 없다면 0 전달.
	- from : 발신지 정보를 채워 넣을 sockaddr 구조체 변수의 주소 값 전달.
	- addrlen : 매개변수 from으로 전달된 주소 값의 구조체 변수의 크기 전달. 

UDP 기반의 에코 서버
ex)

#include <stdio.h>
#include <stdlbi.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>

#define BUF_SIZE 30
void error_handling(char *message);

int main(int argc, chgar *argv[])
{
	int ser_sock;
	char message[BUF_SIZE];
	int str_len;
	socklen_t clnt_ar_sz;

	struct sockaddr_in serv_adr, clnt_adr;
	if(argc != 2){
		printf("Usage : %s <port>\n", argv[0]);
		exit(1);
	}

	serv_sock = socket(PF_INET, SOCK_DGRAM, 0); // UDP 설정을 위해 인자로 SOCK_DGRAM을 인자로 전달
	if(serv_sock == -1)
		error_handling("UDP socket creation error");

	memset(&serv_adr, 0, sizeof(serv_adr));
	serv_adr.sin_family = AF_INET;
	serv_adr.sin_addr.s_addr=htonl(INADDR_ANY);
	serv_adr.sin_port=htons(atoi(argv[1]));

	if(bind(serv_sock, (struct sockaddr*)&serv_adr, sizeof(serv_ard)) == -1)
		error_handling("bind() error");

	while(1)
	{
		clnt_adr_sz = sizeof(clnt_adr);
		str_len=recvfrom(serv_sock, message, BUF_SIZE, 0,
			(struct sockaddr*)&clnt_adr, &clnt_adr_sz);	// bind()된 주소로 전달되는 모든 데이터를 수신.	
														// 물론 데이터의 전달대상에는 제한이 없다. 
		sendto(serv_sock, message, str_len, 0,			// recvfrom()에 의하여 데이터를 전송한 이의 주소정보도
														// 들어오게 되는데, 바로 이 주소정보를 역이용하여
														// 데이터를 역으로 재전송하고 있다. 
			(struct sockaddr*)&clnt_adr, clnt_adr_sz);
	}
	close(serv_sock);	// 위의 문장이 무한 루프이기 때문에 이 코드는 사실상 실행되지 않는다. 
	return 0;
}

void error_handling(char *message)
{
	fputs(message, stderr);
	fputc('\n', stderr);
	exit(1);
}


클라인트 코드

#include <stdio.h>
#include <stdlbi.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#define BUF_SZIE 30
void error_handling(char *message);

int main(injt argc, char *argv[])
{
	int sock;
	char messgae[BUF_SIZE];
	int str_len;
	socklen_t adr_sz;

	struct sockaddr_in serv_adr, from_adr;
	if(argc!=3)
	{
		printf("Usage : %s <IP> <port>\n", argv[0]);
		exit(1);
	}

	sock = socket(PF_INET, SOCK_DGRAM, 0);	// UDP 소켓 생성
	if(sock == -1)
		error_handling(socket() error);

	memset(&serv_adr, 0, sizeof(serv_adr));
	serv_adr.sin_family = AF_INET;
	serv_adr.sin_addr.s_addr = inet_addr(argv[1]);
	serv_adr.sin_port=htons(atoi(argv[2]));

	while(1)
	{
		fputs("Insert message(q to quit) : ", stdout);
		fgets(message, sizeof(message), stdin);
		if(!strcmp(message,"q\n") || !strcmp(messgae,"Q\n"))
			break;

		sendto(sock, message, strlne(message), 0,				// 서버로 데이터 전송 
			(struct sockaddr*)&serv_adr, sizeof(serv_adr));
		ard_sz=sizeof(from_adr);
		str_len=recvfrom(sock, message, BUF_SIZE, 0,			// 데이터를 수신 
						(struct sockaddr*)&from_adr, &adr_sz);
		message[str_len] = 0;
		printf("Message from server : %s", message);
	}
	close(sock);
	return 0;
}

void error_handling(char *message)
{
	fputs(message, stderr);
	fputc('\n', stderr);
	exit(1);
}

위 코드에는 소켓에 IP와 PORT를 할당하는 부분이 없는데, 어떻게 된 걸까?
(TCP의 경우에는 connect함수호출 시 자동으로 할당됨.)
UDP는 sendto() 함수 호출 시 IP와 PORT번호가 자동으로 할당되기 때문에, 별도의 과정이 없다. 

sendto() 함수는 크게 세 가지 일을 하는데, 
1. UDP소켓에 목적지의 IP와 PORT번호 등록
2. 데이터 전송
3. UDP 소켓에 등록된 목적지 정보 삭제 

06-3 UDP의 데이터 송수신 특성과 UDP에서의 connect 함수 호출 

TCP는 데이터에 경계가 존재하지 않아서, 데이터 송수신 과정에 호출하는 
입출력 함수의 호출횟수는 큰 의미를 지니지 않는다.

반면 UDP는 데이터의 경계가 존재하는 프로토콜이므로, 데이터 송수신 과정에서 호출하는 
입출력 함수의 호출횟수가 큰 의미를 지닌다. 
이 말은 입력함수의 호출횟수와 출력함수의 호출횟수가 정확히 일치해야 데이터를 전부 수신한 것이다. 

또한 UDP는 데이터의 경계가 존재하기 때문에 하나의 패킷이 하나의 데이터로 간주된다. 

만약에 connected UDP 소켓을 만들고 싶으면
connect 함수만 호출해 주면 된다. 

ex)
connect(sock, (struct sockaddr*)&adr, sizeof(adr));

