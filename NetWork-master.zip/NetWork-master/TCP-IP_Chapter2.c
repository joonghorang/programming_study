02-1 소켓의 프로토콜과 그에 따른 데이터 전송 특성

소켓의 생성
#include <sys/socket.h>

int socket(int domain, 		// 소켓이 사용할 프로토콜 체계 (Protoco Family정보) 전달
								//PF_INET, PF_INET6, PF_LOCAL등
			int type, 		// 소켓의 데이터 전송방식에 대한 정보 전달
								// SOCK_STREAM(연결지향형 소켓), SOCK_DGRAM(비 연결 지향형 소켓)
			int protocol, 	// 하나의 프로토콜 체계 안에 데이터 전송방식이 동일한 프로토콜이 둘 이상
							// 존재하는 경우에 사용한다. 
								// IPPROTO_TCP, IPPROTO_UDP 등.

			);