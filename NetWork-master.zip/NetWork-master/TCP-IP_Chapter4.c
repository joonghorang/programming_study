TCP 기반 서버 / 클라이언트 1

연결 지향형 소켓 기반의 서버 클라이언트 짜보기 

TCP(Transmission Control Protocol) 소켓의 경우 연결을 지향하기 때문에 '스트림 기반 소켓'이라고도 한다. 

TCP/IP 계층은 총 4개의 영역으로 계층화 되어 있는데,
1. Application 계층 	// 2단계까지의 업적으로 소켓이 주어졌는데, 
						// 클라이언트 소켓과 서버 소켓간의 데이터 송수신에 대한 
						// 약속들. 이를 가리켜 APPLICATION 프로토콜이라고 한다. 
2. TCP 또는 UDP 계층 	// 데이터 전송 방식의 표준화 TCP 전송에 기반이 되는 프로토콜이 IP.
						// IP는 원래 하나의 데이터 패킷이 전송되는 과정에만 중심을 두고 설계되었다. 
						// 따라서 여러 개를 전송할 때 IP만을 사용하면 패킷이 도착하는 순서가 꼬이거나 파손 될 수 있다. 
						// 이런 걸 관리해 주는 것이 TCP이다. 

3. IP 계층 				// 경로 검색 방식의 표준화
4. LINK 계층 			// 물리적 연결 방식의 표준화 

TCP소켓을 사용하여 데이터를 송수신 한다면 이 네 개의 계층을 통해야 한다. 
* 똑같은 걸 OSI 7계층으로 구분하기도 한다. 하지만 프로그래머의 관점으로는 4계층으로 이해해도 충분하다. 

04-2 TCP기반 서버, 클라이언트 구현

TCP 서버의 함수호출 순서

1. socket() 			// 소켓 생성
2. bind()				// 소켓 주소 할당
3. listen()				// 연결요청 대기상태
4. accept() 			// 연결허용
5. read()/write() 		// 데이터 송수신
6. close()				// 연결종료

연결요청 대기 상태로의 진입 
#include <sys/type.h>

int listen(int sock, int backlog);

	성공 시 0, 실패 시 -1 반환

"int sock" : 연결 요청 대기상태에 두고자 하는 소켓의 파일 디스크립터 전달,
		   함수의 인자로 전달된 디스크립터의 소켓이 서버 소켓(리스닝 소켓)이 된다. 

"int backlog" : 연결요청 대기 큐(Queue)의 크기정보 전달, 5가 전달되면 큐의 크기가 5가 되어
			  클라이언트의 연결요청을 5개까지 대기시킬 수 있다. 
			  즉, 최대 대기열 수.


클라이언트의 연결 요청 수락
#include <sys/socket.h>

int accept(int sock, struct sockaddr * addr, socklen_t * addrlen);
    ->  성공 시 생성된 소켓의 파일 디스크립터, 실패 시 -1반환 
    
"int sock" : 서버 소켓의 파일 디스크립터 전달.

"struct sockaddr * addr" : 연결요청 한 클라이언트의 주소정보를 담을 변수의 주소 값 전달, 
							함수호출이 완료되면 인자로 전달된 주소의 변수에는 클라이언트의 
							주소정보가 채워진다.

"socklen_t * addrlen" : 두 번째 매개변수 addr에 전달된 주소의 변수 크기를 바이트 단위로 전달,
						단 크기정보를 변수에 저장한 다음에 변수의 주소 값을 전달한다.
						그리고 함수호출이 완료되면 크기정보로 채워져 있던 변수에는
						클라이언트의 주소정보 길이가 바이트 단위로 계산되어 채워진다. 

accept()는 연결요청 대기 큐에서 대기중인 클라이언트의 연결요청을 수락하는 기능을 한다. 

내용 쓰기
#include <sys/socket.h>

write(clnt_sock, message, sizeof(message));

ex)
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>

#define BUF_SIZE 1024

void error_handling(char *message);

int main(int argc, char *argv[])
{
    int serverSocket;
    int clientSocket;

    struct sockaddr_in serv_addr;
    struct sockaddr_in clnt_addr;
    socklen_t clnt_addr_size;

    char message[BUF_SIZE];
    int str_len, i;

    if (argc != 2)
    {
        printf("Usage : %s <port>\n", argv[0]);
        exit(1);
    }

    serverSocket = socket(PF_INET, SOCK_STREAM, 0);
    if (serverSocket == -1)
    {
        error_handling("socket() error");
    }

    memset(&serv_addr, 0, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    serv_addr.sin_port = htons(atoi(argv[1]));

    if (bind(serverSocket, (struct sockaddr*) &serv_addr, sizeof(serv_addr)) == -1)
    {
        error_handling("bind() error");
    }

    if (listen(serverSocket, 5) == -1)
    {
        error_handling("listen() error");
    }

    clnt_addr_size = sizeof(clnt_addr);

    for (i = 0; i < 5; i++)
    {
        clientSocket = accept(serverSocket, (struct sockaddr*)&clnt_addr, &clnt_addr_size);
        if (clientSocket == -1)
        {
            error_handling("accept() error");
        }
        else
        {
            printf("Conneted Client %d \n", i + 1);
        }

        while ((str_len = read(clientSocket, message, BUF_SIZE)) != 0)
        {
            write(clientSocket, message, str_len);
        }

        close(clientSocket);
    }
    close(serverSocket);
    return 0;
}

void error_handling(char* message)
{
    fputs(message, stderr);
    fputc('\n', stderr);
    exit(1);
}

TCP 클라이언트의 기본적인 함수호출 순서

1. socket() 		// 소켓생성
2. connect()		// 연결요청
3. read()/write()	// 데이터 송수신
4. close()			// 연결종료 

서버의 구현과정과 비교해서 차이가 있는 부분은 '연결 요청' 이라는 과정이다. 
연결 요청을 하려면 아래 함수를 사용한다.

#include <sys/socket.h>

int connect(int sock, const struct sockaddr * servaddr, socklen_t addrlen);
	성공 시 생성된 소켓의 파일 디스크립터, 실패 시 -1 반환

"sock" : 클라이언트 소켓의 파일 디스크립터 전달.
"servaddr" : 연결요청할 서버의 주소정보를 담은 변수의 주소 값 전달, 
			 함수호출이 완료되면 인자로 전달된 주소의 변수에는 클라이언트의 주소정보가 채워진다.
"addrlen" : 두 번째 매개변수 servaddr에 전달된 주소의 변수 크기를 바이트 단위로 전달
			단, 크기 정보를 변수에 저장한 다음에 변수의 주소 값을 전달한다.
			그리고 함수호출이 완료되면 크기정보로 채워져 있던 변수에는 클라이언트 주소정보 길이가 
			바이트 단위로 계산되어 채워진다. 

클라이언트 연결은 소켓의 주소할당 과정이 없었는데, 
이는 connect() 함수가 호출될 때 "자동으로" 운영체제에서 IP는 컴퓨터(호스트)에 할당된 내 IP로,
PORT는 임의로 선택해서 할당되었기 때문이다. 

ex)
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>

#define BUF_SIZE 1024

void error_handling(char *message);

int main(int argc, char* argv[])
{
    int sock;
    struct sockaddr_in serv_addr;
    char message[BUF_SIZE];
    int str_len;
    int recv_len, recv_cnt;

    if (argc != 3)
    {
        printf("Usage : %s <IP> <port>\n", argv[0]);
        exit(1);
    }

    sock = socket(PF_INET, SOCK_STREAM, 0);			//  서버 접속을 위한 소켓을 생성
    if (sock == -1)
    {
        error_handling("socket() error");
    }

    // serv_addr에 있는 IP와 PORT정보를 초기화, 초기화 되는 값은 연결 목적으로 하는 서버 소켓의 정보들.
    // 즉 목적지 설정 중. 
    memset(&serv_addr, 0, sizeof(serv_addr));		
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = inet_addr(argv[1]);
    serv_addr.sin_port= htons(atoi(argv[2]));

    if (connect(sock, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) == -1) // 서버로 연결 요청 
    {
        error_handling("connect() error!");
    }
    else
    {
        puts("Connected Success!!!");
    }

    while (1) // 연결요청이 성공한 후에 서버로부터 전송되는 데이터를 수신하고 있다. 
    {
        fputs("Input message(Q to quit): ", stdout);
        fgets(message, BUF_SIZE, stdin);

        if (!strcmp(message, "q\n") || !strcmp(message, "Q\n"))
            break;

        str_len = write(sock, message, strlen(message));

        recv_len = 0;
        while(recv_len < str_len)
        {
            recv_cnt = read(sock, &message[recv_len], BUF_SIZE - 1);
            if (recv_cnt == -1)
            {
                error_handling("read() error!");
            }
            recv_len += recv_cnt;
        }
        message[recv_len] = 0;
        printf("Message from server : %s \n", message);
    }
    close(sock);	// 데이터 수신 후 소켓을 닫음. 
    return 0;
}

void error_handling(char *message)
{
    fputs(message, stderr);
    fputc('\n', stderr);
    exit(1);
}

