#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#define BUF_SIZE 30

void error_handling(char *message)
{
	fputs(message, stderr);
	fputc('\n', stderr);
	exit(1);
}

void read_routine(int sock, char *buf)
{
	while(1)
	{
		int str_len = read(sock, buf, BUF_SIZE); // 소켓에 있는 내용을 버퍼사이즈만큼 버퍼에 넣는다. 
												// 그리고 읽은 길이를 str_len에 저장.
		if(str_len == 0) //다 읽었으면 str_len은 0일테니 무한 반복문을 탈출.
			return;

		buf[str_len] = 0;
		printf("Message from server : %s", buf); // 내용을 출력
	}
}

void write_routine(int sock, char *buf)
{
	while(1)
	{
		fgets(buf, BUF_SIZE, stdin); // 사용자 입력으로부터 버퍼사이즈만큼 buf에 넣는다.
		if(!strcmp(buf, "q\n") || !strcmp(buf, "Q\n")) 
		{
			shutdown(sock, SHUT_WR);
			return;
		}
		write(sock, buf, strlen(buf)); //입력받은 내용을 buf에 들어있는 길이만큼  소켓을 통해 쓴다.
	}
}

int main(int argc, char* argv[])
{
	int sock;
	pid_t pid;
	char buf[BUF_SIZE];
	char bufTemp[BUF_SIZE];

	struct sockaddr_in server_address;
//	int string_length;
//	int receive_length, receive_count;
	
	if(argc != 3)
	{
		printf("Usage : %s <IP> <port> \n", argv[0]);
		exit(1);
	}

	sock = socket(PF_INET, SOCK_STREAM, 0);
	if(sock == -1)
		error_handling("socket() error");

	memset(&server_address, 0, sizeof(server_address));
	server_address.sin_family = AF_INET;
	server_address.sin_addr.s_addr = inet_addr(argv[1]); // 사용자에게 입력받은 첫번째 인자를 iP주소로 할당
	server_address.sin_port = htons(atoi(argv[2])); 	// 입력받은 두번째 인자를 포트번호로 할당
			
	if(connect(sock, (struct sockaddr*)&server_address, sizeof(server_address)) == -1)
		error_handling("connect() error");
	else
		printf("Connect Success!");


	pid = fork();
	if(pid == 0) // 자식프로세스라면
		write_routine(sock, buf); // 소켓을 통해 buf만큼 쓴다. 
				
	else
		read_routine(sock, bufTemp); // 소켓을 통해 buf만큼 읽는다. 

	close(sock);
	return 0;
}
/*
	while(1)
	{
		fputs("Input message(Q to quit) : ", stdout);
		fgets(message, BUF_SIZE, stdin); // 입력받은 문자를 message에 버퍼사이즈만큼 저장한다. 
		if(!strcmp(message, "q\n") || !strcmp(message, "Q\n"))	// 입력받은 메시지와 q\n을 비교하여 같으면 종료
			break;

		string_length = write(sock, message, strlen(message)); // 메시지의 길이만큼 메시지를 소켓에 쓴다. 

		receive_length = 0;
		while(receive_length < string_length) // 받은 메시지가 string_length보다 작을 동안
		{
			receive_count = read(sock, &message[receive_length], BUF_SIZE -1); // 읽어들인 바이트 수를 카운트에 삽입 
			if(receive_count == -1)
				error_handling("read() error!");
			receive_length += receive_count; // 읽은 만큼 읽은 길이가 늘어난다. 
		}
		message[receive_length] = 0;
		printf("Message from server : %s", message);
	}		
	close(sock);
	return 0;
}

*/
