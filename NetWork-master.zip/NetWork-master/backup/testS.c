#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>		 // 다중접속을 위해 추가
#include <sys/wait.h> 	// 다중접속을 위해 추가 
#include <arpa/inet.h>
#include <sys/socket.h>

#define BUF_SIZE 30

void error_handling(char *message)
{
	fputs(message, stderr);
	fputc('\n', stderr);
	exit(1);
}
void error_handling(char *message);

void read_childprocess(int sig)		// 다중 접속을 위해 추가
{
	pid_t pid;
	int status;
	pid = waitpid(-1, &status, WNOHANG);
	printf("removed process id : %d \n", pid);
}
void read_childprocess(int sig);
int main(int argc, char *argv[])
{
	int server_socket;
	int client_socket;
	struct sockaddr_in server_address;
	struct sockaddr_in client_address;

	pid_t pid; // 다중 접속을 위해 추가
	struct sigaction act;
	socklen_t adr_sz;
	int str_len;
	int state;
	char bufWrite[BUF_SIZE];
	char bufRead[BUF_SIZE];
	char bufStore[BUF_SIZE];
	char bufStore1[BUF_SIZE];
	char bufStore2[BUF_SIZE];
	char bufStore3[BUF_SIZE];

	int fdsWrite[2]; // 파이프를 위한 파일 디스크립터 
	int fdsRead[2]; 
	int fds[2];
	int fds1[2];
	int fds2[2];
	int fds3[2];
	
	int client_number = 0;
	int client_socket_array[10];

	if(argc != 2)
	{
		printf("Wrong Input, %s please input <port> number. \n", argv[0]);
		exit(1);
	}

	act.sa_handler = read_childprocess; // 좀비 프로세스를 막기위한 코드.  
	sigemptyset(&act.sa_mask);
	act.sa_flags = 0;
	state = sigaction(SIGCHLD, &act, 0);


	server_socket = socket(PF_INET,SOCK_STREAM, 0);
	if(server_socket == - 1) // error handling
		error_handling("socket() error");

	memset(&server_address, 0, sizeof(server_address));
	server_address.sin_family = AF_INET;
	server_address.sin_addr.s_addr = htonl(INADDR_ANY);
	server_address.sin_port = htons(atoi(argv[1])); // 입력받은 포트번호를 소켓에 지정

	if(bind(server_socket, (struct sockaddr*) &server_address, sizeof(server_address)) == -1)
		error_handling("bind() error");

	if(listen(server_socket, 5) == -1)
		error_handling("listen() error");

	pipe(fds);
	pipe(fds1);
	pipe(fds2);
	pipe(fds3);
	int str_len2;
	int str_len3;
	int str_len1;
	
	pid = fork();
	if(pid == 0)
	{	
		FILE * fp = fopen("echomsg.txt", "wt");
		int i, len;
		for(i = 0; i < 2; i++)
		{
			str_len2 = read(fds[0], bufStore1, BUF_SIZE);
			fwrite((void*)bufStore1, 1, len, fp);
			printf("%s\n", bufStore1);
		}
		fclose(fp);
		return 0;
	}

	while(1) //반복적으로 입력을 받고 출력해주기 위해 무한 루프를 생성
	{
		adr_sz = sizeof(client_address);
		client_socket = accept(server_socket, (struct sockaddr*)&client_address, &adr_sz);
		client_socket_array[client_number++] = client_socket;
		if(client_socket == -1)
			continue;
		else
			puts("new client connected");

		pid = fork();
		puts("now Fork()");
		if(pid == -1) // 에러처리 
		{
			close(client_socket);
			continue;
		}
		if(pid == 0) // 자식 프로세스라면 
		{     
			close(server_socket);	// 클라이언트와 통신을 전담할 소켓이므로 부모소켓에 있는  서버 소켓은 닫는다. 
			
			while((str_len = read(client_socket_array[0], bufStore, BUF_SIZE))!=0)
			{
				write(client_socket_array[0], bufStore, str_len);
				write(fds[1], bufStore,  str_len);
			}
			close(client_socket);
			puts("client disconnected...");
			return 0;
		}
		else
			close(client_socket);
	}
	close(server_socket);
	return 0;
}

