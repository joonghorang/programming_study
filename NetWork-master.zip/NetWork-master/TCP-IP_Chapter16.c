16. 입출력 스트림의 분리에 대한 나머지 이야기

fopen 함수가 호출되면 '스트림'이 생성되었다고 한다. 
이는 '데이터의 송신 또는 수신을 위한 일종의 다리' 이다. 

16-1 입력 스트림과 출력 스트림의 분리 
16-2 파일 디스크립터와 복사와 Half-close

하나의 파일 디스크립터에 여러개의 파일 포인터가 물린경우 
이 중 하나라도 종료가 되면, 파일디스크립터와 소켓까지 모두 소멸된다. //fclose()

따라서 이 문제를 해결하려면 파일디스크립터를 파일 포인터의 갯수만큼 복사하면 된다. 
이렇게 되면 "모든 파일 디스크립터가 소멸되어야 소켓도 소멸된다."

파일 디스크립터를 복사하는 것은 fork() 함수와 다른데
fork는 프로세스를 통째로 복사해서 새로 생성하는 것이고,
여기서 말하는 복사는 하나의 프로세스 내에 여러개의 파일 디스크립터를 만드는 것이다. 

이를 위한 함수 dup & dup2

#include <unistd.h>

int dup(int fildes);
int dup2(int fildes, inf fildes2); // 새로 만들어진 파일디스크립터를 특정 번호에 맞출 때 사용. 
	-> 성공 시 복사된 파일 디스크립터, 실패 시 -1 반환 

	- fildes 복사할 파일 디스크립터 전달 
	- fildes2 명시적으로 지정할 파일 디스크립터의 정수 값 전달. 

파일 디스크립트를 복사한 후의 스트림 분리된 서버 예제 코드 
ex)
#define BUF_SIZE 1024

int main(int argc, char *argv[])
{
	int serv_sock, clnt_sock;
	FILE * readfp;
	FILE * writefp;

	struct sockaddr_in serv_adr, clnt_adr;
	socklen_t clnt_adr_sz;
	char buf[BUF_SIZE] = {0,};

	serv_sock = socket(PF_INET, SOCK_STREAM, 0);
	memset(&serv_adr, 0, sizeof(serv_adr));
	serv_adr.sin_family = AF_INET;
	serv_adr.sin_addr.s_addr = htonl(INADDR_ANY);
	serv_adr.sin_port = htons(atoi(argv[1]));

	bind(serv_sock, (struct sockaddr*) & serv_adr, sizeof(serv_adr));
	listen(serv_sock, 5);
	clnt_adr_sz = sizeof(clnt_adr);
	clnt_sock = accept(serv_sock, (struct sockaddr*) &clnt_adr, &clnt_adr_sz);

	readfp = fdopen(clnt_sock, "r");
	writefp = fdopen(dup(clnt_sock), "w"); // 여기서 복사하고 있다. 

	fputs("FROM SERVER : Hi client? \n", writefp);
	fputs("I love all of the world \n", writefp);
	fputs("You are awesome ! \n", writefp);
	fflush(writefp);

	shutdown(fileno(writefp), SHUT_WR); // shutdown 함수가 호출되면 복사된 파일 디스크립터의 수에 
										// 상관없이 Half-close가 전달되며, 
										// 이 과정에서 EOF도 전달된다. 
										// 즉 완벽한 Half-close를 구현하려면 shutdown 함수가 필요하다. 
	fclose(writefp);

	fgets(buf, sizeof(buf), readfp); 
	fputs(buf, stdout);
	fclose(readfp);
	return 0;
}

}