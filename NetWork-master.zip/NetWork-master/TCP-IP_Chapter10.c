멀티프로세스 기반의 서버구현

10-1 프로세스의 이해와 활용

지금까지 공부한 내용으로는 차례차례 순차적 연결을 허용하는 서비스만 만들 수 있다. 

따라서, 
"모든 연결요청자의 접속대기시간은 1초를 넘기지 않습니다. 그러나 서비스를 제공받는데 걸리는 시간은 평균적으로 2~3초 정도 걸리는"
즉, 평균 만족도를 높이는 서비스를 만들어야 한다. 

멀티 프로세스 서버의 구현에 사용되는 함수 fork()

#include <unistd.h>

pid_fork(void);
	성공 시 프로세스 ID, 실패 시 -1 반환

이 함수는 fork 함수를 호출한 프로세스를 볷하하는 것이다. 
그리고 두 프로세스 모두 fork 함수의 호출 이후 문장을 실행하게 된다.(정확히 표현하면 fork 함수의 반환 이후).

그러나 차이가 있는데
부모 프로세스 fork 함수의 반환 값은 자식 프로세스의 ID이고,
자식 프로세스의 반환 값은 0이다. 
즉, fork() 하는 동안 각각 다른 반환 값을 리턴 받는다. 
이를 활용한 예제 코드는.

ex)
#include <stdio.h>
#include <unistd.h>

int gval = 10;
int main(int argc, char *argv[])
{
	pid_t pid;
	int lval = 20;
	gval++, lval+=5;

	pid=fork();
	if(pid==0) // if child process
		gval+=2, lval+=2;
	else		// if parent process
		gval-=2, lval-=2;

	if(pid==0)
		printf("Child Proc: [%d, %d] \n", gval, lval); // 13, 27
	else
		printf("Parent Proc: [%d, %d] \n", gval, lval); // 9, 23
	return 0;
}

10-2 프로세스 & 좀비 프로세스 

좀비 프로세스가 생성되는 상황 두 가지
 - 인자로 전달하면서 exit를 호출하는 경우
 - main 함수에서 return 문을 실행하면서 값을 반환하는 경우 

 그럼 이 좀비 프로세스는 언제 종료가 되나?

 "해당 자식 프로세스를 생성한 부모 프로세스에게 exit함수의 인자 값이나 return 문의 반환 값이 전달 되어야 한다. "

 이는 부모 프로세스의 함수요청이 있어야 운영체제가 값을 전달해 준다. 
 그래서 close() 함수 같은 것을 해주는 것. 

 * 백그라운드 실행
root@my_linux:/tcpip# ./zombie & (엔터) // 이러면 해당 실행은 백그라운드에서 진행된다. 
root@my_linux:/tcpip# ./ ps au

좀비 프로세스의 소멸 1 : wait 함수 사용
#include <sys/wait.h>

pid_t wait(int * statloc);
	-> 성공 시 종료된 자식 프로세스의 ID, 실패 시 -1 반환 

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main(int argc, char *argv[])
{
	int status;
	pid_t pid=fork();

	if(pid==0)
	{
		return 3; // 생성된 자식 프로세스는 여기서 종료	
	}
	else
	{
		printf("Child PID : %d \n", pid);
		pid=fork(); // 자식 프로세스 또 생성 
		if(pid == 0) // 여기서 또 자식 프로세스를 종료 
		{
			exit(7);
		}
		else
		{
			printf("Child PID : %d \n", pid);
			wait(&status);	// wait함수를 통해 종료된 프로세스 관련 정보는 status에 담기게되고, 해당 정보의 프로세스는 완전히 소멸된다. 
			if(WIFEXITED(status))	// WIFEXITED함수를 통해 자식 프로세스의 정상종료여부 확인 
			{
				printf("Child send one : %d \n", WEXITSTATUS(status)); // 정상종료의 경우에 한하여 자식프로세스가 전달한 값을 출력 
			}

			wait(&status); // 앞서 생성한 프로세스가 2개 이므로 또 한번의 wait 함수 호출
			if(WIFEXITED(status))
			{
				printf("Child send two : %d \n", WEXITSTATUS(status));
			}

			sleep(30); // 부모 프로세스의 종료를 멈추기 위해 삽입한 코드. 이 순간에 자식 프로세스의 상태를 포어그라운드에서 확인 
						// 하지만 wait() 함수 호출로 완전히 사라졌음을 확인할 수 있다. 
		}
	}
	return 0;
} 

좀비 프로세스의 소멸 2 : waitpid() 함수의 사용

wait 함수의 블로킹이 문제가 된다면 waitpid()함수를 쓰면된다. 

#include <sys/wait.h>

pid_t waitpid(pid_t pid, int * statloc, int options);
	-> 성공 시 종료된 자식 프로세스의 ID(또는 0), 실패 시 -1 반환

	- pid : 종료를 확인하고자 하는 자식 프로세스의 ID 전달, 이를 대신해서 -1을 전달하면 
			wait함수와 마찬가지로 임의의 자식 프로세스가 종료되기를 기다린다. 

	- statloc : wait 함수의 매개변수 statloc과 동일한 의미로 사용된다. 
	- options : 헤더파일 sys/wait.h에 선언된 상수 WNOHANG을 인자로 전달하면, 종료된 자식 프로세스가 
				존재하지 않아도 블로킹 상태에 있지 않고, 0을 반환하면서 함수를 빠져 나온다. 

ex)
#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

int main(int argc, char *argv[])
{
	int status;
	pid_t pid = fork();

	if(pid == 0)
	{
		sleep(15);	// 자식 프로세스의 종료를 늦추기 위해 sleep호출 
		return 24;
	}
	else
	{
		while(!waitpid(-1, &status, WNOHANG))	// while문 안에서 waitpid 함수를 호출하고 있고, 세 번째 인자로 WNOHANG을 전달,
												// 하였으니 종료된 자식 프로세스가 없으면 0을 반환한다. 
												// 따라서 위에 15초 동안 자식프로세스가 실행되고 있으니,
												// 블라킹을 안한 waitpid함수가 계속 확인을 하면서 
												// "sleep 3sec"를 5번정도 출력하게 된다. 
		{
			sleep(3);
			puts("sleep 3sec.");
		}

		if(WIFEXITED(status))
		{
			printf("Child send %d \n", WEXITSTATUS(status));
		}
	}
	return 0;
}


10-3 시그널 핸들링

그럼 도대체 자식 프로세스가 언제 종료될 줄 알고 waitpid 함수를 계속 호출하고 앉아 있어야 하나?

우선, 그본적으로 자식 프로세스의 종료 인식의 주체는 운영체제이다. 따라서 운영체제가 검사하고 있다가
종료되었다면 알려주는 것이 효율적이다. 

이러한 동작 방식을 구현하기 위해 '시그널 핸들링(Signal Handling)'이 존재한다. 
이는 특정상황이 발생했음을 알리기 위해 운영체제가 프로세스에게 전달하는 메시지를 의미한다. 

프로세스 : "야, 운영체제야! 내가 생성한 자식 프로세스가 종료되면 zombie_handler라는 이름의 함수 좀 호출해 주라!"
-> 시그널 등록 
		
운영체제 : "그래! 그럼 네가 생성한 자식 프로세스가 종료되면, 
			네가 말한 zombie_hander라는 이름의 함수를 내가 대신 호출해 줄 테니,
			그 상황에서 실행해야 할 문장들을 그 함수에 잘 묶어둬!"


시그널을 등록하는 함수는

#include <signal.h>

void (*signal(int signom void(*func)(int)))(int);
	반환형이 함수 포인터이다 보니, 선언이 다소 복잡하다. 
	함수의 이름은 signal이며
	매개변수는 int signom, void(*func)(int)이고
	첫 번째 인자는 특정 상황에 대한 정보를,
	두 번째 인자는 특정 상황에서 호출되는 함수의 주소 값(포인터)을 전달한다. 
	그러면 첫 번째 인자를 통해명시된 상황이 발생했을 때, 
	두 번째 인자로 전달된 주소 값의 함수가 호출된다. 

	첫 번째 인자로 들어갈 수 있는 값은
		SIGALRM : alarm 함수호출을 통해서 등록된 시간이 된 상황
		SIGINT : CTRL + C가 입력된 상황
		SIGCHLD : 자식 프로세스가 종료된 상황 

	반환형은 매개변수형이 int이고 반환형이 void인 함수 포인터 이다. 

	만약 "자식 프로세스가 종료되면 mychild() 함수를 호출해 달라" 표현하면
	signal(SIGCHLD, mychild); 이다. 


	SIGALRM과 같이 주로 사용하게 되는 함수는

	#include <unistd.h>

	unsigned int alarm(unsigned int seconds); 
		-> 0또는 SIGALRM 시그널이 발생하기까지 남아있는 시간을 초 단위로 반환한다. 

ex)

#include <stdio.h>
#include <unistd.h>
#include <signal.h>

void timeout(int sig)
{
	if(sig == SIGALRM)
	{
		puts("Time out!");
	}
	alarm(2); // 2초 간격으로 SIGALRM 시그널을 반복 발생시키기 위해 시그널 핸들러 내에서 alarm 함수를 호출하고 있다. 
}
void keycontrol(int sig)
{
	if(sig == SIGINT)
	{
		puts("CTRL+C pressed");
	}
}

int main(int argc, char *argv[])
{
	int i;
	signal(SIGALRM, timeout); 	// 시그널 SIGALRM, SIGINT에 대한 시그널 핸들러를 등록하고 있다. 
	signal(SIGINT, keycontrol);
	alarm(2);					// 시그널 SIGALRM 발생을 2초뒤로 예약하였다. 

	for(i = 0; i < 3; i++)	// 시그널의 발생과 시그널 핸들러의 실행을 확인하기 위해서 100초간 총 3회의 대기시간을 갖는다. 
							// 그러나 "시그널이 발생하면 sleep 함수의 호출로 블로킹 상태에 있던 프로세스가 깨어난다"
							// 함수의 호출을 유도하는 것은 운영체제이지만, 그대로 프로세스가 잠들어 있는 상태에서 함수가 
							// 호출될 수는 없다. 따라서 시그널이 발생하면, 시그널에 해당하는 시그널 핸들러의 호출을 위해서 
							// sleep함수의 호출로 블로킹 상태에 있던 프로세스는 깨어나게 된다. 
							// 그리고 한번 깨어나면 다시 잠들지 않는다. 비록 sleep 함수의 호출문에서 요구하는 시간이 있더라도. 
							// 그래서 이 예제는 10초가 되지 않아 끝난다. CTRL+C를 입력하면 1초도 안될 지도...
	{
		puts("wait...");
		sleep(100);
	}
	return 0;
}



sigaction 함수를 이용한 시그널 핸들링
이 함수는 signal함수를 대체할 수 있고, 훨씬 더 안정적으로 동작한다. 왜냐하면,
"signal 함수는 유닉스 계열의 운영체제 별로 동작방식에 있어서 약간의 차이를 보일 수 있지만,
sigaction 함수는 차이를 보이지 않는다."

#include <signal.h>

int sigaction(int signo, const struct sigaction * act, struct sigaction * oldact);
	-> 성공 시 0, 실패 -1 반환 

	- signo : signal함수와 마찬가지로 시그널의 정보를 인자로 전달
	- act : 첫 번째 인자로 전달된 상수에 해당하는 시그널 발생시 호출될 함수(시그널 핸들러)의 정보 전달.
	- oldact : 이전에 등록되었던 시그널 핸들러의 함수 포인터를 얻는데 사용되는 인자, 필요없다면 0을 전달. 

위 함수의 const struct sigaction 구조체를 먼저 선언 및 초기화해야하는데
이는,

struct sigaction
{
	void (*sa_handler)(int);	// 시그널 핸들러의 함수 포인터 값(주소 값)을 저장

	// 이 두 멤버는 시그널 관련 옵션 및 특성의 지정에 사용되는데, 
	// 우리의 목적은 좀비 프로세스의 생성을 막는데 있으므로 설명은 생략. 

	sigset_t sa_mask;			// 모든 비트를 0으로 초기화 한다. 
	int sa_flags;				// 0으로 초기화 한다. 
}

ex)

#include <stdio.h>
#include <unistd.h>
#include <signal.h>

void timeout(int sig)
{
	if(sig == SIGALRM)
	{
		puts("Time out!");
	}
	alarm(2); // 2초 간격으로 SIGALRM 시그널을 반복 발생시키기 위해 시그널 핸들러 내에서 alarm 함수를 호출하고 있다. 
}

int main(int argc, char *argv[])
{
	int i;
	struct sigaction act;			// 시그널 발생시 호출될 함수의 등록을 위해서 구조체 변수를 선언.
	act.sa_handler = timeout;		// 함수 포인터 값을 저장 
	sygemptyset(&act.sa_mask);		// 모든 비트를 0으로 초기화 
	act.sa_flags = 0;				// 여기도 필요한 멤버가 아니므로 0으로 초기화 
	sigaction(SIGALRM, &act, 0);	// 시그널 SIGALRM에 대한 핸들러를 지정.

	alarm(2);						// 2초후에 시그널 SIGALRM이 발생하도록 설정 

	for(i = 0; i < 3; i++)
	{
		puts("wait...");
		sleep(100);
	}
	return 0;
}

시그널 핸들링을 통한 좀비 프로세스의 소멸 

ex)
#include <stdio.h>
#include <stdlib,.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>

void read_childproc(int sig)
{
	int status;
	pid_t id = waitpid(-1, &status, WNOHANG);
	if(WIFEXITED(status))
	{
		printf("Removed proc id : %d \n", id);
		printf("Child send : %d \n", WEXITSTATUS(status));
	}
}

int main(int argc, char *argv[])
{
	pid_t pid;
	struct sigaction act;
	act.sa_handler = read_childproc;
	sigemptyset(&act.sa_mask);
	act.sa_flags = 0;
	sigaction(SIGCHLD, &act, 0);

	pid = fork();
	if(pid == 0) // 자식 프로세스 실행 영역
	{
		puts("Hi ! I'm child procsess");
		sleep(10);
		return 12;
	}
	else // 부모 프로세스 실행영역
	{
		printf("Child proc id : %d \n", pid);
		pid = fork();
		if(pid == 0) // 또 다른 자식 프로세스의 실행 영역
		{
			puts("Hi ! I'm child process");
			sleep(10);
			exit(24);
		}
		else
		{
			int i;
			printf("Child proc id : %d \n", pid);
			for(i = 0; i < 5; i++)
			{
				puts("wait...");
				sleep(5);
			}
		}
	}
	return 0;
}

시그널 SIGCHLD의 발생을 대기하기 위해서 부모 프로세스를 5초간 5회 멈춰 놓았다. 
물론 시그널이 발생하면 부모 프로세스는 깨어나기 때문에 
실제 멈춰있는 시간은 25초가 되지 않는다. 


10-4 멀티태스킹 기반의 다중 접속 서버

다중 접속 에코 서버 구현 

1. 에코 서버(부모 프로세스)는 accept 함수호출을 통해서 연결요청을 수락한다. 
2. 이때 얻게 되는 소켓의 파일 디스크립터를 자식 프로세스를 생성해서(fork) 넘겨준다.
	넘기는 코드를 구현하기가 까다로울 지도 모르지만, 자식프로세스는 부모 프로세스가 소유하고 있는 것을
	전부 복사해서 생성되므로, 따로 넘겨줄 필요가 없다. 
3. 자식 프로세스는 전달받은 파일 디스크립터를 바탕으로 서비스를 제공한다.

ex)
에코 서버
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>
#include <arpa/inet.h>
#include <sys/socket.h>

#define BUF_SIZE 30
void error_handling(char *message);
void read_childproc(int sig);

int main(int argc, char *argv[])
{
	int serv_sock, clnt_sock;
	struct sockaddr_in serv_adr, clnt_adr;

	pid_t pid;
	struct sigaction act;
	socklen_t adr_sz;
	int str_len, state;
	char buf[BUF_SIZE];
	if(argc != 2)
	{
		printf("Usage : %s <port> \n", argv[0]);
		exit(1);
	}

	act.sa_handler = read_childproc;
	sigemptyset(&act.sa_mask);
	act.sa_flags = 0;
	state = sigaction(SIGCHLD, &act, 0);
	serv_sock = socket(PF_INET, SOCK_STREAM, 0);
	memset(&serv_adr, 0, sizeof(serv_adr));
	serv_adr.sin_family = AF_INET;
	serv_adr.sin_addr.s_addr = htonl(INADDR_ANY);
	serv_adr.sin_port = htons(atoi(argv[1]));

	if(bind(serv_sock, (struct sockaddr*) & serv_adr, sizeof(serv_adr)) == -1)
		error_handling("bind() error");
	if(listen(serv_sock, 5) == -1)
		error_handling("listen() error");

	while(1)
	{
		adr_sz = sizeof(clnt_adr);
		clnt_sock = accept(serv_sock, (struct sockaddr*)&clnt_adr, &adr_sz);
		if(clnt_sock == -1)
			continue;
		else
			puts("new client connected...");
		pid = fork();
		if(pid == -1)
		{
			close(clnt_sock);
			continue;
		}
		if(pid == 0) // 자식 프로세스 실행 영역
		{
			close(serv_sock);
			while((str_len = read(clnt_sock, buf, BUF_SIZE)) != 0)
				write(clnt_sock, buf, str_len);

			close(clnt_sock);
			puts("client disconnected...");
			return 0;
		}
		else
			close(clnt_sock);
	}
	close(serv_sock);
	return 0;
}

void read_childporc(int sig)
{
	pid_t pid;
	int status;
	pid = waitpid(-1, &status, WNOHANG);
	printf("removed proc id : %d \n", pid);
}

void error_handling(char *message)
{
	fputs(message, stderr);
	fputc('\n', stderr);
	eixt(1);
}

fork 함수 호출을 통한 파일 디스크립터의 복사

" 파일 디스크립터만 복사된 건가요? 아니면 소켓도 복사된 건가요?"

일단, 소켓은 프로세스의 소유가 아니다. 
엄밀히 말해 소켓은 운영체제의 소유이다. 
프로세스는 단지 해당 소켓을 의미하는 파일 디스크립터만 소유하고 있을 뿐이다. 

따라서 하나의 소켓에 여러개의 파일 디스크립터가 붙는 형세라고 보는 것이 맞다. 
또한, 모든 파일 디스크립터가 종료되어야 소켓이 소멸된다. 
따라서 fork 함수 호출 이후에는 서로에게 상관이 없는 소켓의 파일 디스크립터를 닫아야 한다. 

10-5 TCP의 입출력 루틴 분할

입출력 루틴 분할의 의미와 이점.

지금까지 구현한 에코 클라리언트의 방식은 다음과 같았다. 
"서버로 데이터를 전송한다! 그리고는 데이터가 에코되어 돌아올 때까지 기다린다. 
무조건 기다린다. 그리고 에코되어 돌아온 데이터를 수신하고 나서야 비로소 데이터를 추가로 전송할 수 있다."

왜 이렇게 해야 했나?
프로그램 코드의 흐름이 read와 write를 반복하는 구조였기 때문이다. 
그런데 이렇게밖에 할 수 없었던 이유는 하나의 프로세스를 기반으로 프로그램이 동작했기 때문이다. 
그러나 이제는 둘 이상의 프로세스를 생성할 수 잇으니,
데이터의 송신과
데이터의 수신을 분리해보자. 

예로 든 모델은 클라이언트의 부모 프로세스가 데이터의 수신을 담당하고, 
자식 프로세스는 데이터의 송신을 담당한다. 

결과적으로 서버가 데이터를 수신하든지 말든지 계속해서 데이터를 송신할 수도 있다. 
따라서 동일한 시간 내에 데이터 송수신이 많아 질 수 밖에 없다. 
또한, 이렇게 해두면 코드의 복잡도도 낮출 수 있다. 

에코 클라이언트 
ex)
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>
#include <arpa/inet.h>
#include <sys/socket.h>

#define BUF_SIZE 30
void error_handling(char *message);
void read_routine(int sock, char *buf);
void write_routine(int sock, char *buf);

int main(int argc, char *argv[])
{
	int sock;
	pid_t pid;
	char buf[BUF_SIZE];
	struct sockaddr_in serv_adr;
	if(argc != 3)
	{
		printf("Usage : %s <IP> <port> \n", argv[0]);
		exit(1);
	}

	sock = socket(PF_INET, SOCK_STREAM, 0);
	memset(&serv_adr, 0, sizeof(serv_adr));
	serv_adr.sin_family = AF_INET;
	serv_adr.sin_addr.s_addr = inet_addr(argv[1]));
	serv_adr.sin_port = htons(atoi*argv[2]));

	if(connect(sock, (struct sockaddr*)&serv_adr, sizeof(serv_adr)) == 01)
		error_handling("connect() error!");

	pid = fork();
	if(pid == 0)	// 자식 프로세스 실행 영역
		write_routine(sock, buf);
	else			// 부모 프로세스 실행 영역
		read_routine(sock, buf);

	close(sock);
	return 0;
}

void read_routine(int sock, char * buf) // 외부 함수로 read와 write 함수를 빼냄
{
	while(1)
	{
		int str_len = read(sock, buf, BUF_SIZE);
		if(str_len  == 0)
			return;

		buf[str_len] = 0;
		printf("Message from server : %s", buf);
	}
}

void write_routine(int sock, char *buf)
{
	while(1)
	{
		fgets(buf, BUF_SIZE, stdin);
		if(!strcmp(buf, "q\n") || !strcmp(buf, "Q\n"))
		{
			shutdown(sock, SHUT_WR);
			return;
		}
		write(sock, buf, strlen(buf));
	}
}

void error_handling(char *message)
{
	fputs(message, stderr);
	fputc('\n', stderr);
	exit(1);
}