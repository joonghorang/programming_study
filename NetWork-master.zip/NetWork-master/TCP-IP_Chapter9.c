소켓의 다양한 옵션

09-1 : 소켓의 옵션과 입출력 버퍼의 크기

소켓의 다양한 옵션 

getsockopt & setsockopt

소켓의 거의 모든 옵션은 설정상태의 참조(Get) 또는 변경(Set)이 가능하다. 
그리고 이 옵션의 참조 및 변경에는 다음 두 함수를 사용한다.

1. 옵션을 확인할 때 사용하는 함수 

#include <sys/socket.h>

int getsockopt(int sock, int level, int optname, void *optval, socklen_t *optlen);
	-> 성공 시 0, 실패 시 -1 반환

	- sock : 옵션확인을 위한 소켓의 파일 디스크립터 전달.
	- level : 확인할 옵션의 프로토콜 레벨 전달.
	- optname : 확인할 옵션의 이름 전달. 
	- optval : 확인결과의 저장을 위한 버퍼의 주소 값 전달.
	- optlen : 네 번재 매개변수 optval로 전달된 주소 값의 버퍼크기를 담고 있는 변수의 주소 값 전달, 
				함수호출이 완료되면 이 변수에는 네 번째 인자를 통해 반환된 옵션정보의 크기가 바이트 단위로 계산되어 저장된다. 

ex)
int tcp_sock, upd_sock;
int sock_type;
socklen_t optlen;
int state;

state = getsockopt(tcp_sock, SOL_SOCKET, SO_TYPE, (void*)&sock_type, &optlen);

2. 옵션을 변경할 때 사용하는 함수 

#include <sys/socket.h>

int setsockopt(int sock, int level, int optname, const void *optval, socklen_t optlen);
	-> 성공 시 0, 실패 시 -1 반환

	- sock : 옵션변경을 위한 소켓의 파일 디스크립터 전달
	- level : 변경할 옵션의 프로토콜 레벨 전달.
	- optname : 변경할 옵션의 이름 전달.
	- optval : 변경할 옵션정보를 저장한 버퍼의 주소 값 전달.
	- optlen : 네 번째 매개변수 optval로 전달된 옵션정보의 바이트 단위 크기 전달. 


SO_SNDBUF(출력버퍼의 크기와 관련된 옵션) & SO_RCVBUF(입력버퍼의 크기와 관련된 옵션)

ex)
state = setsockopt(sock, SOL_SOCKET, SO_RCVBUF, (void*)&rcv_buf, sizeof(rcv_buf));
state = setsockopt(sock, SOL_SOCKET, SO_RCVBUF, (void*)&snd_buf, sizeof(rcv_buf));

* "소켓의 타입은 소켓 생성시 한 번 결정되면 변경이 불가능하다."
* "버퍼의 사이즈 변경에는 최소값과 최대값이 한정되어 있다."(무조건 프로그래머  마음대로 변경할 수 없다.)

09-2 SO_REUSEADDR

주소할당 에러(Binding Error) 

서버와 클라이언트가 연결된 상태에서 서버 측 콘솔에서 CTRL+C를 입력한다. 즉, 서버 프로그램을 강제 종료한다.
이는 서버가 클라이언트 측으로 먼저 FIN 메시지를 전달하는 상황의 연출을 위한 것이다. 
그런데 이렇게 서버를 종료하고 나면 서버의 재실행에 문제가 생긴다. 동일한 PORT번호를 기준으로 서버를 재실행하면
"bind() error"라는 메시지가 출력될 뿐 서버는 실행되지 않는다. 
그러나 이 상태에서 약 3분 정도 지난 다음 재실행을 하면 정상적인 실행을 확인할 수 있다. 
앞서 보인 두 가지 실행방식에 있어서의 유일한 차이점은 FIN 메시지를 누가 먼저 전송했는지에 있다. 
그럼에도 불구하고 이렇듯 차이를 보이는 이유가 어디에 있는지 함께 고민해보기로 하자. 

Time-wait 상태
서버와 클라이언트간에 Four-way handshaking 이후에 소켓이 바로 소멸되지 않고 Time-wait상태라는 것을
일정시간 거치게 된다. 물론 연결의 종료를 요청한 쪽만 거치는 것이다. 
이 때문에 서버가 먼저 연결의 종료를 요청해서 종료하고 나면, 바로 이어서 실행을 할 수 없다. 
소켓이 Time-wait 상태에 있는 동안에는 해당 소켓의 PORT번호가 사용중인 상태이기 때문이다. 
반대로 클라이언트 소켓이 먼저 종료를 하는 경우 큰 문제가 되지 않는데, 왜냐하면 클라이언트의 포트번호는 임의로 할당되기 때문이다. 

이 문제를 해결하기 위해서는 소켓의 옵션중에 SO_REUSEADDR의 상태를 변경하면 된다. 
이를 통해 소켓에 할당되어 있는 PORT번호를 새로 시작하는 소켓에 할당되게끔 할 수 있다. 

ex)
optlen = sizeof(option);
option = TRUE;
setsockopt(serv_sock, SOL_SOCKET, SO_REUSEADDR, (void*)&option, optlen);

09-3 TCP_NODELAY

Nagle 알고리즘은 네트워크상에서 돌아다니는 패킷들의 흘러 넘침을 막기위해 고안된 알고리즘이다. 
골자는 "앞서 전송한 데이터에 대한 ACK 메시지를 받아야만, 다음 데이터를 전송하는 알고리즘"이다. 

기본적으로 TCP 소켓은 Nagle 알고리즘을 적용해서 데이터를 송수신하기 때문에 
ACK가 수신될 떄까지 최대한 버퍼링을 해서 데이터를 전송한다. 

이 알고리즘을 적용하지 않으면 쓸데 없는 헤더파일을 계속 전송해야 한다. 

그러나 용량이 큰 경우 Nagle 알고리즘을 적용하지 않는 편이 더 좋다. 
왜냐하면 매번 출력버퍼를 거의 꽉 채워서 패킷을 전송하고, 따라서 패킷의 수가 크게 증가하지도 않을 뿐더러,
ACK를 기다리지 않고 연속해서 데이터를 전송하니 전송속도도 놀랍게 향상된다. 

따라서 "트래픽의 차이가 크지 않고 Nagle 알고리즘을 적용하는 것보다 데이터의 전송이 빠른 경우"
Nagle 알고리즘을 해제 해야 하는데 방법은
소켓 옵셔 TCP_NODELAY를 1(TRUE)로 변경해주면 된다.

ex)
int opt_val = 1;
setsockopt(sock, IPROTO_TCP, TCP_NODELAY, (void*)&opt_val, sizeof(opt_val));

반대로 설정 상태를 확인하려면
ex)
int opt_val;
socklen_t opt_len;
opt_len = sizeof(opt_val);
getsockopt(sock, IPROTO_TCP, TCP_NODELAY, (void*)&opt_val, &opt_len);

설정된 상태라면 opt_val = 0, 아니라면 1