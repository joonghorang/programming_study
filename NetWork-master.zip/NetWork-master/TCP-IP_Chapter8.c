도메인 이름과 인터넷 주소

08-1 Domain Name System(DNS)

어떻게 도메인 이름을 IP주소로 변화하는 걸까? 
DNS 서버에게 요청하면 된다. 

그러나 일개 컴퓨터에 설정되어 있는 디폴트 DNS 서버가 모든 도메인의 IP주소를 알고 있지는 않다.
그러나 디폴트 DNS 서버는 모르면 물어서라도 가르쳐준다. 

즉, DNS 서버는 계층적으로 관리되는 일종의 분산 데이터베이스 시스템이다. 

08-2 IP주소와 도메인 이름 사이의 변환

IP주소는 도메인 이름에 비해 상대적으로 변경의 확률이 높다. 
그래서 IP주소와 도메인 이름 상의 변환함수가 필요하다. 

다음 함수를 이용하면 문자열 형태의 도메인 이름으로부터 IP의 주소정보를 얻을 수 있다.

#include <netdb.h>

struct hostent * gethostbyname(const char * hostname);
	성공 시 hostent 구조체 변수의 주소 값, 실패 시 NULL 포인터 반환

여기서 반환되는 hostent 구조체는 아래와 같다.
struct hostent
{
	char * h_name;		// official name
	char ** h_aliases;	// alias list
	int h_addrtype; 	// host address type
	int h_length;		// address length
	char ** h_addr_list;// address list
}

h_name 
이 멤버에는 '공식 도메인 이름(Official domain name)' 이라는 것이 저장된다. 
공식 도메인 이름은 해당 홈페이지를 대표하는 도메인 이름이라는 의미를 담고 있지만,
실제 우리에게 잘 알려진 유명회사의 도메인 이름이 공식 도메인 이름으로 등록되지 않은 경우가 많다. 

h_aliases
같은 메인 페이지인데도 다른 도메인 이름으로 접속할 수 있는 경우를 본적이 있는가?
하나의 IP에 둘 이상의 도메인 이름을 지정하는 것이 가능하기 때문에,
공식 도메인 이름 이외에 해당 메인 페이지에 접속할 수 있는 다른 도메인 이름의 지정이 가능하다. 
그리고 이들 정보는 h_aliases를 통해서 얻을 수 있다.

h_addrtype
gethostbyname 함수는 IPv4뿐만 아니라 IPv6까지 지원한다. 때문에 h_addr_list로 반환된 IP
주소의 주소체계에 대한 정보를 이 멤버를 통해 반환한다. 
IPv4의 경우 이 멤버에는 AF_INET이 저장된다. 

h_length
함수호출의 결과로 반환된 IP주소의 크기정보가 담긴다. 
IPv4의 경우에는 4바이트이므로 4가 저장되고, 
IPv6의 경우에는 16바이트이므로 16이 저장된다. 

h_addr_list
이것이 가장 중요한 멤버이다. 이 멤버를 통해서 도메인 이름에 대한 IP주소가 정수의 형태로 반환된다. 
참고로 접속자수가 많은 서버는 하나의 도메인 이름에 대응하는 IP를 여러 개 둬서, 
둘 이상의 서버로 부하를 분산시킬 수 있는데, 이러한 경우에도 이 멤버를 통해서 모든 IP의 주소정보를 얻을 
수 있다. 

ex)
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
void error_handling(cahr *message);

int main(int argc, char *argv[])
{
	int i;
	struct hostent *host;
	if(argc!=2){
		printf("Usage : %s <addr>\n", argv[0]);
		exit(1);
	}

	host=gethostbyname(argv[1]);				// main 함수로 전달된 문자열을 인자로 gethostbyname 함수를 호출하고 있다. 
	if(!host)
		error_handling("gethost... error");

	printf("Official name : %s \n", host->h_name); 	// 공식 도메인 이름을 출력하고 있다. 
	for(i=0; host->h_aliases[i]; i++)				// 공식 도메인 이름 이외의 도메인 이름을 출력하고 있다. 
		printf("Aliases %d: %s \n", i+1, host->h_aliases[i]);
	pirntf("Address type : %s \n", 
		(host->h_addrtype==AF_INET)?"AF_INET" : "AF_INET6");
	for(i=0; host->h_addr_list[i]; i++)				// IP 주소정보를 출력하고 있다. 
		printf("IP addr %d: %s \n", i+1,
			inet_ntoa(*(struct in_addr*)host->h_addr_list[i]));
	return 0;
}

void error_handling(char *message)
{
	fputs(message,l stderr);
	fputc('\n', stderr);
	exit(1);
}

IP 주소를 이용해서 도메인 정보 얻어오는 함수 

#include <netdb.h>

struct hostent * gethostbyaddr(const char * addr, socklen_t len, int family);
	성공 시 hostent 구조체 변수의 주소 값, 실패 시 NULL 포인터 반환

	- addr : IP주소를 지니는 in_addr 구조체 변수의 포인터 전달, 
			 IPv4 이외의 다양한 정보를 전달받을 수 있도록 일반화하기 위해서 매개변수를 char형으로 선언 
	- len : 첫 번째 인자로 전달된 주소정보의 길이, IPv4의 경우 4, IPv6의 경우 16전달. 
	- family : 주소체계 정보 전달, IPv4의 경우 AF_INET, IPv6의 경우 AF_INET6 전달. 

ex)

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
void error_handling(cahr *message);

int main(int argc, char *argv[])
{
	int i;
	struct hostent *host;
	struct sockaddr_in addr;
	if(argc != 2) {
		printf ("Usage : %s <IP> \n", argv[0]);
		exit(1)
	}

	memset(&addr, 0, sizeof(addr));
	addr.sin_addr.s_addr = inet_addr(argv[1]);
	host - gethostbyaddr((char*)&addr.sin_addr, 4, AF_INET);
	if(!host)
		error_handling("gethost... error");

	printf("Official name : %s \n", host->h_name);
	for(i=0; host->h_aliases[i]; i++)
		printf("Aliases %d: %s \n", i+1, host->h_aliases[i]);
	printf("Address type: %s \n",
		(host->h_addrtype==AF_INET)?"AF_INET":"AF_INET6");
	for(i=0; host->h_addr_list[i]; i++)
		printf("IP addr %d: %s \n", i+1,
			inet_ntoa(*(struct in_addr*)host->h_addr_list[i])
			  );
	return 0;
}

void error_handling(char *message)
{
	fputs(message, stderr);
	fputc('\n', stderr);
	exit(1);
}