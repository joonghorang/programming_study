/* Sample TCP server */

#include <arpa/inet.h>
#include <sys/socket.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>

int main(int argc, char**argv)
{
  	int listen_fd;
	int	connect_fd;
	int n;

  	struct sockaddr_in server_address;
	struct sockaddr_in client_address;
  	socklen_t client_length;
  	char message[4096];
  	char header[] = "HTTP/1.0 200 OK\r\nDate: Wed, 12 Mar 2014 00:14:10 GMT\r\n\r\n";
 	char buf[BUFSIZ];
	int i;
  	
	listen_fd = socket(AF_INET,SOCK_STREAM,0);

  	memset(&server_address, 0, sizeof(server_address));
  	server_address.sin_family = AF_INET;
  	server_address.sin_addr.s_addr = htonl(INADDR_ANY);
  	server_address.sin_port = htons(8000);
  	bind(listen_fd,(struct sockaddr *)&server_address,sizeof(server_address));

  	listen(listen_fd,1024);

  	for(i = 0; i < 100;i++) 
	{
   		client_length = sizeof(client_address);
    	connect_fd = accept(listen_fd,(struct sockaddr *)&client_address, &client_length);
    	printf("connected (%d)\n", connect_fd);

    	if (connect_fd > 0) 								// 정상입력이라면
		{
      		n = recv(connect_fd, message, 4096, 0);
      		message[n] = 0;
      		printf("=====\n%s=====\n", message);			// 서버콘솔에 상태 메시지를 출력
      		send(connect_fd, header, strlen(header), 0);
      		int fd = open("141023.html", O_RDONLY);			// html파일의 파일디스크립터를 fd에 저장
      		while ((n = read(fd, buf, BUFSIZ)) > 0) 		// read()함수가 에러가 나지 않을 때까지 파일을 버퍼사이즈 단위로 읽어서
			{
				send( connect_fd, buf, n, 0);				// 연결된 클라이언트 파일디스크립터로 전송
			}
			close(fd);
			close(connect_fd);

			connect_fd = accept(listen_fd, (struct sockaddr *)&client_address, &client_length);
			n = recv(connect_fd, message, 4096, 0);
			message[n] = 0;
			printf("=====\n%s=====\n", message);
			send(connect_fd, header, strlen(header), 0);
			int imgfd = open("img.jpg", O_RDONLY);
			while ((n = read(imgfd, buf, BUFSIZ)) > 0)
			{
				send(connect_fd, buf, n, 0);
			}
			close(imgfd);
      		close(connect_fd);
    	}
  	}
}
