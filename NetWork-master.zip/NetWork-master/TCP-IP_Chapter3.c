03 주소체계와 데이터 정렬(전화기에 전화번호 부여하기)

03-1 소켓에 할당되는 IP(Internet Protocol)주소와 PORT번호

인터넷 주소 
	1. IPv4
	2. IPv6

네트워크를 구성하려면 외부로부터 수신된 데이터를 호스트에 전달하고, 
호스트가 전달하는 데이터를 송신해주는 물리적 장치가 필요하다. 
이를 가리켜 라우터 또는 스위치라고 하는데, 이것도 그냥 컴퓨터에 지나지 않는다.

둘 이상의 컴퓨터로부터 데이터를 전송받으려면 나도 소켓외에 세부 구분이 필요하다. 
그것이 포트번호.
즉 하나의 운영체제 내에서 소켓을 구분하는 목적으로 사용된다. 
반대로 얘기하면 동일한 포트번호를 둘 이상의 소켓에 할당할 수 없다. 

* Port번호의 범위는 0이상 65535까지이다. 그러나 0~1023번까지는 예약되어 있다. 
* 또한 UPD와 TCP는 Port번호를 공유하지 않기 때문에 같은 번호를 쓸 수 있다.

IPv4 기반의 주소표현을 위한 구조체
	
	너 어떤 주소 체계니?
	IPv4

	IP주소는 뭐야?
	211.204.214.76

	Port번호는?
	2048번.

그럼 아래와 같이 구조체를 정의하면 된다.
#include 

struct sockaddr_in
{
	sa_family_t		sin_family;		// 주소 체계(Address Family)
	struct in_addr	sin_addr;		// 32비트 IP주소
	uint16_t		sin_port;		// 16비트 TCP/UDP PORT번호
	char			sin_zero[8];	// 사용되지 않음. 구조체 sockaddr_in의 크기를 구조체 sockaddr과 일치시키기 위해 삽입된 멤버.
									// 반드시 0으로 채우지 않으면 원하는 결과를 어딪 못한다. 

};

여기 들어있는 struct in_addr은 아래와 같이 정의되어 있따. 
struct in_addr
{
	in_addr_t		s_addr;	// 32비트 IPv4 인터넷 주소형 
							// 해당 자료형은 netient/in.h라는 헤더파일을 선언해야 한다. 
							// 이런 자료형을 사용하는 것은 이후에 자료형 int가 64비트로 표현되더라도
							// 확장 가능해서 사용할 수 있도록 지정해 주는 것.
};

이렇게 만든 구조체 변수의 주소 값은 bind() 함수의 인자로 다음과 같이 전달된다.

if(bind(serv_sock, (struct sockaddr*) &serv_addr, sizeof(serv_addr)) == -1)
	error_handling("bind() error");

여기서 2번 인자로 받는 struct sockaddr의 구조가 
struct sockaddr // 얘는 IPv4의 주소정보만을 담기 위한 구조체가 아니므로,
				// IPv4 전용 구조체인 sockaddr_in과의 호환을 위해서 형변환이 필요하다. 
{
	sa_family_t		sin_family;		// 주소체계(Address Family)
	char			sa_data[14];	// 주소정보 여기에 IP주소와 PORT번호를 한꺼번에 담는다. 남은 부분은
									// 0으로 채워야 하기 때문에 sin_zero[8]값이 필요했던 것. 
}

03-3 네트워크 바이트 순서와 인터넷 주소 변환

CPU 데이터 저장방식이 각 CPU마다 다르다. 
빅에디안(상위 바이트의 값을 작은 번지수에 저장하는 방식)과
리틀 엔디안(상위 바이트의 값을 큰 번지수에 저장하는 방식)이 다르기 때문에 
두 개의 기준을 맞춰주기 위해 네트워크 바이트 순서(Network Byte Order)를 지켜줘야 한다.

그건, "빅 엔디안 방식으로 통일 합시다" 이다. 

바이트 순서의 변환을 돕는 함수는.

	unsigned short htons(unsigned short); // h 호스트 바이트 순서를 n 네크워크 바이트 순서로 
	unsigned short ntohs(unsigned short); // n(network) to h(host) -by- s(short)
	unsigned long htonl(unsigned long);
	unsigned long ntohs(unsigned long);

	* 호스트 바이트 순서란 로컬 피씨에서 저장하는 순서
	* 네트워크 바이트 순서란 네트워크 상에서 사용하는 바이트의 순서. 

하지만 이런 변환은 "sockaddr_in 구조체 변수에 데이터를 채울 때 외에는" 자동으로 
이루어 지기 때문에 신경 쓰지 않아도 된다. 

03-4 인터넷 주소의 초기화와 할당 

211.214.107.99 와 같은 IP 주소를 32비트 정수형으로 변환해주는 함수. 

in_addr_t inet_addr(const char * string);
	성공 시 빅 엔디안으로 변환된 32비트 정수 값, 실패 시 INADDR_NONE 반환 

ex)
char *addr1 = "1.2.3.4";
unsigned long conv_addr = inet_addr(addr1);
if(conv_addr == INADDR_NONE)
	printf("Error occured! \n");
하지만 이 함수를 사용하면 변환된 IP 주소를 구조체 sockaddr_in에 선언되어 있는 
in_addr 구조체 변수에 대입하는 과정을 추가로 거쳐야 한다. 

그-러-나-

구조체 변수 in_addr을 이용해서 같은 일을 하는 함수.
#include <arpa/inet.h>

int inet_aton(	const char * string, 	// 변환할 IP 주소 정보를 담고 있는 문자열의 주소 값 전달. 
 				struct in_addr * addr   // 변환된 정보를 저장할 in_addr 구조체 변수의 주소 값 전달. 
 				);
성공 시 1(true), 실패 시 0(false) 반환. 

그럼, 반대로 다시 IP주소 형으로 반환해주는 함수는?
#include <arpa/inet.h>

char * inet_ntoa(struct in_addr adr); 
성공 시 변환된 문자열의 주소 값, 실패 시 -1 반환

반환 값이 포인터 형으로 선언 되었기 때문에, inet_ntoa() 함수를 호출하면 변환된 값에 덮어 쓰게 된다.
오랫동안 이 정보를 유지하려면 별도의 메모리 공간에 복사를 해 둬야 한다. 

ex)
	struct sockaddr_in addr1, addr2;
	char *str_ptr;
	char str_arr[20];

	addr1.sin_addr.s_addr=htonl(0x1020304);
	addr2.sin_addr.s_addr=htonl(0x1010101);

	str_ptr=inet_ntoa(addr1.sin_addr);
	strcpy(str_arr, str_ptr); 	// 여기가 변환된 값을 저장해 두는 코드
								// 반환된 주소 str_ptr을 참조해서 str_arr에 저장해둔다. 

	inet_ntoa(addr2.sin_addr); // 이게 실행 되면 str_ptr에 저장되었던 값이 사라진다. 


인터넷 주소의 초기화

소켓생성 과정에서 쓰는 인터넷 주소정보의 초기화 방법

	struct sockaddr_in addr;
	char *serv_ip="211.217.168.13";		// IP주소 문자열 선언 , 보통은 이렇게 하드 코딩하지 않는다. main에서 전달받음. 
	char *serv_port="9190";				// PORT번호 문자열 선언
	memset(&addr, 0, sizeof(addr)); 	// 구조체 변수 addr의 모든 멤버를 우선 0으로 초기화
										// 이렇게 0으로 초기화 하는 이유는 나중에 
										// sockaddr_in 구조체 멤버 sin_zero를 0으로 초기화 하기 위함. 
										// memset()은 동일한 값으로 바이트단위 초기화 할 때 쓰는 함수.
	addr.sin_family=AF_INET;			// 주소체계 지정 
	addr.sin_addr.s_addr=inet_addr(serv_ip);	// 문자열 기반의 IP주소 초기화
	addr.sin_port=htons(atoi(serv_port));		// 문자열 기반의 PORT번호 초기화 


	그러나 서버 소켓의 생상과정에서 매번 서버의 IP주소를 입력하는 것이 귀찮을 수 있다. 

	그러면 addr.sin_addr.s_addr=inet_addr(serv_ip); 대신
	"addr.sin_addr.s_addr=htonl(INADDR_ANY);" 로 바꾸어 줄 수 있다. 
	이러면 자동으로 자신이 속한 컴퓨터의 IP주소가 들어간다. (상대적으로 들어갈 값이 뻔하지만 둘 이상의 IP주소를 소유할 수 도 있으므로.)
	* 따라서 프로그램 실행시 서버프로그램은 포트번호만 넘기지만, 
	  클라이언트 프로그램은 IP주소와 PORT번호 둘 다 넘겨줘야 한다. 

	즉 이 코드들은 문자열로 표현된 IP주소와 PORT번호를 기반으로 하는 
	sockaddr_in 구조체 변수의 초기화 과정을 의미한다. 
	""IP 211.217.168.13, PORT 9190"으로 들어오는 데이터는 내게로 보내라!"

	그럼 클라이언트는
	""IP 211.217.168.13, PORT 9190"으로 연결을 해라 !"

	외치는 형태가 다르다는 것은 호출하는 함수가 다름을 의미한다. 
	서버는 bind()를 통해서 이루어지고,
	클라는 connect()를 통해서 이루어진다. 

	그렇기 때문에 외치기 전에 준비해야할 주소 값의 유형도 다르다. 
	서버 프로그램에서는 
	1. sockaddr_in 구조체 변수를 하나 선언해서 
	2. 이를 서버 소켓이 동작하는 컴퓨터의 IP와 소켓에 부여할 PORT번호로 초기화한 다음에 
	3. bind를 호출한다.
	반면에 클라이언트에서는 
	1. sockaddr_in 구조체 변수를 하나 선언해서
	2. 이를 연결할 서버 소켓의 IP와 PORT번호로 초기화한 다음에 
	3. connect 함수를 호출한다. 


소켓에 인터넷 주소 할당하기 
	#include <sys/socket.h>

	int bind(int sockfd, 		 // 주소정보를(IP와 PORT를) 할당할 소켓의 파일 디스크립터.
		struct sockaddr *myaddr, // 할당하고자 하는 주소 정보를 지니는 구조체 변수의 주소 값. 
		socklen_t addrlen);		 // 두 번째 인자로 전달된 구조체 변수의 길이 정보.

	성공시 0, 실패 시 -1반환
	위의 함수 호출이 성공하면, 
	첫 번째 인자에 해당하는 "소켓"에 
	두 번째 인자로 전달된 "주소 정보가 할당된다." 

ex)

int serv_sock;
struct sockaddr_in serv_addr;
char *serv_port="9190";

// 서버 소켓(리스닝 소켓) 생성
serv_sock=socket(PF_INET, SOCK_STREAM, 0);

// 주소정보 초기화
memset(&serv_addr, 0, sizeof(serv_addr));
serv_addr.sin_family=AF_INET;
serv_addr.sin_addr.s_addr=htonl(INADDR_ANY);
serv_addr.sin_port=htons(atoi(serv_port));

// 주소정보 할당
bind(serv_sock, (struct sockaddr*)&serv_addr, sizeof(serv_addr));

