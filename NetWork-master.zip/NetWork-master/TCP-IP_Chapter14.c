14 멀티캐스트 & 브로드캐스트 

멀티캐스트 방식의 데이터 전송은 UDP를 기반으로한다. 
따라서 UDP 서버/클라이언트의 구현방식이 매우 유사하다. 
차이점이 있다면 UDP에서의 데이터 전송은 하나의 목적지를 두고 이뤄지지만,
멀티캐스트에서의 데이터 전송은 특정 그룹에 가입(등록) 되어 있는 다수의 호스트가 된다. 

"즉 멀티 캐스트 방식을 이용하면 단 한번에 데이터 전송으로 다수의 호스트에게 데이터를 전송할 수 있다."

트래픽이 많이 생길 것 같지만, 
하나의 영역에 동일한 패킷이 둘 이상 전송되지 않는다. 

그룹을 묶어서 그룹에 일괄 뿌리는 방식이므로,
길을 찾으면서 해맬필요가 없다. 

* TTL(Time to Live)
"패킷을 얼마나 전달할 것인가"를 결정하는 주 요소이다. 
이는 정수로 표현되며, 이 값은 라우터를 하나 거칠 때마다 1씩 감소한다. 
그리고 0이 되면 패킷은 더 이상 전달되지 못하고 소멸된다. 
값을 너무 크게 잡으면 트래픽에 악영향을 미치고,
값을 너무 작게 잡으면 전달되지 않을 수도 있다. 

설정은 소켓의 옵션설정을 통해 이뤄진다. 
int send_sock;
int time_live = 64;

send_sock = socket(PF_INET, SOCK_DGRAM, 0);
setsockopt(send_sock, IPPROTO_IP, IP_MULTICAST_TTL, (void*)&time_live, sizeof(time_live));

멀티캐스트 그룹의 가입 역시 소켓의 옵션설정을 통해 이루어진다. 
그룹 관련된 프로토콜의 레벨은 IPPROTO_IP이고, 옵션의 이름은 IP_ADD_MEMBERSHIP

struct ip_mreq
{
	struct in_addr imr_multiaddr; // 가입할 그룹의 IP주소
	struct in_addr imr_interface; // 그룹에 가입하는 소켓이 속한 호스트의 IP주소 INADDR_ANY를 이용하는 것도 가능. 
}

int recv_sock;
struct ip_mreq join_adr;
....
recv_sock = socket(PF_INET, SOCK_DGRAM, 0);
....
join_adr.imr_multiaddr.s_addr = "멀티캐스트 그룹의 주소정보";
join_adr.imr_interface.s_addr = "그룹에 가입할 호스트의 주소정보";
setsockopt(recv_sock, IPPROTO_IP, IP_ADD_MEMBERSHIP, (void*)&join_adr, sizeof(join_adr));
....

멀티캐스트 기반에서는 서버, 클라이언트라는 표현을 대신해서 
전송자(Sender), 수신자(Receiver)라는 표현을 사용한다. 

예제는 321p

14-2 브로드캐스트(Broadcast)
브로드캐스트와 멀티캐스트의 차이는 전송이 이뤄지는 범위이다. 
멀티캐스트는 서로 다른 네트워크상에 존재하는 호스트라 할지라도, 
멀티캐스트 그룹에 가입만 되어 있으면 데이터의 수신이 가능하다. 
반면 브로드캐스트는 동일한 네트워크에 연결되어있는 호스트로, 데이터의 전송 대상이 제한된다. 

사용되는 IP 주소의 형태에 따라서 두 가지 형태로 구분된다. 
1. Directed 브로드캐스트 : 네트워크 주소를 제외한 나머지 호스트 주소를 전부 1로 설정 
							192.12.34.255 로 전송하면 192.32.24에 모두 전달됨. 

2. Local 브로드캐스트 : 특별히 예약되어 있는 255.255.255.255 를 대상으로 데이터를 전송하면 
						192.32.24 로 시작되는 IP주소의 모든 호스트에 데이터가 전달됨.

기본적으로 생성되는 소켓은 브로드캐스트 기반의 데이터 전송이 불가능하도록 설정되어있기 때문에
다음과 같이 설정 변경을 해야한다. 

int send_sock
int bcast = 1; // SO_BROADCAST의 옵션정보를 1로 변경하기 위한 변수 초기화 
send_sock = socket(PF_INET, SOCK_DGRAM, 0);
....
setsockopt(send_sock, SOL_SOCKET, SO_BROADCAST, (void*)&bcast, sizeof(bcast));
....

자세한 예제는 327p
