15 소켓과 표준 입출력

15-1 표준 입출력 함수의 장점
 - 표준 입출력 함수는 이식성이 좋다.
 - 표준 입출력 함수는 버퍼링을 통한 성능의 향상에 도움이 된다. 

 그런데 소켓을 생성하면 운영체제가 입출력 버퍼를 자동으로 생성해준다고 하지 않았나? 
 그렇다. 추가로 또 하나의 버퍼를 제공받는 것이다. 

 소켓과 관련해서 제공되는 버퍼는 TCP의 구현을 위한 목적이 강하다. (재전송의 경우 등)
 반면 표준 입출력 함수 사용시 제공되는 버퍼는 오로지 성능 향상만을 목적으로 제공이 된다. 
 이걸 쓰면 헤더정보에 사용하는 전송량을 줄일 수 있다. 

 하지만 단점도 있다. 
 - 양방향 통신이 쉽지 않다.
 - 상황에 따라서 fflush 함수의 호출이 빈번히 등장할 수 있다.(읽기에서 쓰기로 넘어갈때 버퍼를 비워야함)
 - 파일 디스크립터를 FILE 구조체의 포인터로 변환해야 한다. (소켓은 기본적으로 파일 디스크립터를 반환한다.)

15-2 표준 입출력 함수 사용하기 

fdopen 함수를 이용한 FILE 구조체 포인터로의 변환

#include <stdio.h>

FILE * fdopen(int fildes, const char * mode);
	-> 성공 시 변환된 FILE 구조체 포인터, 실패 시 NULL 반환

	- fildes : 변환할 파일 디스크립터를 인자로 전달
	- mode : 생성할 FILE 구조체 포인터의 모드(mode)정보 전달. 

ex)
FILE *fp;
int fd = open("data.dat", O_WRONLY|O_CREAT|O_TRUNC);
fp = fdopen(fd, "w");

fileno 함수를 이용한 파일 디스크립터로의 변환 

#include <stdio.h>

int fileno(FILE * stream);
	-> 성공 시 변환된 파일 디스크립터, 실패 시 -1 반환 

ex)
fileno(fp);

15-3 소켓 기반에서의 표준 입출력 함수 사용

에코 서버
#include <"헤더 파일 선언은 이전과 동일">
#define BUF_SIZE 1024
void error_handling(char *message);

int main(int argc, char *argv[])
{
	int serv_sock, clnt_sock;
	char message[BUF_SIZE];
	int str_len, i;

	struct sockaddr_in serv_adr;
	struct sockaddr_in clnt_adr;
	socklen_t clnt_adr_sz;
	FILE * readfp;
	FILE * writefp;

	if(argc != 2) 
	{
		printf("Usage : %s <port> \n", argv[0]);
		exit(1);
	}

	serv_sock = socket(PF_INET, SOCK_STREAM, 0);
	if(serv_sock == -1)
		error_handling("socket() error");

	memeset(&serv_adr, 0, sizeof(serv_adr));
	serv_adr.sin_family = AF_INET;
	serv_adr.sin_addr.s_addr = htonl(INADDR_ANY);
	serv_adr.sin_port = htons(atoi(argv[1]));

	if(bind(serv_sock, (struct sockaddr*) & serv_adr, sizeof(serv_adr)) == -1)
		error_handling("bind() error");
	if(listen(serv_sock, 5) == -1)
		error_handling("listen() error");
	clnt_adr_sz = sizeof(clnt_adr);

	for(i = 0; i < 5; i++)
	{
		clnt_sock = accept(serv_sock, (struct sockaddr*) & clnt_adr, &clnt_adr_sz);
		if(clnt_sock == -1)
			error_handling("accept() error");
		else
			printf("Connected client %d \n", i+1);

		readfp = fdopen(clnt_sock, "r");
		writefp = fdopen(clnt_sock, "w");
		while(!feof(readfp)) 
		{
			fgets(message, BUF_SIZE, readfp);
			fputs(message, writefp);
			fflush(writefp); // 이걸 비워줘야 클라인트로 데이터가 전송된다. 
		}
		fclose(readfp);
		fclose(writefp);
	}
	close(serv_sock);
	return 0;
}

클라이언트 

#define BUF_SIZE 1024
void error_handling(char *message);

int main(int argc, char *argv[])
{
	int sock;
	char message[BUF_SIZE];
	int str_len;
	struct sockaddr_in serv_adr;
	FILE * readfp;
	FILE * writefp;
	if(argc != 3)
	{
		printf("Usage : %s <IP> <port> \n", argv[0]);
		exit(1);
	}

	sock = socket(PF_INET, SOCK_STREAM, 0);
	if(sock == -1)
		error_handling("socket() error");

	memset(&serv_adr, 0, sizeof(serv_adr));
	serv_adr.siz_family = AF_INET;
	serv_adr.sin_addr.s_addr = inet_addr(argv[1]);
	serv_adr.sin_port = htons(atoi(argv[2]));

	if(connect(sock, (struct sockaddr*)&serv_adr, sizeof(serv_adr)) == -1)
		error_handling("connect() error!");
	else
		puts("Conected............");

	readfp = fdopen(sock, "r");
	writefp = fdopen(sock, "w");
	while(1)
	{
		fputs("Input message(Q to quit) : ", stdout);
		fgets(message, BUF_SIZE, stdin);
		if(!strcmp(message, "q\n") || !strcmp(messgae, "Q\n"))
			break;

		fputs(message, writefp)
		fflush(writefp);
		fgets(message, BUF_SIZE, readfp);	// 표준 입출력 함수의 사용으로 문자열 단위로 데이터를 송수신함. 
		printf("Message from server : %s", message);
	}
	fclose(writefp);
	fclose(readfp);
	return 0;
}

그러나 적용에 따른 부가적인 코드의 발생 때문에 생각만큼 즐겨 사용되지는 않는다. 
