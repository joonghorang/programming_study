chapter 18 Node.js에서 익스프레스를 구현
익스프레스는 Node.js에서 손쉽게 사용할 수 있는 http 모듈의 기능을 한 번 감싼 경량화된 모듈이다. 
또한 사용자들이 서버의 루트 및 요청, 쿠키, HTTP 요청 상태 등을 더 쉽게 다룰 수 있도록 기존 http 모듈의 기능을 확장한다. 

익스프레스 시동
Node.js프로젝트에서 익스프레스를 시동하는 방법은 매우 간단하다. 

var express = require('express');
var app = express();

익스프레스 설정 구성
익스프레스는 익스프레스 서버의 동작 제어 설정을 위한 여러 애플리케이션을 제공한다. 
이를 통해 익스프레스 핸들러가 JSON 파싱(parsing)이나 루팅routing, 뷰(view)를 처리하는 방법 뿐 아니라
환경을 설정할 수 있다. 

express 객체는 애플리케이션 설정 값 지정을 위한 set(setting, value)과 
enable(setting), disable(setting)메소드를 제공한다. 예를 들어 다음 코드는 trust porxy설정을 
활성화하고 jade에 view engine을 지정한다. 

app.enable('trust proxy');
app.disable('strict routing');
app.set('view engine', 'jade');

설정 값을 가져오려면 get(setting)과 enabled(setting), disabled(setting)메소드를 사용한다. 
예를 들면 다음과 같다. 

app.enalbed('trust proxy'); // true
app.disalbed('strict routing'); // true
app.get('view engine'); // jade 

익스프레스 애플리케이션 설정 
env // 문자열 형태의 환경 모드를 정의한다. 예를 들면 development나 testing, production과 같은 값으로
	// 기본 값은 process.env.NODE_ENV다. 
trust proxy // 리버스 프락시(reverse proxy)지원을 활성화/비활성화 한다. 기본 값은 disabled다. 
jsonp callback name // JSONP 요청의 기본 콜백 이름을 지정한다. 기본 값은 ? callback = 다.
json replacer // JSON replacer 콜백 함수를 정의한다. 기본 값을 null이다. 
json spaces // JSON 응답을 포맷팅할 때 사용할 공간을 숫자로 정의한다. 기본 값을 개발 시 2이고 배포(production)시 0이다. 
case sensitive routing // 대소문자 구분(case-sensitivity)을 활성화/비활성화한다. 예를 들어 /home은/ Home과 같지 않다. 
						// 기본 값은 disabled이다. 
strict routing // 엄격한 루팅(strict routing)을 활성화/비활성화한다. 예를 들어 /home은 /home/과 같지 않다. 기본 값을 disabled dlek. 
view cache // 뷰 템플릿을 컴파일할 때 캐시 사용여부를 활성화/비활성화 하는 것으로, 컴파일된 템플릿의 캐시 버전을 유지할 것인지를 정의한다. 
			// 기본값은 enabled이다. 
view engine // 뷰의 파일 확장자가 생략된 경우 템플릿을 렌더링할 떄 사용돼야 할 기본 템플릿 엔진의 확장자를 정의한다.
views // 뷰 템플릿을 탐색할 때 사용되는 템플릿 엔진의 경로를 지정한다. 기본 값은 ./views다. 

익스프레스 서버 시동 
ex) 익스프레스를 사용한 HTTP와 HTTPS를 구현 

var express = require('express');
var https = require('https');
var http = require('http'); 
var fs = require('fs');
var app = express();
var options = {
	host : '127. 0. 0. 1',
	//key : fs.readFileSync('ssl/server.key'),
	//cert : fs.readFileSync('ssl/server.crt')
};
http.createServer(app).listen(8000);
//https.createServer(options, app).listen(443);
app.get('/', function(req, res){
	res.send('Hello from Express');
});

*https는 키와 인증파일이 있어야 하기 때문에 패스. 


루트 환경 구성 

루트는 익스프레스 서버에서 HTTP요청이 URI에 대한 경로 일부분을 다루기 위해 단순화해 정의한 것이다. 
루트 구현
루트는 두 부분으로 정의할 수 있다. 첫째는 HTTP 요청 메소드(일반적으로 GET이다 POST)다. 
두 번째는 URL에 정의된 경로(path)다. 예를 들어 /는 웹사이트의 루트를 의미하고,
/login은 로그인 페이지를, /cart는 쇼핑 카드를 보인다. 
이러한 메소드들은 완전히 서로 다르게 처리돼야한다. 

익스프레서 서버에서 루트트 구현하기 위해 필요한 다양한 함수들은 아래의 문법을 사용한다. 
app.<method>(path, [callback...], callback)
위 문법의 <method>는 GET이나 POST같은 HTTP 요청 메소드와 연관돼 있다. 
예를들면
app.get(path, [middleware, ...], callback)
app.post(path, [middleware, ...], callback)

path는 콜백 함수에 의해 처리될 URL의 경로이다. 
middleware는 콜백함수가 실행되기 전에 적용될 미들웨어 함수다. 
callback 파라미터는 요청을 처리하고 클라이언트에 응답을 반환하는 요청 핸들러request handler다. 
callback 파라미터는 첫번째 파라미터로 Request 객체를, 두 번째 파라미터로 Response객체를 전달받는다. 
ex)
app.get('/', function(req, res){
	res.send("Server Root");
});
app.get('/login', function(req, res){
	res.send("Login Page");
});
app.post('/save', function(req, res){
	res.send("Save Page");
});

익스프레스 서버가 HTTP 요청을 전달받으면 적절한 HTTP 메소드와 경로로 정의된 루트를 찾는다.
하나가 찾아지면, Request와 Response 객체가 생성돼 요청을 관리하고 루트에 대한 콜백함수로 전달된다. 

익스프레스는 또한 app.post()와 app.get() 메소드와 완전히 동일하게 동작하는 app.all()메소드를 제공한다.
단 하나의 차이점은 HTTP메소드가 뭐든 상관없이 app.all() 메소드의 콜백 함수가 정의된 경로(path)의 모든 요청에
대해 호출된다는 점이다. 또 다른 특징은 경로(path)에 와일드카드(*)로 문자를 입력할 수 있다는 점이다. 
요청을 로깅하거나 요청 처리를 위한 특별 기능을 구현할 수 있다. 
ex)
app.all('*', function(req, res){
	//global handler for all paths
});
app.all('/user/*', function(req, res){
	//global handler for /user path
});


루트에 파라미터를 적용
루트를 구현하기 시작하면서 복잡한 시스템을 보게 된다면, 수많은 루트가 도를 넘게 정의된 것을 확인 할 수 있다.
루트의 수를 줄이기 위해서는 URL내에 파라미트를 구현할 수 있다. 
파라미터를 사용해 동일한 루트에 고유 값을 포함시켜 유사하지만 서로 다른 요청을 처리함으로써 애플리케이션이
요청을 처리하고 응답을 생성할 수 있다. 

예를 들어 시스템의 모든 사용자와 제품별로 별개의 루트를 가질 필요는 없다. 대신 하나의 로트에 사용자 ID
와 제품 ID를 파라미터로 넘기고 서버단에서 해당 ID를 어떤 사용자 혹은 제품인지를 판단하는 데 사용한다 .
다음은 루트에 파라미터를 적용하기 위해 사용되는 4가지 방법이다. 

1. 질의 문자열 : 일반적으로 많이 사용하는 HTTP 질의 문자열인 ?key=value&key=value...를 URL경로뒤에
붙이면 된다. 이 방법이 파라미터를 구현하는 데 가장 많이 사용되는 것이지만 URL의 길이가 매우 길어지고
복잡해 질 수 있다. 

파라미터를 얻는 방법은 url.parse()를 사용해 Request객체의 url속성을 파싱한다. 
다음코드는 author와 title파라미터를 전달하는 
/find?author=<author>&title=<title>의 기본적인 GET루트를 구현한 예다. /
author와 title의 실제 값을 가져오기 위해 
url.parse() 메소드를 사용해 질의 객체를 생성한다. 

var express = require('express');
var url = require('url');
var app = express();
var http = require('http');
http.createServer(app).listen(8000);
app.get('/find', function(req, res){
	var url_parts = url.parse(req.url, true);
	var query = url_parts.query;
	res.send('Finding Book : Author: ' + query.author + ' Title : ' + query.title);
});
주소창 예문
http://localhost:8000/find?author=Brad&title=Node

2. POST 파라미터 : 웹 폼(web form)을 구현하거나 또다른 POST 요청을 처리할 때 요청시 몸체(body)에 
파라미터를 담아 전송할 수 있다. 

3. 정규 표현식(Regexes) : 루트의 경로 부분에 정규 표현식을 사용할 수 있다. 
익스프레스는 이 정규표현식을 URL의 경로를 파싱하는 데 사용하며, 매치되는 표현을 파라미터 배열로 저장한다. 
ex)
app.get(/^\/book\/(\w+)\:(\w+)?$/, function(req,res){
	res.send('Get Book : Chapter : ' + req.params[0] + 'Page : ' + req.params[1]);
});
이런식으로 파라미터 값에 아무것도 정의되지 않은 것을 볼 수 있다.
대신 req.param은 URL경로상에서 정규표현식과 매치되는 아이템들을 배열로 저장한다. 
예를 들어 다음 URL로 가정해보자.
/book/12:15
이 경우 res.send() 는 다음을 반환한다.
Get Book : Chapter : 12 Page : 15

4. 선언된 파라미터(Defined Parameters) : 루트의 경로 부분에 <param_name>를 사용해 파라미터의 
이름으로 정의할 수 있다. 익스프레스는 경로를 파싱할 때 자동으로 파라미터를 이름으로 할당한다.

데이터가 구조화돼 있다면 정규표현식을 사용하는 대신 선언된 파라미터를 사용한다.
선언된 파라미터를 사용하면 루트 경로route path내에 파라미터를 이름으로 정의할 수 있다. 
즉 <param_name>을 사용해 루트의 경로를 파라미터로 정의한다. 선언된 파라미터를 사용할 때 
req.param은 배열이 아닌 함수로 req.param(param_name)와 같이 호출해 파라미터 값을 반환받는다. 

다음 코드는 /user/<user_id> 포맷의 URL에 대한 기본적인 :userid 파라미터를 구현한 예다. 
app.get('/user/:userid', function(req, res){
	res.send("Get User: " + req.param("userid"));
});

/user/4983으로 접속하면
Get User : 4983을 반환한다. 

선언된 파라미터에 콜백함수를 적용
선언된 파라미터를 사용할 때 가장 큰 장점은 URL에서 선언된 파라미터를 찾았을 때 실행되는 콜백함수를
등록할 수 있다는 점이다. URL을 분석할 때 익스프레스가 콜백이 등록된 파라미터를 찾으면 루트 핸들러를
호출하기 전에 파라미터의 콜백 함수를 먼저 호출한다. 

하나의 루트에는 하나 이상의 콜백 함수를 등록할 수 있다. 
콜백 함수를 등록하려면 app.param() 메소드를 사용한다. 
app.param()메소드는 선언된 파라미터를 첫 번째로 전달받고
두 번째로 Request와 Response, next, value 파라미터를 받는 콜백함수를 전달받는다. 
app.param(param, function(req, res, next, value){});

Request와 Response객체는 루트의 콜백에 전달되는 객체와 동일하다. 
next 파라미터는 app.param()콜백 함수 다음에 호출될 콜백 함수가 있다면 해당 콜백 함수를 지정한다. 
이 때 반드시 콜백 함 수 내 어디에선가 next()를 호출해야 콜백 체인이 깨지지 않는다. 
value파라미터는 URL 경로로부터 파싱된 파라미터의 값이다. 

예를 들어 다음 코드는 루트에 userid파라미터가 정의된 모든 요청에 적용된다. 
콜백 함수를 벗어나기 전에 next()를 호출하는 것에 유의한다. 
app.param('userid', function(req, res, next, value){
	console.log("Request with userid : " + value); // browser가 아닌 콜솔에 출력된다. 
	next(); // 이 녀석을 호출하고 나가야 콜백체인이 깨지지 않는다. 
});

루트 파라미터 적용 예
var express = require('express');
var url = require('url');
var app = express();
app.listen(8000);
app.get('/', function (req, res){
	res.send("Get Index");
});
app.get('/find', function(req, res){
	var url_parts = url.parse(req.url, true);
	var query = url_parts.query;
	var response = "Finding Book : Author : " + query.author + ' Title : ' + query.title;
	console.log('\nQuery URL : ' + req.originalUrl);
	console.log(response);
	res.send(response);
});
app.get(/^book\/(\w+)\:(\w+)?$/, function(req, res){
	var response = 'Get Book : Chapter : ' + req.params[0] + ' Page : ' + req.params[1];
	console.log('\nRegex URL: ' + req.originalUrl);
	console.log(response);
	res.send(response);
});
app.get('/user/:userid', function(req, res){
	var response = 'Get User : ' + req.param('userid');
	console.log('\nParam URL: ' + req.originalUrl);
	console.log(response);
	res.send(response);
});
app.param('userid', function(req, res, next, value){
	console.log("\nRequest received with userid: " + value);
	next();
});



Request 객체 사용
루트 헨들러('/')는 첫 번째 파라미터로 req객체를 전달받는다. 
req객체는 요청 데이터와 메타데이터를 제공하고,
URL과 헤더, 질의 문자열 등을 더 포함한다. 
객체는 코드 내에서 요청을 적절하게 가공할 수 있게 한다. 

HTTP Request 객체의 속성과 메소드
originalUrl // 요청에 대한 원본 URL 문자열이다. 
protocol // http나 https와 같은 프로토콜을 나타내는 문자열이다. 
ip // 요청에 대한 IP 주소다
path // 요청 URL에 대한 경로다. 
host // 요청에 대한 호스트 이름이다. 
method // GET이나 POST등 HTTP 메소드다. 
query // 요청 URL에 대한 질의 문자열이다. 
fresh // Boolean 형식으로 현재본이 가장 마지막에 수정된 것과 일치한다면 true를 반환
stale // Boolean 형식으로 현재본이 가장 마지막에 수정된 것과 일치한다면 false를 반환
secure // Boolean 형식으로 TLS 연결이 수립돼싿면 true를 반환한다. 
acceptsCharset(charset) // charset으로 정의된 문자셋이 지원되는 형식이라면 true를 반환하는 메소드
get(header) // header의 값을 반환하는 메소드다. 
headers // 요청받은 헤더 객체다. 

예제코드
var express = require('express');
var app = express();
app.listen(8000);
app.get('/user/:userid', function(req, res){
	console.log("URL:\t " + req.originalUrl);
	console.log("Protocol: " + req.protocol);
	console.log("IP:\t " + req.ip);
	console.log("Path:\t " + req.path);
	console.log("Host:\t " + req.host);
	console.log("Method:\t " + req.method);
	console.log("Query:\t " + JSON.stringify(req.query));
	console.log("Fresh:\t " + req.fresh);
	console.log("Stale:\t " + req.stale);
	console.log("Secure:\t " + req.secure);
	console.log("UTF8:\t " + req.acceptsCharset('utf8'));
	console.log("Connection: " + req.get('connection'));
	console.log("Headers: " + JSON.stringify(req.headers, null, 2));
	res.send("User Request");
});

헤더 설정
적절한 http응답을 생성할 때 중요한 부분은 헤더를 설정하느 ㄴ것이다. 
예를 들어 Content-Type 헤더를 설정해 브라우저에게 응답을 어떻게 처리해야 할지를 설정할 수 있다. 
Response객체는 여러 헤더 메소드를 제공하므로 HTTP응답으로 전달될 헤더값을 가져오거나 설정할 수 있다 .

가장 많이 사용되는 메소드는 get(header)와 set(header, value)로, 헤더 값을 가져오거나 설정하기 위한
메소드다. 예를 들어 다음 코드는 먼저 Content-Type 헤더를 가져온 후 헤더에 값을 설정한다. 
var oldType = res.get('Content-Type');
res.set('Content-Type', 'text/plain');

아래는 값을 가져오고 설정하는 것을 도와주는 메소드다. 
get(header) // header 파라미터에 정의된 값을 반환
set(header, value) // header 파라미터에 값을 설정
set(headerObj) // 'header':'value'로 만들어진 여러 속성을 가진 객체를 전달받는다. 
				// headerObj 파라미터 내 각 헤더는 Response객체에 설정된다. 
location(path) // path 파라미터로 정의된 값으로 위치 헤더를 설정한다. 
				// path는 /login과 같은 URL 경로이거나, http://server.net/같은 절대경로,
				// .../users와 같은 상대경로, back과 같은 브라어저 액션으로 정의된다. 
type(type_string) // type_string 파라미터를 기반으로 Content-Type헤더를 설정한다. 
					//type_string파라미터는 application/json과 같이 일반적인 컨텐트 형식이거나
					// png와 같은 특정 형식이거나, .html과 같은 파일 확장자다. 
attachment([filepath]) // attachment에 Content-Disposition헤더를 설정한다. 
						// filepath가 지정됐다면 Content-Type 헤더는 파일 확장자에 기반해 설정된다. 

상태(status) 설정
응답에 대한 HTTP 상태 값을 200보다 큰 값으로 설정해야 한다. 
상태응답을 설정하기 위해서는 status(number)메소드를 사용하고 number파라미터는
hTTP 스펙에 정의된 HTTP 응답 상태값으로 지정한다. 
res.status(200); // 성공
res.status(300); // 리다이렉션
res.status(400); // 잘못된 요청
res.status(401); // 인증 실패
res.status(403); // 접근 권한 없음
res.status(500); // 서버에러 

응답전송
send()메소드는 다음 포맷을 따른다. 
res.send(status, [body])
res.send([body])

status는 HTTP 상태 코드이며 body는 string 혹은 Buffer객체이다. 
Buffer객체를 지정한다면, Content-Type은 명시적으로 다른 값으로 지정하지 않는 한 
자동으로 application/octet-stream가 된다. 
ex)
res.set('Content-Type', 'text/html');
res.send(new Buffer('<html><body>HTML String</body></html>'));

send()는 적절한 헤더와 상태를 가진 응답이라면 모두 처리할 수 있다. 
send()메소드가 실행되면, res.finished나 res.headerSent 속성에 값을 지정한다. 
이 속성은 응답이 전달됐는지나 얼마나 많은 양의 데이터가 전송됐는지를 검증할 때 사용할 수 있다. 
다음은 res.headerSent 속성에 대한 예다. 

HTTP/1.1 200 OK
X-Powered-By : Express
Content-Type : text/html
Content-Length : 92
Date : Tue, 17 Dec 2013 18:52:23 GMT
Connection : keep-alive

ex) response객체를 사용해 상태 및 헤더, 응답 데이터를 전송 
var express = require('express');
var url = require('url');
var app = express();
app.listen(8000);
app.get('/', function(req, res){
	var response = '<html><head><title>Simple Send</title></head>' +
					'<body><h1>Hello from Express</h1></body></html>';
	res.status(200);
	res.set({
		'Content-Type' : 'text/html',
		'Content-Length' : response.length
	});
	res.send(response);
	console.log('Response Finished? ' + res.finished);
	console.log('\nHeaders Sent : ');
	console.log(res.headerSent); // express4.0이후로는 res.headerSent 속성 사용불가. 
});
app.get('/error', function(req, res){
	res.status(400);
	res.send("This is a bad request.");
});


JSON응답 내역 전송 
최근에는 서버에서 클라이언트로 정보를 전달하는 방법으로 JSON 데이터를 사용하는 경향이 있다. 
JSON을 사용하면 클라이언트가 동적으로 페이지에 HTML 엘리먼트를 덧붙일 수 있어
서버가 HTML문서 혹은 일부를 생성해 클라이언트에 HTML을 전송하지 않아도 된다. 
익스프레스는 관련 함수로 json()과 jsonp() 메소드를 제공한다. 
이 메소드들은 body가 JSON을 문자열 형태로 풀어주는 자바스크립트 객체인 경우만 제외하고는
send()메소드가 거의 유사한 문법을 가진다. 

res.json(status, [object])
res.json([body])
res.jsonp(status, [object])
res.jsonp([object])

이렇게 되면 자바스크립트 객체가 JSON문자열로 변환되어 클라이언트에 반환된다. 
jsonp()의경우 요청 객체의 URL이 ?callback=<method> 파라미터를 포함하면, JSON문자열이 해당
메소드 이름의 함수로 감싸지므로 이 이름은 JSONP 설계에 따라 클라이언트 브라우저에서 호출될 수 있다. 

예제코드
var express = require('express');
var url = require('url');
var app = express();
app.listen(8000);
app.get('/json', function(req, res){
	app.set('json spaces', 4);
	res.json({name:"Smithsonian", built:'1846', items:'137M',
			centers: ['art', 'asee', 'natura', 'planet', 'biology', 'space', 'zoo']});
});
app.get('/error', function(req, res){
	res.json(500, {status:false, message: "Internal Server Error"});
});
app.get('/jsonp', function(req, res){
	app.set('jsonp callback name', 'cb');
	res.jsonp({name:"Smithsonian", built:"1846", items:'137M',
			centers: ['art', 'ast', 'naural', 'planet', 'biology', 'space', 'zoo']});
});




파일전송
대표적인 함수는 Response객체의 
sendfile(filepath)다. 
sendfile()은 파일을 클라이언트에 전송하기 위해 필요한 모든 동작을 단일 함수로 진행한다. 
특히 다음 동작을 포함한다. 
- 파일 확장자에 기반해 Content-Type 헤더에 형식을 설정한다. 
- Content-Length와 같이 다른 필요한 헤더를 설정한다. 
- 응답 상태를 설정한다. 
- response 내부의 연결을 사용해 클라이언트에 파일의 내용을 전송한다. 

문법은 다음과 같다. 
res.sendfile(path, [options], [callback])
path는 클라이언트에 전송하고 싶은 파일을 지정해야 한다. 
option 파라미터는 maxAge속성을 포함한 객체로 콘텐츠의 최대 수명을 지정하고,
상대 경로로 path 파라미터를 지원하기 위해 root속성으로 루트 경로를 지정한다. 
콜백 함수는 파일 전송이 완성되면 호출되며 단 하나의 파라미터로 에러를 전달받는다. 

예제코드
var express = require('exrpess');
var url = require('url');
var app = express();
app.listen(8000);
app.get('./image', function(req, res){
	res.sendfile('fruit.txt',
				{ maxAge : 1, // 24*60*60*1000,
				  root : './views/'},
				  function(err){
				  	if(err){
				  		console.log("Error");
				  	} else{
				  		console.log("Success");
				  	}
				  }

				});
});

다운로드 응답 전송
익스프레스는 몇 가지 소사한 차이점을 빼고 
res.sendfile()과 매우 유사하게 동작하는
res.download() 메소드를 포함한다. 
res.download()메소드는 HTTP 응답에 첨부해 파일을 전송하고
Content-Disposition 헤더를 설정한다. 
res.download()메소드는 다음과 같은 문법을 갖는다.
res.download(path, [filename], [callback]);
ex)
app.get('/file', function(req, res, next){
	var path = './fruit.txt';
	res.download(path);
});

응답 리다이렉팅
res.redirect(path); 메소드는 새로운 위치로 요청을 리다이렉션 할 수 있게 해준다. 
ex)
var express = require('express');
var url = require('url');
var app = express();
app.listen(8000);
app.get('/google', function(req, res){
	res.redirect('http://google.com');
});
app.get('/first', function(req, res){
	res.redirect('/second');
});
app.get('/second', function(req, res){
	res.send("Response from Second");
});
app.get('/level/A', function(req, res){
	res.redirect("/level/B");
});
app.get('/level/B', function(req, res){
	res.send("Response from Level B");
});

* ejs형식과 html형식을 겸용해서 사용하고 싶다면
app.engine('html', require('ejs').renderFile); 로 등록한다. 

































