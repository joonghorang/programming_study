chapter 4. Node.js에서 이벤트, 리스너, 타이머, 콜백을 사용

Node.js에서는 이벤트 풀 방식이기 때문에 개별 스레드는 지정된 순서에 따라 실제 실행되지 않는다. 
예를 들어 DB를 사용하는 요청은 그렇지 않은 용청에 비해 완료 시간이 길기 때문에 나중에 호출될 수 있다. 

이벤트 콜백을 사용하는 Node.js의 이벤트 모델은 블로킹 I/O함수를 만나기 전까지는 강력하다. 
블로킹 I/O는 현재 스레드의 수행을 중단시키고 지속적으로 응답을 기다린다. 
블로킹 I/O의 종류는 다음과 같다. 

- 파일 읽기
- 데이터베이스 질의
- 소켓 요청
- 원격 서비스 접속. 

Node.js는 블로킹 입출력으로 인한 지연을 피하고자 이벤트 콜백을 사용한다. 그래서 블로킹 입출력을 
수행한 어떤 요청이든 백그라운드의 다른 스레드에서 수행된다. Node.js는 백그라운드에서 스레드 풀을 
구현했다. 이벤트 큐에서 이벤트나 블록 입출력 이벤트가 얻어지면, Node.js는,
메인 이벤트 루프 스레드가 아닌, 스레드 풀에서 스레드 한 개를 꺼내어 해당 함수를 수행한다. 
이런 구조로 인해 이벤트 큐 내에 모든 잔여 이벤트들의 블로킹 입출력을 방지할 수 있다. 

블로킹 스레드 상에서 실행된 함수의 경우도 여전히 처리해야 할 작업에 대한 이벤트를 이벤트 큐에 추가할 수 있다.
데이터 베이스 질의 요청의 경우 일반적으로 결과를 분석해 응답을 보내기 전 이벤트 큐를 통해 
추가적인 작업을 하는 경우가 많다. 

대화 예제는 웹 서버의 처리 방식과 유사한 부분이 많다. 
빨리 끝나는 대화(예를 들어 간단한 메모리 내 일부 데이터 요청)도 있고,
여러 부분으로 나누어지는 다양한 대화(복잡한 서버단 대화와 유사)도 있다.
또한 다른 사용자의 응답을 오랫동안 기다리는 경우(파일 시스템이나 데이터베이스, 원격 서비스에 블로킹I/O요청)도 있다.
각 스레드가 자신의 클론clone처럼 동작하는 전통적인 스레드 웹 서버 모델이 대화 예제에 적합해 보일 것이다. 
스레드/클론은 사람들과 대화를 주고받을 수 있기 때문에 다중 대화의 동시 처리가 가능해 보인다. 
하지만 이 모델에는 두 가지 문제가 있다. 

첫째 문제는 작업을 처리할 수 있는 클론 수 제한이다. 
다섯 개의 클론이 있는 경우 여섯 번째 사람과 대화를 위해서는 하나의 클론이 반드시 종료돼야 한다. 
두 번째 문제는 스레드/클론이 공유해야 하는 제한된 수의 CPU/브레인이다. 
하나의 클론이 브레인을 사용하는 중에 다른 클론은 대기해야 한다. 
즉 브레인의 작업을 기다리는 클론이 발생하면 이 구조는 큰 장점을 갖지 못한다. 

Node.js이벤트 모델은 전통적인 웹 서버 모델에 비해 좀 더 현실 세계에 가깝게 동작한다. 
우선 Node.js 애플리케이션은 전통적인 웹 서버 모델이 사용하는 클론의 개념이 없이 단일 스레드로 수행된다.
사람들의 질문에 최선으로 응답하고 상호작용은 개별 사람들에 대상으로 이벤트 방식으로 처리된다. 
동시에 진행되는 많은 대화에 대해 개별 대화들을 오가며 처리할 수 있다. 
다음으로 브레인을 공유하지 않기 때문에 대화를 나누고 있는 사람에게 집중할 수 있다. 

응답을 위해 시간이 필요한 질문을 요청받은 경우 어떤 상황이 발생할까?
질문에 대한 답변을 머릿속으로 생각하고 있는 동안에도 파티의 다른 사람과 대화가 가능하다.
생각할 시간이 많이 필요한 작업을 처리한느 동안에 비록 상대방과의 응답시간이 느려질 수 는 있지만
여전히 다른 사람과 대화할 수 있다. 

이런 내용은 Node.js가 백그라운드 스레드 풀을 사용해 블로킹 I/O 요청을 처리하는 방법과 유사하다. 
Node.js는 블로킹 요청을 스레드 풀 내 스레드에 옮겨서 처리하기 때문에 애플리케이션 처리 이벤트에 
영향은 최소화된다. 



이벤트 큐에 작업을 추가

node.js애플리케이션을 작성할 때는 이전 절에서 설명한 이벤트 모델을 고려해야 한다. 
이벤트 모델의 확장성과 성능을 향상시키려면 작업을 연속된 콜백으로 수행되는 단위로 나눠야 한다. 
Node.js 애플리케이션은 다음 함수들을 사용해 콜백 함수를 이벤트 큐의 작업으로 등록 가능하다. 
	- 파일을 작성하거나 데이터베이스에 연결하는 등의 블로킹 I/O라이브러리 호출을 사용
	- http.request나 server.connection과 같은 빌트인 이벤트에 이벤트 리스너를 추가
	- 이벤트 이미터(emitter)를 작성해 고유한 리스너를 추가
	- process.nextTick 옵션을 사용해 다음 이벤트 루프 사이클에 선택될 작업을 스케줄링
	- 타이머를 사용해 특정 시간 이후나 주기적인 간격으로 작업을 스케줄링 

타이머 구현 
Node.js와 자바스크립트의 유용한 기능으로 특정 시간 동안 코드의 실행을 지연시키는 기능이 있다. 
이를 이용해 항상 실행되길 원치 않는 작업을 정리하거나 새로 고침을 위한 작업을 할 수 있다. 
Node.js에는 timeout, interval, immediate가 있다. 

1)timeout예제
특정 시간이 지난후 실행되게 하는 함수이다. 
ex)
function writeText(){
	console.log("2seconds passed.");
}
setTimeout(simpleTimeout, 2000, "2초");

2)인터벌 타이머로 주기적 작업 수행
ex)
function myFunc(){
	console.log("2s");
}
setInterval(myFunc, 2000);

3) 이미디어트 타이머를 사용해 즉시처리 작업 수행하기 
이 함수는 I/O이벤트 콜백 함수의 수행 시작과 함께 다른 어떤 타이머보다 먼저 수행되기를 원하는 작업을
처리하는 데 사용된다. 현재 처리되고 있는 이벤트 큐의 작업이 완료된 후 다른 작업에 우선해 요청 작업이
스케줄링된다. 
긴 수행 시간을 가진 작업에 의해 I/O 이벤트가 오랫동안 수행되지 못하는 경우를 예방할 수 있다. 
이 함수는 실행후, 타이머 객체 ID를 반환한다. 
ex)
var myImmediate = setImmediate(myuFunc, 1000);
해당 함수의 타이머를 취소하려면
clearImmediate(myImmediate);


이벤트 리스너와 이벤트 이미터 구현
이벤트는 events 모듈에 포함된 EventEmitter 객체를 사용해 발생시킬 수 있다. 
emit(eventName, [args]) 함수는 eventName 이벤트를 유발시키고 제공된 전달인자를 포함한다. 
다음 코드는 간단히 이벤트 에미터를 구현하는 방법이다. 
var events = require('events');
var emitter = new events.EventEmitter();
emitter.emit("simpleEvent");

(클라이언트 코드의 이벤트 등록 및 실행과 유사하다)
ex)
var events = require('events');
function Account(){
	this.balance = 0;
	events.EventEmitter.call(this);
	this.deposit = function(amount){
		this.balance += amount;
		this.emit('balanceChanged');
	};
	this.withdraw = function(amount){
		this.balance -= amount;
		this.emit('balanceChanged');
	};
}
Account.prototype.__proto__ = events.EventEmitter.prototype;
function displayBalance(){
	console.log("Account balance : $%d", this.balance);
}
function checkOverdraw(){
	if(this.balance < 0){
		console.log("Account overdrawn!!!");
	}
}
function checkGoal(acc, goal){
	if(acc.balance > goal){
		console.log("Goal Achieved!!!");
	}
}
var account = new Account();
account.on("balanceChanged", displayBalance);
account.on("balanceChanged", checkOverdraw);
account.on("balanceChanged", function(){
	checkGoal(this, 1000);
});
account.deposit(220);
account.deposit(320);
account.deposit(600);
account.withdraw(1200);


콜백 구현

콜백 함수에 추가 전달인자 보내기
대부분의 콜백은 자동으로 오류나 버퍼의 내용을 자동으로 전달인자로 받는다. 
콜백 함수를 처음 사용하는 사람들이 많은 전달인자를 보내는 방식에 의문을 가질 것이다. 
익명함수를 사용해 전달인자를 만들고,
익명함수 내에서 콜백함수를 전달인자와 함께 사용하는 방식을 사용할 수 있다. 

예제 코드
var events = require("events");
function CarShow(){
	events.EventEmitter.call(this);
	this.seeCar = function(carName){
		this.emit('sawCar', carName);
	};
}
CarShow.prototype.__proto__ = events.EventEmitter.prototype;
var show = new CarShow();
function logCar(carName){
	console.log("Saw a " + carName);
}
function logColorCar(carName, color){
	console.log("Saw a %s %s", color, carName);
}
show.on("sawCar", logCar);
show.on("sawCar", function(carName){
	var colors = ["red", "blue", "black"];
	var color = colors[Math.floor(Math.random()*3)];
	logColorCar(carName, color);
});
show.seeCar("Ferrari");
// show.seeCar("Porsche");
// show.seeCar("Bugatti");
// show.seeCar("Lamborghini");
// show.seeCar("Aston Martin");

콜백내 클로저 구현
비동기 콜백 방식의 흥미로운 문제는 클로져(closure)다. 
클로저는 자바스크립트 용어로 변수가 함수 범위에 속하고 부모 함수 범위에는 속하지 않는 것을 
의미한다. 목록을 순환하면서 값을 변경하는 경우처럼 
비동기 콜백을 수행할 때 부모 함수의 범위는 변한다. 

콜백 함수에서 ㅁ부모 함수 범위에 있는 변수에 접근하려면 
클로저를 제공해 이벤트 큐에서 콜백 함수가 빠져 나올 때 
해당 변수가 사용 가능하도록 만든다. 

이를 위한 기본적인 방법은 함수 블록 내에서 비동기 함수 호출을 캡슐화하고 필요한 변수를 전달하는 것이다. 

예제 코드
function logCar(logMsg, callback){
	process.nextTick(function(){ 		// 함수를 진정 비동기로 만드는 방법. 
		callback(logMsg);
	});
}
var cars = ["Ferrari", "Porsche", "Bugatti"];

for (var idx in cars){
	var message = "Saw a " + cars[idx]; // 이렇게 되면 비동기적으로 코드가 실행되어, 이미 message에는 멘 마지막 Bugatti가 들어 있어서 
										// 이 변수가 함수 인자로 전달되어 버린다. 
	logCar(message, function(){
		console.log("Normal Callback: " + message);
	});
}

for (var idx in cars){					
	var message = "Saw a " + cars[idx]; // 반대로 이렇게 되면 message자체를 인자로 그때 그때 전달했기 때문에, 
										// 해당 함수는 그 때 당시의 인자가 들어갈 수 있게 된다. 
	(function(msg){
		logCar(msg, function(){
			console.log("Closure Callback: " + msg);
		});
	})(message);
}

콜백 체인 구성
비동기 함수의 경우 이벤트 큐에 있는 두 함수의 실행 순서를 보장할 수 없다. 
이를 해결하기 위한 최선의 방법은 비동기 함수 내에서 다른 비동기 함수를 호출하는 방식으로
콜백 체인을 구성하는 것이다. 

이 경우 비동기 함수는 이벤트 큐에 한 번 이상 속하지 않는다. 
예제 코드는 아래와 같다. 
// 하나씩 순차적으로 비동기 콜백을 사용해 실행되는 함수다. 
// 중요하니 잘 봐두었다가 훗날 필요할 때 써먹도록 한다. 

function logCar(car, callBack){ 
	console.log("Saw a %s", car);
	if(cars.length){ // 만약에 차가 하나도 남아 있지 않으면 콜백함수가 실행되지 않는다. 
		process.nextTick(function(){
			callBack();
		});
	}
}
function logCars(cars){ // 약간 재귀함수 같은 구조. 
	var car = cars.pop();	// 함수에 들어올 때 마다 차 배열에서 하나 씩 제거
	logCar(car, function(){ // 제거된 배열을 다시 재귀 함수에 삽입하고 콜백함수로 자기자신에 자동차를 넣은 함수를 전달 
		logCars(cars);
	});
}
var cars = ["Ferrari", "Porsche", "Bugatti", "Lamborghini", "Aston Martin"];
logCars(cars);

