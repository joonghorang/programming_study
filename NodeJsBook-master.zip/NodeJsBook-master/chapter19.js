chapter 19 익스프레스 미들웨어 구현 

미들웨어의 이해 
익스프레스는 요청을 전달받은 시점부터 실제로 요청을 처리하고 응답을 전송하는 시점까지의 사이에서
추가 기능을 제공하는 단순하지만 효과적인 미들웨어 프레임워크다. 
미들웨어는 인증이나 쿠키, 세션을 구현하게 하거나, 요청이 핸들러에 전달되기 전에 조작할 수 있게 한다. 

익스프레스는 'connect'라는 NPM 모듈의 상위 계층에 생성됐으므로, 다음 connect에 의해 제공되는 미들웨어
지원을 제공한다. 

다음은 익스프레스에 의해 지원되는 미들우에ㅓ 컴퍼넌트 목록이다. 

- static : 익스프레스 서버는 GET요청으로 전달되는 정작 파일의 스트리밍을 지원한다. 
			이 미들웨어는 express내에 구현돼 express.static()과 같이 접근할 수 있다. 

- express-logger : 서버에 전달된 요청을 추적하기 위해 정형화된 요청 로거(logger)를 구현한다. 

- basic-auth-connect : 기본 HTTP인증을 지원한다. 

- cookie-parser : 요청으로부터 쿠키를 읽고 응답에 쿠키를 설정하는 것을 지원한다. 

- cookie-session : 쿠키 기반 세션을 지원한다. 

- express-session : 꽤 견고한(robust)세션 구현을 지원한다. 

- body-parser : POST요청의 본문(body)에 포함된 JSON 데이터를 파싱해 req.body 속성에 넣는다. 

- compression : 클라이언트에 대용량의 응답을 보낼 때 Gzip압축을 지원한다. 

- csurf : 위조 방지를 위한 크로스 사이트(cross-site)요청을 지원한다. 

19장에 나오는 예제들을 다루기 위해서는 아래의 모듈을 설치해야한다. 
npm install basic-auto-connect@1.0.0
npm install body-parser@1.0.2
npm install connect-mongo@0.4.0
npm install cookie-parser@1.0.1
npm install cookie-session@1.0.1
npm install express-sesiion@1.0.3



경로 전역에 미들웨어를 할당
미들웨어를 모든 루트에 할당하려면 익스프레스 app객체의 use()메소드를 구현한다. 
use( [path], middleware)

path변수는 선택적이며 기본 값은 모든 경로를 의미하는 /다. 
middleware파라미터는 다음 문법을 따르는 함수다. 
function(req, res, next) // next는 다음에 실행될 메들웨어 함수 

각 미들웨어 컴포넌트는 적절한 미들웨어 함수를 반환하는 생성자를 포함한다. 
예를 들어 body-parser 미들웨어를 기본 파라미터로 모든 경로에 지정한다면 다음 문장과 같다. 
var express = require('express');
var bodyParser = require('body-parser');
var app = express();
app.use('/', bodyParser());


단일 루트에 미들웨어를 할당
path 파라티머 뒤에 body-parser 미들웨어를 전달해 단일 루트로 할당할 수 있다. 
예를 들어 다음 코드에서 /parsedRoute 에 대한 요청은 할당될 것이고, /otheRoute에 대한 요청은 할당되지 않는다. 

ex)
var express = require('express');
var bodyParser = require('body-parser');
var app = express();
app.get('/parsedRoute', bodyParser(), function(req, res){
	res.send('This requres was logged.');
});
app.get('/otherRoute', function(req, res){
	res.send('This requres was not logged.');
});


query 미들웨어 사용
이는 질의 문자열ㅇ르 URL에서 자바스크립트 객체로 변환해주고, 이 값을 req객체의 query속성에 저장한다. 
이녀석은 express4.0이후로부터 빌트인 되어있어 따로 require()함수를 호출하지 않아도 된다. 
var express = require('express');
var app = express();
app.get('/', function(req, res){
	var id = req.query.id; // 여기서 쿼리는 ?id=10&score=95와 같은 값일 수 있다. 
	var score = req.query.score;
	console.log(JSON.stringify(req.query));
	res.send("done");
});

정적 (html)파일 전달. 
static 미들웨어는 익스프레스 미들웨어에서 가장 일반적으로 많이 사용된다. 
이는 디스크렝서 클라이언트로 직접 정적 파일을 전송하는 것을 가능하게 한다. 
또한 자바스크립트 파일이나 CSS파일, HTML문서와 같이 변경되지 않는 것들에 사용할 수 있다. 
문법은 다음과 같다. 
express.static(path, [options])

path파라미터는 정적 파일과 관련된 루트 경로를 지정한다. 
options파라미터를 사용해 다음 속성들을 지정할 수 있다. 
	maxAge : 브라우저 캐시의 만료시간으로 밀리초 단위다. 기본 값은 0이다. 
	hidden : 불린 형식으로, true라면 숨김 파일을 전송할 수 있다. 기본 값은 false다.
	redirect : 불린 형식으로, true라면 요청 경로가 디렉토리이며 요청이 /로 시작하는 경로로 리다이렉션된다. 기본값은 true.
	index : 루트 경로에서 기본 파일 경로다. 기본 값은 index.html이다. 

두 가지 정적 루트를 구현하는 예제 코드
var express = require('express');
var app = express();
app.use('/', express.static('./static'), {maxAge:60*60*1000});
app.use('/images', express.static('../images'));
app.listen(8000);

이러면 index.html이 /static 폴더 안에 위치해야하고,
해당 html에서 ./css/static.css 경로로 파일을 로드해야한다. 


POST 본문 데이터 처리 
가장 많이 사용되는 또 다른 익스프레스 미들웨어는 POST 요청 내 포함된 본문 데이터를 처리하는 것이다 .
오청 본문 내 데이터는 POST파라미터 문자열이나 JSON문자열, 가공되지 않은 데이터 등 다양한 서식으로
되어 있다. 익스프레스의 body-parser 미들웨어는 요청 본문의 JSON데이터를 파싱해 req.body속성에 저장
을 시도하낟. 
예제코드
var express = require('express');
var bodyParser = require('body-parser'); // 하지만 오래된 미들웨어 이므로 알아보고 따른 걸 쓰자. 
var app = express();
app.use(bodyParser());
app.get('/', function(req, res){
	var response = '<form method="POST">' + 
		'First: <input type="text" name = "first"><br>' +
		'Last : <input type="text" name = "last"><br>' + 
		'<input type="submit" value = "Submit"></form>';
	res.send(response);
});
app.post('/', function(req, res){
	var response = '<form method="POST">' + 
		'First: <input type="text" name = "first"><br>' +
		'Last: <input type="text" name ="last"><br>' + 
		'<input type = "submit" value = "Submit"></form>' +
		'<h1>Hello ' + req.body.first + '</h1>';
	res.type('html');
	res.end(response);
	console.log(req.body);
});
app.listen(8000);


쿠키 주고받기
익스프레스의 cookie미들웨어를 사용하면 매우 간단하게 쿠키를 처리할 수 있다. 
cookie 미들웨어는 요청으로부터 쿠키를 파싱하고 자바스크립트 객체로 
req.cookies 속성에 저장한다. 다음 문법을 따른다. 
express.cookie([secret]);

secret 문자열 파라미터는 선택적으로 사용하며 내부의 secret 문자열을 사용한 사인된 쿠키(signed cookie)
에 의한 위조를 방지한다. 

응답에 쿠키를 설정하기 위해서는 res.cookie()메소드를 다음과 같이 사용한다. 
res.cookie(name, value, [options])

name과 value 파라미터가 정의된 쿠키가 응답에 추가된다. 
option파라미터에 쿠기에 대한 다음 속성을 지정하낟.
	maxAge : 쿠키가 소멸되기까지 살아있는 시간으로 밀리초 다누이다. 
	httpOnly : 불린 형식으로, true라면 쿠키가 서버에 의해서만 접근가능하며 클라이언트 측 
				자바스크립트에 의한 접근은 허용하지 않는다. 
	signed : 불린 형식으로, true 라면 쿠키가 사인될 것이므로 (signed) req.cookie 객체가 아닌
	req.signedCookie 객체를 사용해 접근해야 한다. 
	path : 쿠키를 적용할 경로다. 

ex)
res.cookie('hasVisited', '1', 
			{
				maxAge : 60*60*1000,
				httpOnly : true,
				path : '/'
			});

res.clearCookie() 메소드를 사용하면 클라이언트에서 쿠키를 삭제할 수 있다. 
ex)
res.clearCookie('hasVisited');

다음 예제는 요청으로부터 req.cookies.hasVisited라는 이름의 쿠키를 가져오고 아직 값이 
설정되지 않았다면 쿠키를 설정하는 간단한 예제다. 

ex) 
var express = require('express');
var cookieParser = require('cookie-parser');
var app = express();
app.use(cookieParser());
app.get('/', function(req, res){
	console.log(req.cookies);
	if(!req.cookies.hasVisited){
		res.cookie('hasVisited', '1', 
					{
						maxAge : 60*60*1000,
						httpOnly : true,
						path : '/'
					});
	}
	res.send('Sending Cookie');
});
app.listen(8000);

세션 구현 
복잡한 세션 관리라면 직접 구현하는 것을 선호하겠지만, 기본적인 세션 관리라면
cookie-session미들웨어가 비교적 잘 동작한다. 

이는 cookie-parser미들웨어 아레에서 수행되기 때문에, cookie-parser를 먼저 인스톨해야한다. 
사용 문법은 
res.cookie([options])

option 파라미터를 사용해 쿠키에 대한 다음 속성을 설정할 수 있다. 
	- key : 세션을 식별하는 쿠키의 이름
	- secret : 쿠키 위조 방지(prevent cookie tampering)을 위해 세션 쿠키를 사인하는데 사용된 문자열
	- cookie : 쿠키의 셋팅을 정의하는 객체로 maxAge와 path, httpOnly, signed를 포함한다. 
			 기본값은 {path : '/', httpOnly : true, maxAge : null} 이다. 
	- proxy : 불린 형식으로, true라면 익스프레스가 x-forwarded-proto를 통해 보안 쿠키를 설정할 때 
				리버스 프락시(reverse proxy)를 신뢰하도록 설정한다. 

cookie-session을 구현할 때, 세션은 req.session에 객체로 저장된다. 
req.session에 대해 어떤 변경이 발생한다면 동일한 브라우저의 여러 요청에 적용된다. 

ex)
var express = require('express');
var cookieParser = require('cookie-parser');
var cookieSession = require('cookie-session');
var app = express();
app.use(cookieParser());
app.use(cookieSession({secret : 'MAGICALEXPRESSKEY'}));
app.get('/library', function(req, res){
	console.log(req.cookies);
	if(req.session.restricted){
		res.send('You have been in the restricted section' + 
				req.session.restrictedCount + 'times.');
	} else {
		res.send('Welcome to the library');
	}
});
app.get('/restricted', function(req, res){
	req.session.restricted = true;
	if(!req.session.restrictedCount){
		req.session.restrictedCount = 1;
	} else {
		req.session.restrictedCount += 1;
	}
	res.redirect('/library');
});
app.listen(8000);

기본 HTTP 인증 적용
그 밖에 HTTP인증을 적용하는 미들웨어는 
Authorization 헤더를 사용해 브라우저에서 서버로 암호화된 사용자 이름과 비밀번호를 전송한다. 
해당 URL의 브라우저에 저장된 인증 정보가 없다면 브라우저는 기본 알림 창을 띄워 
사용자 이름과 비밀번호를 받는다. 기본 HTTP인증은 최소한의 인증 방법을 요구하는 기본적인 
사이트에서 잘 동작하면 구현하기도 쉽다. 

익스프레스의 basic-auto-connect미들웨어 함수는 기본 HTTP 인증을 처리하는 것을 지원한다. 
basic-auth-connect 미들웨어는 다음 문법을 따른다. 

var basicAuth = require('basic-auth-connect');
express.basicAuth(function(user, pass){});

basic-auth-connect에 전달된 함수는 사용자 이름과 비밀번호를 입력받고 정확한 값이라면
true를 반환하고 그렇지 않으면 false를 반환한다. 예를 들면 다음과 같다. 

app.use(express.basicAuth(function(user, password){
	return(user === 'testuser' && pass ==== 'test');
}));

전형적으로 데이터베이스에 사용자 이름과 비밀번호를 저장하고,
인증 함수 내에서는 값을 검증하기 위해  user 객체를 탐색한다. 

다음 예제는 전역 인증을 구현한다. 
var express = require('express');
var basicAuth = require('basic-auth-connect');
var app = express();
app.listen(8000);
app.use(basicAuth(function(user, pass){
	return(user === 'testuser' && pass === 'test');
}));
app.get('/', function(req, res){
	res.send('Successful Authentication!');
});

단일 루트에만 기본 HTTP인증을 구현
ex)
var express = require('express');
var basicAuth = require('basic-auth-connect');
var app = express();
var auth = basicAuth(function(user, pass){
	return (user === 'user1' && pass === 'test');
});
app.get('/library', function(req, res){
	res.send('Welcome to the library');
});
app.get('/restricted', auth, function(req, res){
	res.send('Welcome th the resticted section');
});
app.listen(8000);


세션 인증 구현
기본 HTTP 인증이 가장 큰 단덤은 인증 정보가 저장돼 있는 한 로그인 상태로 지속된다는 점으로
매우 안전한 편은 아니다. 인증을 구현하는 더 나은 방법은 세션이 인증 정보를 저장하고 원하는 시점에
정보를 파기하는 것이다. 

익스프레스의 session 미들웨어는 세션인증을 구현하기에 매우 접합하다. 
res.session객체에서 호출 가능한 메소드 목록은 아래와 같다. 
- regenerate([callback]) // req.session 객체를 삭제하고 새로운 것을 생성해 세션을 초기화한다.
- destroy([callback]) // req.session 객체를 삭제한다. 
- save([callback]) // 세션 데이터를 저장한다. 
- touch([callback]) // 세션 쿠키의 maxAge 값을 초기화한다. 
- cookie // 브라우저의 세션과 연결되는 쿠키 객체를 정의한다. 

ex)
var express = require('express');
var bodyParser = require('body-parser');
var cookieParser = require('cookie-parser');
var session = require('express-session');
var crypto = require('crypto');
function hashPW(pwd){
	return crypto.createHash('sha256').update(pwd).
			digest('base64').toString();
}
var app = express();
app.use(bodyParser());
app.use(cookieParser('MAGICString'));
app.use(session());
app.get('/restricted', function(req, res){
	if(req.session.user){
		res.send('<h2>' + req.session.success + '</h2>' + 
				 '<p>You have entered the restricted section <p> <br>' +
				 '<a href = "/logout">logout</a>');
	} else {
		req.session.error = 'Access denied!';
		res.redirect('/login');
	}
});
app.get('/logout', function(req, res){
	req.session.destroy(function(){
		res.redirect('/login');
	});
});
app.get('/login', function(req, res){
	var response = '<form method = "POST">' +
		'Username: <input type = "text" name = "username"><br>' + 
		'Password: <input type = "password" name = "password"><br>' + 
		'<input type = "submit" value = "Submit"></form>';
	if(req.session.user){
		res.redirect('/restricted');
	}else if(req.session.error){
		response += '<h2>' + req.session.error + '<h2>';
	}
	res.type('html');
	res.send(response);
});
app.post('/login', function(req, res){
	//user should be a lookup of req.body.usernmae in database
	var user = {name : req.body.username, password:hashPW("myPass")};
	if (user.password === hashPW(req.body.password.toString())){
		req.session.regenerate(function(){
			req.session.user = user;
			req.session.success = 'Authecticated as ' + user.name;
			res.redirect('/restricted');
		});
	} else {
		req.session.regenerate(function(){
			req.session.error = 'Authectication failed.';
			res.redirect('/restricted');
		});
		res.redirect('/login');
	}
});
app.listen(8000);


사용자 정의 미들웨어 생성(쿼리만 떼기)
// 정확히 url 부분만 남겨서 리턴하고, 
// 나머지는 ?split함수로 잘라버림. 
var express = require('express');
var app = express();
function queryRemover(req, res, next){
	console.log("\nBefore URL : ");
	console.log(req.url);
	req.url = req.url.split('?')[0];
	console.log("\nAfter URL : ");
	console.log(req.url);
	next();
};
app.use(queryRemover);
app.get('/no/query', function(req, res){
	res.send("test");
});
app.listen(8000);



































