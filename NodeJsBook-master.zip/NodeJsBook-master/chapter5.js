Chapter5. Node.js의 데이터 입출력 처리 

JSON으로 하는 작업
JSON을 자바스크립트 객체로 변환
JSON.parse(string)함수를 사용하면 적절히 구분된 JSON을 자바스크립트 객체로 변환 가능하다. 
그 후 .표기법을 사용해 접근 가능하다. 

자바스크립트 객체를 JSON으로 변환
반대로 자바스크립트 객체를 적절히 JSON 포맷으로 변환할 수 있다. 
JSON.stringify(object);

ex)
var accountObj = { // 객체 리터럴 표기 방식으로 한다. 
	name : "Baggins",
	number : 10645,
	members : ["Frodo, Bilbo"],
	location : "Shire"
};
var accountStr = JSON.stringify(accountObj);


버퍼 데이터를 대상으로 Buffer 모듈을 사용
자바스크립트는 유니코드 처리에 최적화돼 있기 때문에 바이너리 데이터 관리에는 좋지 않다. 
아래와 같은 일부 웹 애플리케이션이나 서비스의 경우 바이너리 데이터가 유용하게 사용된다. 
	- 압축된 파일 전송
	- 동적인 이미지 생성
	- 직렬화된 바이너리 데이터 전송 

버퍼 데이터 이해
노드는 버퍼 구조 내에 바이너리 대이터를 생성하고 일고, 쓰고, 조작하기 위한 Buffer 모듈을 제공한다.
Buffer 모듈은 전역적이기 때문에 접근으 ㄹ위해 require() 함수를 사용하지 않아도 된다. 
버퍼 데이터는 배열과 유사한 구조로 저장되지만 기본 메모리 할당에 사용되는 일반 힙과는 다른 공간에 저장된다. 
그래서 버퍼의 크기는 변경이 불가능하다. 
버퍼를 문자열로 변환하거나 문자열을 버퍼로 변환할 때에는 명시적으로 인코딩 형태를 지정해야 한다. 

인코딩 목록은 아래와 같다.
utf8
utf16le // 리틀 엔디언으로 인코딩된 2 또는 4바이트의 유니코드 문자
ucs2 // 리틀 엔디언으로 인코딩된 2또는 4바이트의 유니코드 문자
base64 // Base-64 스트링 인코딩
Hex // 각 바이트는 두 개의 16진수 문자로 인코딩 

버퍼 생성하기
버퍼 객체는 실제 기본 멤노리를 할당하기 때문에 생성시 크기를 지정해야 한다. 
new 키워드를 이용해 Buffer 객체 생성시에 세 가지 옵션이 있다. 

new Buffer(sizeInBytes)
new Buffer(octectArray)
new Buffer(string, [encoding])

아래 예제 코드는 바이트 사이즈, 8진 버퍼, UTF8문자열을 사용하는 버퍼 할당을 다룬다. 
var buf256 = new Buffer(256);
var bufOctets = new Buffer([0x6f, 0x63, 0x74, 0x65, 0x74, 0x73]);
var bufUTF8 = new Buffer("Some UTF8 Text \u00b6 \u30c6 \u20ac", 'utf8');

버퍼에 쓰기 
버퍼 객체를 생성하고 난 후에는 객체의 크기를 변경할 수 없지만,
버퍼 내 어느 위치에든 쓸 수 있따. 

buffer.write(string, [offset], [length], [encoding]); // 버퍼에 지정된 위치, 크기, 인코딩의 string을 쓴다.
buffer[offset] = value // offset 위치의 데이터를 지정된 value값으로 교체한다. 
buffer.fill(value, [offset], [end]) // 버퍼의 지정된 offset위치에서 end 위치까지 지정된 value로 모든 바이트를 쓴다. 
writeInt8(value, offset, [noAssert])
writeInt16LE... // Buffer객체에 리틀 엔디언이나 빅 엔디언 방식으로, int, unInt, doubles, floats를 쓰는 다양한 함수가 있다. 
				// value는 씌어질 값, offset은 씌어질 위치, noAssert는 value와 offset의 검증을 할지 말지. 

예제코드
var buf256 = new Buffer(256);
buf256.fill(0);
buf256.write("add some text");
console.log(buf256.toString());
buf256.write("more text", 9, 9);
console.log(buf256.toString());
buf256[18] = 43;
console.log(buf256.toString());


버퍼에서 읽기 
buffer.toString([encoding], [start], [end]) 
// start부터 end까지에 이르는 구간에 있는 버퍼 내용을 지정된 인코딩의 문자열로 반환하는 함수다. 
// start와 end가 지정되지 않은 경우 toString()은 버퍼의 시작과 끝을 범위로 사용한다. 
stringDecoder.write(buffer) // 버퍼의 디코딩된 문자열 버전을 반환한다. 
buffer[offset] // 지정된 offset의 버퍼 내용의 8진수 값을 반환한다. 
readInt8(offset, [noAssert]) 
readInt16Le ... 
// 다양한 크기의 리틀 엔디언과 빅 엔디언을 사용하는 int, unint, doubles, float 형태의 버퍼 객체를 
// 읽기 위한 함수이다. 
예제코드 
var bufUTF8 = new Buffer("Some UTF8 Text \u00b6 \u30c6 \u20ac", 'utf8');
console.log(bufUTF8.toString());
console.log(bufUTF8.toString('utf8', 5, 9));
var StringDecoder = require("string_decoder").StringDecoder;
var decoder = new StringDecoder('utf8');
console.log(decoder.write(bufUTF8));
console.log(bufUTF8[18].toString(16));
console.log(bufUTF8.readUInt32BE(18).toString(16));

 버퍼 길이 결정 
 "UTF8 text \u00b6".length; // 11
 Buffer.byteLength("UTF8 text \u00b6", 'utf8'); // 12
 Buffer("UTF8 text \u00b6").length; // 11 

 버퍼 복사
 copy(targetBuffer, [targetStart], [sourceStart], [sourceEnd])
 // targetBuffer는 다른 버퍼 객체를 위한 부분이고,
 // targetStart, sourceStart, sourceEnd는 소스와 타겟 버퍼 내의 위치를 전달한다. 
 // *문자열 데이터의 경우 인코딩이 같은지 확인해야 한다. 

 다른 방법으로는 아래 코드처럼 위치를 직접 지정해 버퍼간 복사를 진행할 수도 있다. 
 sourceBuffer[index] = destinationBuffer[index];

 예제코드
var alphabet = new Buffer('abcdefghijklmnopqrstuvwxyz');
console.log(alphabet.toString());
// 전체 버퍼를 복사한다. 
var blank = new Buffer(26);
blank.fill();
console.log("Blank: " + blank.toString());
alphabet.copy(blank);
console.log("Blank: " + blank.toString());
//버퍼의 일부분을 복사한다. 
var dashes = new Buffer(26);
dashes.fill('-');
console.log("Dashes: " + dashes.toString());
alphabet.copy(dashes, 10 , 10, 15);
console.log("Dashes: " + dashes.toString());
//버퍼의 특정 부분을 기준으로 삼아 복사한다. 
var dots = new Buffer('----------------------------');
dots.fill('.');
console.log("dots : " + dots.toString());
for(var i = 0; i < dots.length; i++){
	if (i%2){
		dots[i] = alphabet[i];
	}
}
console.log("dots: " + dots.toString());

버퍼 분할
var numbers = new Buffer("1234567890");
var slice = numbers.slice(3, 6);
console.log(slice.toString());
slice[0] = '#'.charCodeAt(0);
slice[slice.length-1] = '#'.charCodeAt(0);
console.log(slice.toString());
console.log(numbers.toString());


버퍼 병합
var af = new Buffer("African Swallow?");
var eu = new Buffer("European Swallow?");
var question = new Buffer("Air Speed Velocity of an ");
console.log(Buffer.concat([question, af]).toString());
console.log(Buffer.concat([question, eu]).toString());



스트림 데이터 사용을 위한 Stream 모듈 사용하기
노드의 중요한 모듈중에 Stream모듈이 있다. 
데이터 스트림은 읽기, 쓰기, 읽기/쓰기가 가능한 메모리 구조다. 
이는 파일 접근이나 HTTP 요청으로 데이터를 읽을 때를 포함한 많은 부분에 사용된다. 
이번 절은 Stream 모듈을 사용해 스트림을 생성하거나 읽고 쓸 때의 내용을 다룬다. 


스트림을 사용하는 목적은 데이터 전송을 위한 공통 구조를 제공하기 위해서다. 
스트림에서 데이터가 읽기 가능한 상태가 되면
data 이벤트가 발생하고, 
오류가 발생하면 error 이벤트가 생성된다. 
스트림에서 데이터를 처리하기 위한 리스너를 등록해 사용할 수도 있다. 

Readalbe스트림
이 스트림 객체는 다음 이벤트를 생성한다. 
- readable // 스트림에서 데이터 청크를 읽을 수 잇을 때 생성된다. 
- data // 데이터 이벤트 핸들러가 추가된 것을 제외하면 readable과 유사하다. 스트림은 흐름 모드로 
// 변경되고 데이터 핸들러는 남아 있는 데이터가 없을 떄까지 지속적으로 호출된다. 
- end // 스트림에 데이터가 더 이상 제공되지 않을 때 생성된다. 
- close // 파일 같은 기본 리소스가 닫힐 때 생성된다. 
- error // 데이터를 수신 시 오류가 발생한 경우 생성된다. 

Readable 스트림 객체의 지원 함수
- read([size])  // 스트림에서 String이나 buffer, null 형태의 데이터를 읽음(null은 더 이상 읽은 데이터가 
	// 남아 있지 않는 것을 의미함). size 전달인자를 지정한 경우 읽는 데이터의 크기가 제한된다.
- setEncoding(encoding) // read() 요청 결과를 String 형태로 변환 시 인코딩 형태 
- pause() // 객체에서 생성되는 data 이벤트를 중지
- resume() // 객체에서 생성되는 data 이벤트를 재개
- pipe(destination, [options]) // 출력 스트림을 destination필드에 지정된 Writable 스트림 객체에 연결, 
// {end:true} 는 Readable이 끝나는 시점에 Writable목적 스트림도 끝나는 것을 의미
- unpipe([destination]) // Writable 목적 스트림에서 객체 제거 

예제코드
var stream = require('stream');
var util = require('util');
util.inherits(Answars, stream.Readable);
function Answers(opt){
	stream.Readable.call(this, opt);
	this.quotes = ["yes", "no", "maybe"];
	this._index = 0;
}
Answers.prototype._read = function(){
	if(this._index > this.quotes.length){
		this.push(null);
	} else {
		this.push(this.quotes[this._index]);
		this._index += 1;
	}
};
var r = new Answers();
console.log("Direct read: " + r.read().toString());
r.on('data', function(data){
	console.log("Callback read: " + data.toString());
});
r.on('end', function(data){
	console.log("No more answers");
});

Writable스트림
이 스트림은 다음과 같은 이벤트를 발생시킨다. 
- drain // write() 호출이 false를 반환한 이후 다시 데이터를 쓰기 가능한 상태라는 것을 
		// 리스너 함수에 알려주기 위해 사용한다. 
- finish // 모든 데이터가 비워지고 더 이상 쓸 데이터가 없는 경우 Writable객체에 
		// end() 가 호출된 후 생성된다. 
- pipe // Readable스트림에 Writable목적지가 추가되면 pipe() 함수 호출 후 생성된다. 
- unpipe // Readable스트림에서 Writable 목적지 제거를 위해 unpipe() 호출 후 생성된다. 

이 스트림에서 사용 가능한 함수는 다음과 같다. 
- write(chunk, [encoding], [callback]); // 스트림 객체의 데이터 위치에 데이터 청크를 쓴다. 
// 데이터는 String이나 Buffer형태다. encoding이 지정되면 문자열 데이터의 인코딩 정보로 
// 사용된다. callback이 지정되면 데이터가 비워진 이후 호출된다. 
- end([chunk[], [encoding], [callback]); // 데이터를 더 이상 수용하지 않고 finish 이벤트를
// 보내는 것을 제외하면 write()와 동일하다. 

예시코드
var stream = require("stream");
var util = require("util");
util.inherits(Writer, stream.Writable);
function Writer(opt){
	stream.Writable.call(this, opt);
	this.data = new Array();
}
Writer.prototype._write = function(data, encoding, callback){
	this.data.push(data.toString('utf8'));
	console.log("Adding: " + data);
	callback();
};
var w = new Writer();
for(var i = 1; i <= 5; i++){
	w.write("Item" + i, 'utf8', (function(msg){
		console.log("callback" + msg);
	})(i));
}
w.end("ItemLast");
console.log(w.data);

Readable 스트림과 Writable 스트림을 파이프 형태로 연결 
예시코드
var stream = require('stream');
var util = require('util');
util.inherits(Reader, stream.Readable);
util.inherits(Writer, stream.Writable);
function Reader(opt){
	stream.Readable.call(this, opt);
	this._index = 1;
}
Reader.prototype._read = function(size){
	var i = this._index++;
	if(i > 10){
		this.push(null);
	} else {
		this.push("Item " + i.toString());
	}
};
function Writer(opt){
	stream.Writable.call(this, opt);
	this._index = 1;
}
Writer.prototype._write = function(data, encoding, callback){
	console.log(data.toString());
	callback();
};
var r = new Reader();
var w = new Reader();
r.pipe(w);

zlib을 이용한 데이터 압축 및 해제
- 버퍼 압축과 해제 예시코드
var zlib = require("zlib");
var input = "..................text...................";
zlib.deflate(input, function(err, buffer){
	if(!err){
		console.log("deflate (%s) : ", buffer.length, buffet.toString('base64'));
		zlib.inflate(buffer, function(err, buffer){
			if(!err){
				console.log("deflate (%s) : " , buffer.length, buffer.toString());
			}
		});
		zlib.unzip(buffer, function(err, buffer){
			if(!err){
				console.log("unzip deflate (%s) : ", buffer.length, buffer.toString());
			}
		});
	}
});

zlib.deflateRaw(input, function(err, buffer){
	if(!err){
		console.log("deflateRaw (%s) : ", buffer.length, buffer.toString('base64'));
		zlib.inflateRaw(buffer, function(err, buffer){
			if(!err){
				console.log("inflaeRaw (%s) : ", buffer.length, buffer.toString());
			}
		});
	}
});

zlib.gzip(input, function(err, buffer){
	if(!err){
		console.log("gzip (%s) : ", buffer.length, buffer.toString('base64'));
		zlib.gunzip(buffer, function(err, buffer){
			if(!err){
				console.log("gunzip (%s) : ", buffer.length, buffer.toString());
			}
		});	
		zlib.unzip(buffer, function(err, buffer){
			if(!err){
				console.log("unzip gzip (%s): ", buffer.length, buffer.toString());
			}
		});
	}
});

스트림 압축 해제
var zlib = require("zlib");
var gzip = zlib.createGzip();
var fs = require("fs");
var inFile = fs.createReadStream('zlib_file.js');
var outFile = fs.createWriteStream('zlib_file.gz');
inFile.pipe(gzip).pipe(outFile);
setTimeout(function(){
	var gunzip = zlib.createUnzip({flush: zlib.Z_FULL_FLUSH});
	var inFile = fs.createReadStream('zlib_file.gz');
	var outFile = fs.createWriteSteam('zlib_file.unzipped');
	inFile.pipe(gunzip).pipe(outFile);
}, 3000);
