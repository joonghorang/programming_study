Chapter 6 Node.js에서 파일 시스템에 접근 

동기적 파일 시스템 호출 vs 비동기적 파일 시스템 호출 
노드에서 fs모듈은 거의 모든 기능을 동기, 비동기적으로 둘 다 제공한다. 
예를 들면 write() 는 비동기적으로 동작하고 writeSync()는 동기적으로 동작한다. 

동기적 파일 시슽쳄 호출은 호출이 끝날 때까지 블록 상태를 유지한 후 스레드로 제어가 넘어온다. 
이 방식은 장점도 있지만 동기적 호출이 메인 이벤트 스레드를 블록하거나 너무 많은 백그라운드 스레드 풀의
스레드를 사용할 경우 심각한 성능 저하를 가져올 수 있다. 
그렇기 때문에 가능한 동기적 파일 시스템 호출은 제한하는 것이 좋다. 

비동기적 호출은 이벤트 큐에 추가된 후 실행된다. 이 방식은 node.js 이벤트 모델에 적합한 방식이다. 
하지만 호출 스레드가 비동기 호출이 이벤트 루프에서 실행되기전에도 지속적으로 수행되기 때문에 구현이 까다롭다. 

동기적, 비동기적 파일 시스템 호출의 내부 기능은 대부분 동일하다.
둘 다 같은 전달인자를 사용하는데 비동기적 호출의 경우 마지막 전달인자로 파일 시스템 호출 완료 후
수행 될 콜백 함수를 지정하는 것이 다르다. 

주요 차이점을 정리하면 다음과 같다. 
- 비동기 호출은 추가 전달인자로 콜백 함수가 필요하다. 콜백 함수는 파일 시스템 요청이 완료된 후 
실행되고 마지막 전달인자로 오류 메시지를 포함한다. 
- 비동기 호출은 자동으로 예외처리를 하고 오류 객체를 첫 전달인자로 전달한다.
동기적 호출방식에서는 반드시 try/catch 블록을 사용해 예외처리를 한다. 
- 동기 호출은 바로 실행되고 수행이 완료될 때까지 제어가 현재 스레드로 반환되지 않는다.
비동기 호출은 이벤트 큐에 위치된 후 제어가 바로 수행 중이던 코드로 반환된다. 
실제 파일 시스템 호출은 이벤트 큐에서 선택된 이후 수행된다. 


파일 열기 및 닫기 
파일 열기 함수 
fs.open(path, flags, [mode], callback)
fs.openSync(path, flags, [mode])

path 전달인자는 파일 시스템 내의 표준 경로를 지정한다. 
flag 전달인자는 다음의 열기 모드를 지정한다. 
- r // 읽기 가능 파일 열기, 파일이 존재하지 않을 경우 예외가 발생.
- r+ // 일기 쓰기 가능 파일 열기. 파일이 존재하지 않을 경우 예외가 발생
- rs // 동기 모드로 읽기 가능 파일 열기. fs.openSync()과는 동일하지 않다.  
	 // 사용시 로컬 파일 시스템 캐시를 통과한다. NFS 마운트 경우 오래된 로컬 캐시가 존재하지 
	 // 않도록 만들기 떄문에 유용하다. 시스템 성능 저하를 가져올 수 있기 떄문에 플래그 사용에 주의
- rs+ // 읽기 쓰기가 동시에 가능하게 연다는 것을 제외하고 rs와 동일
- w // 쓰기 가능 파일 열기, 파일이 존재하지 않는 경우 새로 생성하고, 존재하는 경우 기존 내용을 제거한다.
- wx // 기존 경로가 존재할 경우에 실패하는 것을 제외하면 w 와 동일하다. 
- w+ // 읽기 쓰기 가능 파일 열기. 파일이 존재하지 않는 경우 생성되고, 존재하는 경우 기존 내용을 제거.
- wx+ // 기존 경로가 존재할 경우에 실패하는 것을 제외하고 w+ 와 동일하다.
- a // 추가를 위한 파일 열기. 파일이 존재하지 않는 경우 생성한다. 
- ax+ // 경로가 존재하는 겨우에 실패하는 것을 제외하고 a+와 동일하다. 
mode전달인자는 선택적인 항목으로 파일 시스템 접근 모드를 설정한다. (기본 설정값은 0666)

아래 예제는 비동기 모드로 파일을 열고 닫는 예제다. err와 fd를 전달인자로 받는 콜백 함수가
지정된 것을 주목하자. 
fd전달인자는 파일을 읽고 쓰기 위해 사용하는 파일 디스크립터를 지정한다. 

ex)
var fs = require('fs');
fs.open("myFile", 'w', function(err, fd){
	if(!err){
		fs.close(fd);
	}
});

다음은 동기로 파일을 열고 닫는 예제다. 
콜백함수가 지정되지 않고 읽기 및 쓰기를 위한 파일 디스크립터가 fs.openSync()에서 직접 반환된다. 
ex)
var fs = require('fs');
var fd = fs.openSync("myFile", 'w');
fs.closeSync(fd);

파일 쓰기

writeFile()함수를 사용한 간편한 파일 쓰기 
fs.writeFile(path, data, [options], callback)
fs.writeFileSync(path, data, [options])

path전달인자를 통해 파일의 절대 경로나 상대 경로를 지정한다.
data전달인자를 통해 파일에 쓸 string이나 Buffer객체를 지정한다 .
선택적으로 사용하는 options 전달인자에는 문자열이나 encoding이나 파일을 열 때 사용할 mode,flag속성을 전달한다.
비동기 함수의 경우 파일 쓰기 완료 후 수행될 콜백 함수를 전달해야 한다. 

아래 예제는 fileWrite()함수를 사용해 config 객체의 JSON 문자열 내용을 파일에 저장하는 내용을 보여준다. 
ex)
var fs = require('fs');
var config = {
	maxFiles : 20,
	maxConnections : 15,
	rootPath : "/webroot"
};
var configTxt = JSON.stringify(config);
var options = {
	encoding : 'utf8', 
	flag : 'w'
};
fs.writeFile('./config.txt', configTxt, options, function(err){ // 경로가 존재하지 않을 경우 에러 
	if(err){
		console.log("Config Write Failed");
	} else {
		console.log("Config saved");
	}
});

동기적 파일 쓰기 
이 함수는 실해중인 쓰레드로 제어를 넘기지 않고 파일에 데이터를 쓴다. 
이 방식은 동일한 코드 내에서 여러 번 쓰기를 수행할 때는 유리하지만
다른 쓰레드의 수행을 방해하기 때문에 단점을 가진다. 

동기적 파일으 ㄹ쓰기위해선
1. openSync()를 사용해 파일 디스크립터를 얻은 후,
2. fs.writeSync()를 사용해 파일에 데이터를 쓴다. 
3. fs.writeSync()는 아래와 같이 사용한다. 
	ex)fs.writeSync(fd, data, offset, length, position)

fd전달인자는 openSync()가 반환한 파일 디스크립터 값이다. 
data 전달인자는 파일에 쓸 string이나 buffer객체를 지정한다. 
offset 전달인자는 data 인자에서 읽기 시작할 위치를 지정한다. 
string이나 buffer의 첫 부분에서 시작하려면 이 값을 null로 설정한다. 
length전달인자는 쓰기를 수행할 바이트 크기를 지정한다. 
이 값이 null인 경우 data 버퍼의 끝까지 쓰기를 수행한다.
position 전달인자는 쓰기를 시작할 파일 내 위치를 지정한다. 
현재 파일 위치를 사용하려면 이 값을 null로 지정한다. 
ex)
var fs = require('fs');
var veggieTray = ['carrots', 'celery', 'olives'];
fd = fs.openSync('../data/veggie.txt', 'w');
while(veggieTray.length){
	veggie = veggieTray.pop() + " ";
	var bytes = fs.writeSync(fd, veggie, null, null);
	console.log("Wrote %s %dbytes", veggie, bytes);
}
fs.closeSync(fd);

비동기적 파일 쓰기
비동기 방식의 파일 쓰기 함수는 쓰기 요청을 이벤트 큐에 넣은 후 호출한 코드로 제어를 반환한다. 
실제 쓰기는 이벤트 큐에서 쓰기 요청이 나와서 실행되기 전까지 이뤄지지 않는다. 
동일한 파일에 여러 쓰기 요청을 수행할 때는 실행 순서가 보장되지 않기 때문에 동기적으로 쓰는 것이 좋다 .
굳이 비동기를 사용하려면, 이전 쓰기에 내포된 콜백함수를 사용하면 된다. 

비동기적 쓰기를 진행하려면
1. open()을 사용해 파일을 열고 콜백함 수를 수행한 후에
2. fs.write()를 사용해 파일에 데이터를 쓴다. 
	ex) fs.write(fd, data, offset, length, position, callback)

fd 전달인자는 openSync()가 반환한 파일 디스크립터(file descriptor)다. 
data 전달인자는 파일에 쓰기를 수행할 String이나 Buffer객체를 지정한다. 
offset은 입력데이터를 읽기 시작할 위치를 지정한다. 
string이나 buffer의 현재 인덱스를 사용하려면 이값을 null로 지정한다. 
length 전달인자는 쓰기를 수행할 바이트 크기를 지정한다. 
버퍼의 끝까지 쓰기를 진행하려면 이 값을 null로 한다. 
position 전달인자는 쓰기를 시작할 파일 내 위치를 지정한다. 현재 파일 위치를 그대로 사용하려면 null
callback전달 인자는 반드시 error와 bytes로 두 전달인자를 받는 함수를 사용해야 한다. 
error는 쓰기 수행 시 발생한 오류가 기록되고, bytes는 쓰기가 진행된 크기를 지정한다. 

아래 예제에서 
open()은 파일 디스크립터를 콜백 함수 전달인자로 지정하고,
콜백 함수 내에서 wirteFruit()함수를 사용한다. 
write()콜백은 파일 디스크립터를 전달인자로 사용하고 writeFruit() 함수를 호출하고 있다. 
이런 쓰기 호출을 통해 비동기 쓰기가 다른 쓰기에 앞서 실행되는 것을 보자할 수 있다. 
ex)
var fs = require('fs');
var fruitBowl = ['apple', 'orange', 'banana', 'grapes'];
function writeFruit(fd){
	if(fruitBowl.length){
		var fruit = fruitBowl.pop() + " ";
		fs.write(fd, fruit, null, null, function(err, bytes){
			if(err){
				console.log("FileWrite Failed");
			} else {
				console.log("Wrote : %s %dbytes", fruit, bytes);
				writeFruit(fd);
			}
		});
	} else {
		fs.close(fd);
	}
}
fs.open('./fruit.txt', 'w', function(err, fd){
	writeFruit(fd);
});


스트리밍 파일 쓰기 
'대량' 데이터를 파일에 쓰기 위해 가장 효율적인 방법 중 하나는 파일을 열어서
writable스트림으로 사용하는 스트리밍이다. 이 스트림을 만들어 pipe()함수를 사용해
readable스트림과 간단히 연결 가능하다. 이 방식을 이요해 HTTP요청과 같은 Readable 스트림 소스에서
매우 간편히 데이터를 쓸 수 있다. 

1. 파일에 데이터를 비동기적으로 스트리밍을 위한 스트림 객체는 아래 문법으로 생성한다.
fs.createWriteStream(path, [options])
path 전달인자는 절대 경로나 상대 경로를 사용해 파일의 위치를 지정한다. 
선택적인 options전달인자에는 encoding과 mode, flag 속성을 지정해 문자열 인코딩과 파일을 열 때 
사용하는 모드와 플래그를 설정한다. 

2, writable파일 스트림을 한 번 열면 표준 스트림 write(buffer) 함수를 사용해 파일을 쓴다. 
쓰기를 마치면 end() 함수를 사용해 스트림을 닫는다. 

예제코드
var fs = require('fs');
var grains = ['wheat', 'rice', 'oats'];
var options = { encoding : 'utf8', flag : 'w'};
var fileWriteStream = fs.createWriteStream("./grains.txt", options);
fileWriteStream.on("close", function(){
	console.log("File Closed");
});
while(grains.length){
	var data = grains.pop() + ' ';
	fileWriteStream.write(data);
	console.log("Wrote: %s", data);
}
fileWriteStream.end(); //이 구문에 의해 close이벤트가 발생함 


파일 읽기

readFile()함수를 이용한 간단한 파일 읽기 
fs.readFile(path, [options], callback);
fs.readFileSync(path, [options])

ex)
var fs = require("fs");
var options = {encoding: 'utf8', flag : 'r'};
fs.readFile('./config.txt', options, function(err, data){
	if(err){
		console.log("Failed to open config file.");
	} else {
		console.log("Config Loaded");
		var config = JSON.parse(data);
		console.log("Max Files : " + config.maxFiles);
		console.log("Max Connections : " + config.maxConnections);
		console.log("Root Path : " + config.rootPath);
	}
});

동기적 파일 읽기
스레드 제어가 반환되기 전에 데이터 읽기를 완료하는 것이 동기적 파일 읽기이다. 
이 같은 방식은 같은 파일이 여러번 읽기 동작이 발생할 경우에는 유리하지만, 
다른 스레드에서 같은 파일에 대한 읽기를 시도하는 경우 느려지는 단점이 있다. 

파일을 동기적으로 읽으려면 먼저 openSync()를 사용해 파일을 열고,
이 때 얻은 파일 디스크립터를 readSync()에 전달해 파일의 데이터를 읽는다. 
다음은 readSync()의 사용법이다. 

fs. readSync(fd, buffe,r offset, length, position)

예제 코드
var fs = require('fs');
fd = fs.openSync('./veggie.txt', 'r');
var veggies = "";
do {
	var buf = new Buffer(5); // 5개씩 끊어서 읽는다. 
	buf.fill();
	var bytes = fs.readSync(fd, buf, null, 5);
	console.log("read %dbytes", bytes);
	veggies += buf.toString();
} while (bytes > 0);
fs.closeSync(fd);
console.log("Veggies: " + veggies);


비동기적 파일 읽기
이는 읽기 요청을 이벤트 큐에 넣고 제어를 호출한 코드로 넘겨준다. 
실제 읽기 동작은 이벤트 큐에서 해당 요처잉 꺼내져 처리될 때까지 미뤄진다. 
비동기 방식의 읽기 동작은 실행 순서가 보장되지 않기 때문에 읽기 순서가 중요한 작업에는 주의해야 한다.
순서를 보장하려면 이전 읽기 요청의 콜백 함수 내에 중첩된 읽기 요청을 진행해야 한다. 

비동기적으로 파일을 읽으려면 
1. 우선 open()을 사용해 파일을 열고,
2. open요청에 대한 콜백이 수행되면
3. read()를 사용해 파일에서 데이터를 읽는다. 
	ex) fs.read(fd, buffer, offset, length, position, callback);

callback은 error, bytes, buffer라는 세 가지 전달인자가 있는 함수를 지정한다. 

open()콜백이 readFruit()함수를 호출하는 것과 파일 디스크립터가 전달된 것을 확인하고,
read()콜백도 readFruit()를 호출하고 파일 디스크립터를 전달하고 있다. 
이런 방식을 사용해 비동기적 읽기가  비동기 읽기 요청보다 먼저 실행되는 것을 보장할 수 있다. 
예제코드
var fs = require('fs');
function readFruit(fd, fruits){
	var buf = new Buffer(5);
	buf.fill();
	fs.read(fd, buf, 0, 5, null, function(err, bytes, data){
		if(bytes > 0){
			console.log("read %dbytes", bytes);
			fruits += data;
			readFruit(fd, fruits);
		} else {
			fs.close(fd);
			console.log("Fruits: %s", fruits);
		}
	});
}
fs.open('./fruit.txt', 'r', function(err, fd){
	readFruit(fd, "");
});

스트리밍 방식의 파일 열기 
fs.createReadStream(path, [options]);
이렇게 파일 스트림을 연 후에는 read() 요청에 대한 readable이벤트를 사용해 데이터를 간편히 
읽을 수 있다. 

예제코드
var fs = require('fs');
var options = {encoding : 'utf8', flag : 'r'};
var fileReadStream = fs.createReadStream("./grains.txt", options);
fileReadStream.on('data', function(chunk){
	console.log('Grains: %s', chunk);
	console.log('Read %d bytes of data.', chunk.length);
});
fileReadStream.on("close", function(){
	console.log('File Closed');
});



기타 파일 시스템 작업 

경로가 있는지를 검증
fs.exists(path, callback)
fs.existsSync(path) // true, false를 리턴한다. 
ex)
fs.exists('filesystem.js', function(exists){
	console.log(exists ? "Path exists" : "Path Does not exists");
});

파일 정보 확인
다른 파일 시스템 관련 기본 작업으로 파일 크기나 모드, 변경시간, 파일 디렉토리 여부 등의 파일 시스템 객체
에 대한 기본 정보를 확인하는 작업이 있다. 아래 함수들을 사용해 파일 시스템 관련 정보를 얻을 수 있다. 

fs.stat(path, callback); // Stats객체를 콜백함수의 두 번째 전달 인자로 전달한다. 첫 전달인자 error는 오류 확인용
fs.statSync(path); // Stats객체를 반환한다. 

Stats객체에 포함된 일반적인 속성과 함수는 다음과 같다. 

isFile() // 항목이 파일인 경우 true를 반환
isDirectory() // 항목이 디렉토리인 경우 true를 반환
isSocket() // 항목이 소켓인 경우 true를 반환
dev // 파일이 위치한 곳의 디바이스 ID
mode // 파일 접근 모드 지정
size // 파일 크기 지정
blksize // 파일 저장에 사용된 바이트 단위의 블록 크기 지정
blocks // 파일이 디스크 상에서 차지하는 블록 크기 지정
atime // 마지막 파일 접근 시간 지정
mtime // 마지막 파일 변경 시간 지정
ctime // 파일 생성 시간 지정

예제코드
var fs = require("fs");
fs.stat('file_stats.js', function(err, stats){
	if(!err){
		console.log('stats : ' + JSON.stringify(stats, null, ' '));
		console.log(stats.isFile() ? "Is a File" : "Is not a File");
		console.log(stats.isDirectory() ? "Is a Folder" : "Is not a Folder");
		console.log(stats.isSocket() ? "Is a Socket" : "Is not a Socket");
		stats.isDirectory();
		stats.isBlockDevice();
		stats.isCharacterDevice();
		//stats.isSymbolicLink(); // only lstat
		stats.isFIFO();
		stats.isSocket();
	}
});


파일 목록 나열
다른 일반적인 파일 시스템 관련 작업 중 하나는 
디렉토리 내 파일과 폴더를 조회하는 것이다. 디렉토리를 지우거나 디렉토리 구조를 동적으로 
변경하는 등의 작업에 디렉토리 목록 조회가 필요하다. 

다음 명령 중 하나를 사용해 디렉토리 내 목록을 조회할 수 있다. 
fs.readdir(path, callback);
fs.readdirSync(path) // 파일 목록을 리턴 
예제코드
var fs = require('fs');
var Path = require('path');
function WalkDirs(dirPath){
	console.log(dirPath);
	fs.readdir(dirPath, function(err, entries){
		for(var idx in entries){
			var fullPath = Path.join(dirPath, entries[idx]);
			(function(fullPath){
				fs.stat(fullPath, function(err, stats){
					if(stats && stats.isFile()){
						console.log(fullPath);
					} else if(stats && stats.isDirectory()){
						WalkDirs(fullPath);
					}
				});
			})(fullPath);
		}
	});
}
WalkDirs("./");


파일 삭제 
fs.unlink(path, callback)
fs.unlinkSync(path)

unlinkSync(path) 함수는 파일 삭제 성공 여부에 따라 true나 false를 반환한다. 
비동기 방식인 unlink()호출은 파일 삭제 실패시 콜백 함수에 오류 값을 전달한다. 
ex)
fs.unlink("new.txt", function(err){
	console.log(err ? "File Deleted Failed" : "File Deleted");
});

디렉토리 추가와 삭제
fs.mkdir(path, [mode], callback)
fs.mkdirSync(path, [mode])

path는 절대 경로나 상대 경로를 사용할 수 있다. 선택적 전달인자인 mode는 새로운 디렉토리의 
접근 모드를 지정할 수 있다. 

mkdirSync(path) 함수는 디렉토리 생성 성공 여부에 따라 true나 false를 반환한다.
비동기 함수인 mkdir()호출은 디렉토리 생성에 실패 시 콜백 함수에 error 값을 전달한다. 

비동기 함수를 사용할 때는 서브 디렉토리 생성에 앞서 디렉토리가 생성되도록 주의한다.
아래는 순차 방식으로 서브 디렉토리 생성 방법이다. 
fs.mkdir("./data/A/B/D", function(err){
	fs.mkdir("./data/A/B", function(err){
		fs.mkdir("./data/A/C/E", function(err){
			fs.mkdir("./data/A/C", function(err){
				fs.mkdir("./data/A", function(err){

				});
			});
		});
	});
});

반대로 디렉토리를 삭제하려면 아래 함수를 사용한다. 
fs.rmdir(path, callback)
fs.rmdirSync(path)
rmdirSync(path)함수는 디렉토리 삭제 성공 여부에 따라 true나 false를 반환한다. 
비동기 함수인 rmdir() 호출은 디렉토리 삭제 도중 발생한 에러를 콜백 함수로 전달한다. 
mkdir() 함수와 같이 부모 디렉토리를 삭제하기 전에 대상 디렉토리르 삭제하도록 한다. 
ex)
fs.rmdir("./data/A/B/C", function(err){ // 코드가 약간 이상한데, 나중에 실재로 작성해보면서 경험하자
	fs.rmdir("./data/A/B", function(err){
		fs.rmdir("./data/D", function(err){

		});
	});
	fs.rmdir("./data/A/C", function(err){
		fs.rmdir("./data/E", function(err){

		});
	})
})

파일 이름과 디렉토리 이름을 변경
fs.rename(oldPath, newPath, callback)
fs.renameSync(oldPath, newPath)// 성공여부에 따라 true, false 리턴
예제 코드
fs.rename("old.txt", "new.txt", function(err){
	console.log(err ? "Rename Failed" : "File Renamed");
});
fs.rename("testDir", "renamedDir", function(err){
	console.log(err ? "Rename Failed" : "Folder Renamed");
});







































