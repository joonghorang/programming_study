Chapter 3.
Node.js 입문

npm 명령어
npm search express // 저장소 내 모듈 패키지 검색

npm install
npm install express
npm install express@0.1.1
npm install ../tModule.tgz // 저장소 내 package.json파일을 사용하거나 로컬 위치에서 패키지 설치

npm install express -g // 전역적으로 접근 가능한 위치에 패키지 설치 

npm remove express // 모듈 제거

npm pack // package.json파일에 정의된 모듈을 .tgz 파일로 패키징

npm view express // 모듈 상세 정보 표시

npm publish // package.json에 정의된 모듈을 레지스트리에 배포

npm unpublish myModule // 배포된 모듈 배포 취소 


package.json 사용법 

ex)
{
	"name" : "my_module",
	"version" : "0.1.0",
	"dependencies" : {
		"express" : "latest"
	}
}

Node.js 애플리케이션 작성
이번 예제의 목적은 패키지를 생성하고 배포하고 사용하는 방법을 익히는 것이기 때문에 패키지 코드의 크기를 작게 했다. 

패키지로 묶인 Node.js 모듈 생성
패키지로 묶인 모듈(NPM)을 생성하려면 자바스크립트로 필요한 기능을 작성하고,
package.json 파일에 패키지 정의를 추가해야 한다. 
패키지는 레지스트리에 등록해 배포를 하거나 지역적 사용을 목적으로 패키지로 묶으면 된다. 

다음 예제는 텍스트 입력을 받아 특정 단어로 별표를 바꿔주는 기능을 하는 
censorify 이름으로 된, 패키지로 묵은 노드 모듈을 만드는 절차다. 

1. 프로젝트 root에 censorify폴더를 생성한다.
2. 생성한 폴더 내에 censortext.js 파일을 생성한다. 
3. 해당 파일에 아래의 내용을 넣는다. 
대부분의 코드는 기본적인 자바스크립트로 작성되 되었지만,
censor(), addCensoredWord(), getCensoredWords() 함수를 익스포트한다. 
해당 모듈을 사용하는 다른 Node.js애플리케이션에서 해당 함수들을 사용하려면 exports.censor와 같은 형식으로 개별적으로 익스포팅해야한다.

var censoredWords = ["sad", "bad", "mad"];
var customCensoredWords = [];
function censor(inStr){
	for(idx in censoredWords){
		inStr = inStr.replace(censoredWords[idx], "****");
	}
	for(idx in customCensoredWords){
		inStr = inStr.replace(customCensoredWords[idx], "****");
	}
	return inStr;
}
function addCensoredWord(word){
	customCensoredWords.push(word);
}
function getCensoredWords(){
	return censoredWords.concat(customCensoredWords);
}
exports.censor = censor;
exports.addCensoredWord = addCensoredWord;
exports.getCensoredWords = getCensoredWords;

4. Node.js 패키지 모듈 제작을 위해 package.json 파일을 .../censorify폴더 내에 생성 후 아래의 내용을 추가한다. 
Node.js는 자동으로 js 확장자를 포함해 검색하기 때문에 .js는 필요하지 않다. 
{
	"author" : "kim joong il",
	"name" : "censorify",
	"version" : "0.0.1",
	"description" : "Censors words out of text",
	"main" : "censortext",
	"dependencies" : {},
	"engines" : {
		"node" : "*"
	}
}
5. README.md 파일을 .../censorify폴더에 생성해 모듈 사용에 필요한 내용을 추가한다. 

6. 콘솔 창을 열어 .../censorify 폴더로 이동한 후 다음 명령어를 실행해 로컬 패키지 모듈을 빌드한다. 
npm pack

그러면 censorify-0.1.1.tgz 파일이 생성된다. 
이로서 첫 패키지 모듈이 완성됐다. 

Node.js 패키지 모듈을 NPM 레지스트리에 발행 
1. 모듈의 코드를 포함하는 공개 저장소를 생성한다. 다음으로 .../censorify 폴더의 내용을 생성한 저장소에 추가한다. 
2. npmjs.org/signup에서 계정을 만든다.
3. 명령 창에서 다음 명령을 사용해 환경 정보에 사용자를 추가한다. 
4. 2단계 계정 등록시 사용했던 사용자명, 패스워드 이메일 정보를 입력한다.
5. 목록 package.json 파일에 아래의 새로운 저장소 정보와 레지스트리 검색 시 사용할 키워드 정보를 수정한다. 
{
	"author" : "kim joong il",
	"name" : "censorify",
	"version" : "0.0.1",
	"description" : "Censors words out of text",
	"main" : "censortext",
	"repository" : {
		"type" : "git",
		"url" : "http://github.com/내 깃주소"
	},
	"keyworkds" : [
		"censor",
		"words"
	],
	"dependencies" : {},
	"engines" : {
		"node" : "*"
	}	
}

6. 콘솔에서 .../censor 폴더로 이동 후 다음 명령을 실행해 모듈을 배포한다. 
npm publish 

패키지가 배포된 후에는 NPM 레지스트리상의 검색을 통해 모듈을 찾을 수 있고, npm install 명령을 통해 자신의 환경에 모듈을 설치할 수 있다. 

레지스트리에서 패키지를 제거하려면 
npm adduser를 통해 모듈에 권한을 가진 사용자 정보를 설정한 후 ,
npm unpublish <project name> 을 수행한다. 
때로는 --force를 붙여야 할 수도 있다. 


Node.js애플리케이션에서 Node.js 패키지 모듈 사용
간단히 자신의 애플리케이션 구조에 모듈을 설치하고 require() 함수를 사용해 모듈을 로딩하기만 하면 Node.js에서 해당 모듈을 사용할 수 있다. 
require() 함수는 설치된 모듈의 이름이나, js파일이 위치한 경로를 전달인자로 갖는다.
ex)
require("censorify")
require("./lib/utils.js")

.js 파일 확장자는 선택적인 사항으로 생략할 수 있다. 

노드에서 실행할 파일에 실제로 위의 패키지를 설치했다고 가정하고 
사용하는 방법은 아래의 코드와 같다. 
var censor = require("censorify");
console.log(censor.getCensoredWords());
console.log(censor.censor("Some very sad, bad and mad text."));
censor.addCensoredWord("gloomy");
console.log(censor.getCensoredWords());
console.log(censor.censor("A very gloomy day."));

그런후 다음 명령을 친다. 
node 실행파일이름.js











